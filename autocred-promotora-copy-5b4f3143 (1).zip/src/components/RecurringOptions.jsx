import React from "react";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";

export default function RecurringOptions({ frequency, quantity, onFrequencyChange, onQuantityChange, defaultFrequency = "mensal", defaultQuantity = 1 }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-blue-200">Frequência de Recorrência</Label>
          <Select value={frequency} onValueChange={onFrequencyChange} defaultValue={defaultFrequency}>
            <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-blue-900 border-blue-700">
              <SelectItem value="quinzenal">Quinzenal (a cada 15 dias)</SelectItem>
              <SelectItem value="mensal">Mensal</SelectItem>
              <SelectItem value="bimestral">Bimestral (a cada 2 meses)</SelectItem>
              <SelectItem value="trimestral">Trimestral (a cada 3 meses)</SelectItem>
              <SelectItem value="semestral">Semestral (a cada 6 meses)</SelectItem>
              <SelectItem value="anual">Anual (1 vez por ano)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-blue-200">Quantidade de Repetições</Label>
          <Input
            type="number"
            min="1"
            max="1200"
            value={quantity}
            onChange={(e) => onQuantityChange(parseInt(e.target.value) || 1)}
            defaultValue={defaultQuantity}
            placeholder="Ex: 12"
            className="bg-blue-950/50 border-blue-700 text-white"
          />
          <p className="text-xs text-blue-400 mt-1">
            {frequency === "quinzenal" && `${quantity} repetições = ${Math.round(quantity * 0.5)} meses`}
            {frequency === "mensal" && `${quantity} repetições = ${quantity} meses`}
            {frequency === "bimestral" && `${quantity} repetições = ${quantity * 2} meses`}
            {frequency === "trimestral" && `${quantity} repetições = ${quantity * 3} meses`}
            {frequency === "semestral" && `${quantity} repetições = ${quantity * 6} meses`}
            {frequency === "anual" && `${quantity} repetições = ${quantity} anos`}
          </p>
        </div>
      </div>
    </div>
  );
}