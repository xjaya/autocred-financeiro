import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Brain, TrendingUp, CheckCircle, AlertCircle, Sparkles, X } from "lucide-react";
import { toast } from "sonner";

// Função para calcular similaridade entre textos (Levenshtein simplificado)
function calculateSimilarity(str1, str2) {
  const s1 = str1.toLowerCase().trim();
  const s2 = str2.toLowerCase().trim();
  
  if (s1 === s2) return 100;
  
  const words1 = s1.split(/\s+/);
  const words2 = s2.split(/\s+/);
  
  let matchingWords = 0;
  words1.forEach(w1 => {
    if (words2.some(w2 => w2.includes(w1) || w1.includes(w2))) {
      matchingWords++;
    }
  });
  
  const similarity = (matchingWords / Math.max(words1.length, words2.length)) * 100;
  return Math.round(similarity);
}

export default function SmartCategorization({ transaction, onApprove, onCorrect }) {
  const [editing, setEditing] = useState(false);
  const [category, setCategory] = useState(transaction.category || "");
  const [subcategory, setSubcategory] = useState(transaction.subcategory || "");
  const [costCenter, setCostCenter] = useState(transaction.cost_center || "");
  const [analyzing, setAnalyzing] = useState(false);
  const [suggestions, setSuggestions] = useState(null);

  const queryClient = useQueryClient();

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list(),
    initialData: [],
  });

  const { data: costCenters = [] } = useQuery({
    queryKey: ["costCenters"],
    queryFn: () => base44.entities.CostCenter.list(),
    initialData: [],
  });

  const { data: aiLearnings = [] } = useQuery({
    queryKey: ["aiLearnings"],
    queryFn: () => base44.entities.AILearning.list(),
    initialData: [],
  });

  const { data: historicalTransactions = [] } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list(),
    initialData: [],
  });

  // Sistema de IA Avançado com pesos e similaridade
  useEffect(() => {
    if (!transaction.category || !transaction.cost_center) {
      analyzeTransaction();
    }
  }, [transaction.id]);

  const analyzeTransaction = async () => {
    setAnalyzing(true);
    try {
      const description = transaction.description.toLowerCase();
      
      // 1. BUSCAR PADRÕES EXATOS APRENDIDOS (peso 10)
      const exactMatches = aiLearnings.filter(l => 
        l.transaction_type === transaction.type &&
        description.includes(l.description_pattern.toLowerCase())
      ).sort((a, b) => (b.times_used || 0) - (a.times_used || 0));

      // 2. BUSCAR PADRÕES SIMILARES (peso 7-9)
      const similarPatterns = aiLearnings
        .filter(l => l.transaction_type === transaction.type)
        .map(l => ({
          ...l,
          similarity: calculateSimilarity(description, l.description_pattern)
        }))
        .filter(l => l.similarity >= 50)
        .sort((a, b) => {
          const scoreA = (a.similarity * 0.6) + ((a.times_used || 0) * 0.4);
          const scoreB = (b.similarity * 0.6) + ((b.times_used || 0) * 0.4);
          return scoreB - scoreA;
        });

      // 3. BUSCAR TRANSAÇÕES HISTÓRICAS SIMILARES (peso 5-7)
      const similarTransactions = historicalTransactions
        .filter(t => 
          t.type === transaction.type && 
          t.category && 
          t.id !== transaction.id
        )
        .map(t => ({
          ...t,
          similarity: calculateSimilarity(description, t.description)
        }))
        .filter(t => t.similarity >= 40)
        .sort((a, b) => b.similarity - a.similarity)
        .slice(0, 5);

      // 4. ANÁLISE COM IA PARA CASOS COMPLEXOS
      let aiSuggestion = null;
      if (exactMatches.length === 0 && similarPatterns.length === 0) {
        const result = await base44.integrations.Core.InvokeLLM({
          prompt: `Analise esta transação e sugira categoria, subcategoria e centro de custo:

TRANSAÇÃO: ${transaction.description}
TIPO: ${transaction.type}
VALOR: R$ ${transaction.amount}

CATEGORIAS DISPONÍVEIS: ${categories.map(c => c.name).join(', ')}
CENTROS DE CUSTO: ${costCenters.map(cc => cc.name).join(', ')}

Retorne a melhor sugestão baseada no contexto.`,
          response_json_schema: {
            type: "object",
            properties: {
              category: { type: "string" },
              subcategory: { type: "string" },
              cost_center: { type: "string" },
              confidence: { type: "number", description: "1-10" },
              reasoning: { type: "string" }
            }
          }
        });
        
        aiSuggestion = result;
      }

      // 5. CALCULAR CONFIANÇA GERAL E MONTAR SUGESTÕES
      let finalSuggestion = null;
      let confidence = 5;

      if (exactMatches.length > 0) {
        const best = exactMatches[0];
        finalSuggestion = {
          category: best.learned_category,
          subcategory: best.learned_subcategory || "",
          cost_center: best.learned_cost_center || "",
          source: "exact_match",
          confidence: Math.min(10, 8 + (best.times_used || 0) / 10)
        };
        confidence = finalSuggestion.confidence;
      } else if (similarPatterns.length > 0) {
        const best = similarPatterns[0];
        finalSuggestion = {
          category: best.learned_category,
          subcategory: best.learned_subcategory || "",
          cost_center: best.learned_cost_center || "",
          source: "similar_pattern",
          confidence: Math.min(9, 6 + (best.similarity / 100) * 3)
        };
        confidence = finalSuggestion.confidence;
      } else if (similarTransactions.length > 0) {
        const best = similarTransactions[0];
        finalSuggestion = {
          category: best.category,
          subcategory: best.subcategory || "",
          cost_center: best.cost_center || "",
          source: "historical",
          confidence: Math.min(7, 4 + (best.similarity / 100) * 3)
        };
        confidence = finalSuggestion.confidence;
      } else if (aiSuggestion) {
        finalSuggestion = {
          category: aiSuggestion.category,
          subcategory: aiSuggestion.subcategory || "",
          cost_center: aiSuggestion.cost_center || "",
          source: "ai_analysis",
          confidence: aiSuggestion.confidence || 5
        };
        confidence = finalSuggestion.confidence;
      }

      setSuggestions({
        primary: finalSuggestion,
        alternatives: [
          ...similarPatterns.slice(0, 2).map(p => ({
            category: p.learned_category,
            subcategory: p.learned_subcategory,
            cost_center: p.learned_cost_center,
            confidence: Math.min(8, 5 + (p.similarity / 100) * 3),
            source: "similar"
          })),
          ...similarTransactions.slice(0, 2).map(t => ({
            category: t.category,
            subcategory: t.subcategory,
            cost_center: t.cost_center,
            confidence: Math.min(6, 3 + (t.similarity / 100) * 3),
            source: "historical"
          }))
        ].slice(0, 3),
        confidence: Math.round(confidence)
      });

      // Aplicar sugestão principal
      if (finalSuggestion) {
        setCategory(finalSuggestion.category);
        setSubcategory(finalSuggestion.subcategory);
        setCostCenter(finalSuggestion.cost_center);
      }

    } catch (error) {
      console.error("Erro na análise:", error);
    }
    setAnalyzing(false);
  };

  const learnFromCorrection = async (correctedData) => {
    try {
      const pattern = transaction.description.split(' ').slice(0, 3).join(' ').toLowerCase();
      
      // Buscar padrão existente
      const existing = aiLearnings.find(l => 
        l.description_pattern === pattern && 
        l.transaction_type === transaction.type
      );

      if (existing) {
        // Atualizar com peso aumentado
        const newTimesUsed = (existing.times_used || 0) + 1;
        const newConfidence = Math.min(10, (existing.confidence_score || 5) + 0.5);
        
        await base44.entities.AILearning.update(existing.id, {
          learned_category: correctedData.category,
          learned_subcategory: correctedData.subcategory || "",
          learned_cost_center: correctedData.cost_center || "",
          times_used: newTimesUsed,
          confidence_score: newConfidence,
          last_used: new Date().toISOString()
        });
      } else {
        // Criar novo padrão
        await base44.entities.AILearning.create({
          description_pattern: pattern,
          learned_category: correctedData.category,
          learned_subcategory: correctedData.subcategory || "",
          learned_cost_center: correctedData.cost_center || "",
          transaction_type: transaction.type,
          confidence_score: 7,
          times_used: 1,
          last_used: new Date().toISOString()
        });
      }

      queryClient.invalidateQueries({ queryKey: ["aiLearnings"] });
    } catch (error) {
      console.error("Erro ao aprender:", error);
    }
  };

  const handleApprove = async () => {
    await learnFromCorrection({ category, subcategory, cost_center });
    await onApprove();
    toast.success("🧠 IA aprendeu com sucesso!");
  };

  const handleCorrect = async () => {
    await learnFromCorrection({ category, subcategory, cost_center });
    await onCorrect({ category, subcategory, cost_center });
    setEditing(false);
    toast.success("✅ Correção aplicada e IA treinada!");
  };

  const sourceLabels = {
    exact_match: "Padrão Exato",
    similar_pattern: "Padrão Similar",
    historical: "Histórico",
    ai_analysis: "Análise IA"
  };

  return (
    <Card className="border-purple-700/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
      <CardContent className="pt-6 space-y-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Brain className="w-5 h-5 text-purple-400" />
              <p className="text-white font-semibold">{transaction.description}</p>
            </div>
            <p className="text-sm text-purple-300">
              R$ {transaction.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })} • {transaction.type}
            </p>
          </div>
          {analyzing && (
            <div className="flex items-center gap-2 text-purple-300 text-sm">
              <Sparkles className="w-4 h-4 animate-spin" />
              Analisando...
            </div>
          )}
        </div>

        {suggestions && (
          <div className="space-y-3">
            <div className="bg-purple-950/30 p-3 rounded-lg border border-purple-700">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-purple-300">
                  {sourceLabels[suggestions.primary.source]}
                </span>
                <div className="flex items-center gap-2">
                  <Progress value={suggestions.confidence * 10} className="w-20 h-2" />
                  <span className="text-xs text-purple-200">{suggestions.confidence}/10</span>
                </div>
              </div>
              
              {!editing ? (
                <div className="space-y-2">
                  <div>
                    <span className="text-xs text-purple-400">Categoria:</span>
                    <p className="text-white font-medium">{category || "-"}</p>
                  </div>
                  {subcategory && (
                    <div>
                      <span className="text-xs text-purple-400">Subcategoria:</span>
                      <p className="text-white">{subcategory}</p>
                    </div>
                  )}
                  <div>
                    <span className="text-xs text-purple-400">Centro de Custo:</span>
                    <p className="text-white">{costCenter || "-"}</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger className="bg-purple-950/50 border-purple-700 text-white">
                      <SelectValue placeholder="Categoria" />
                    </SelectTrigger>
                    <SelectContent className="bg-purple-900 border-purple-700">
                      {categories.map(c => (
                        <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={costCenter} onValueChange={setCostCenter}>
                    <SelectTrigger className="bg-purple-950/50 border-purple-700 text-white">
                      <SelectValue placeholder="Centro de Custo" />
                    </SelectTrigger>
                    <SelectContent className="bg-purple-900 border-purple-700">
                      {costCenters.map(cc => (
                        <SelectItem key={cc.id} value={cc.name}>{cc.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            {suggestions.alternatives.length > 0 && !editing && (
              <div className="space-y-2">
                <p className="text-xs text-purple-400">Alternativas:</p>
                {suggestions.alternatives.map((alt, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setCategory(alt.category);
                      setSubcategory(alt.subcategory);
                      setCostCenter(alt.cost_center);
                    }}
                    className="w-full text-left bg-purple-950/20 p-2 rounded border border-purple-700/50 hover:bg-purple-950/40 transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <div className="text-xs">
                        <span className="text-purple-300">{alt.category}</span>
                        {alt.cost_center && <span className="text-purple-400"> • {alt.cost_center}</span>}
                      </div>
                      <Badge className="bg-purple-500/20 text-purple-300 text-xs">
                        {Math.round(alt.confidence)}/10
                      </Badge>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="flex gap-2">
          {!editing ? (
            <>
              <Button
                onClick={handleApprove}
                className="flex-1 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Aprovar
              </Button>
              <Button
                onClick={() => setEditing(true)}
                variant="outline"
                className="flex-1 border-purple-700 text-purple-300 hover:bg-purple-900/20"
              >
                <AlertCircle className="w-4 h-4 mr-2" />
                Corrigir
              </Button>
            </>
          ) : (
            <>
              <Button
                onClick={handleCorrect}
                className="flex-1 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Salvar e Treinar IA
              </Button>
              <Button
                onClick={() => setEditing(false)}
                variant="outline"
                className="border-red-700 text-red-300 hover:bg-red-900/20"
              >
                <X className="w-4 h-4" />
              </Button>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}