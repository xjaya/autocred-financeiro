import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertTriangle, CheckCircle } from "lucide-react";

export default function ManualColumnMapper({ rawData, onComplete, onCancel }) {
  const [mapping, setMapping] = useState({
    date: null,
    description: null,
    amount: null,
    type: null
  });

  const [sampleRow, setSampleRow] = useState(0);

  // Detecta possíveis colunas nos dados
  const detectColumns = () => {
    if (!rawData || rawData.length === 0) return [];
    
    const firstRow = rawData[0];
    if (typeof firstRow === 'object') {
      return Object.keys(firstRow);
    }
    
    // Se for texto bruto, divide por espaços/tabs
    return firstRow.split(/\s{2,}|\t/).map((_, i) => `Coluna ${i + 1}`);
  };

  const columns = detectColumns();

  const handleApplyMapping = () => {
    if (!mapping.date || !mapping.description || !mapping.amount) {
      alert("Por favor, mapeie pelo menos Data, Descrição e Valor");
      return;
    }

    const mappedTransactions = rawData.map((row, i) => {
      const cells = typeof row === 'object' ? row : row.split(/\s{2,}|\t/);
      
      return {
        id: i,
        date: cells[mapping.date] || "",
        description: cells[mapping.description] || "",
        amount: parseFloat(cells[mapping.amount]?.replace(/[^\d,-]/g, '').replace(',', '.')) || 0,
        type: mapping.type ? (cells[mapping.type]?.toLowerCase().includes('credito') ? 'receita' : 'despesa') : 'despesa',
        category: "",
        cost_center: "",
        supplier_name: "",
        client_name: ""
      };
    });

    onComplete(mappedTransactions);
  };

  return (
    <Card className="border-orange-700/50 bg-gradient-to-br from-orange-900/80 to-orange-800/80">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-orange-400" />
          Mapeamento Manual de Colunas
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-orange-200 text-sm">
          A IA não conseguiu identificar as colunas automaticamente. 
          Por favor, mapeie as colunas do seu extrato:
        </p>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-orange-200">Coluna de Data*</Label>
            <Select value={mapping.date} onValueChange={(val) => setMapping({...mapping, date: val})}>
              <SelectTrigger className="bg-orange-950/50 border-orange-700 text-white">
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent className="bg-orange-900 border-orange-700">
                {columns.map((col, i) => (
                  <SelectItem key={i} value={String(i)}>{col}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-orange-200">Coluna de Descrição*</Label>
            <Select value={mapping.description} onValueChange={(val) => setMapping({...mapping, description: val})}>
              <SelectTrigger className="bg-orange-950/50 border-orange-700 text-white">
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent className="bg-orange-900 border-orange-700">
                {columns.map((col, i) => (
                  <SelectItem key={i} value={String(i)}>{col}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-orange-200">Coluna de Valor*</Label>
            <Select value={mapping.amount} onValueChange={(val) => setMapping({...mapping, amount: val})}>
              <SelectTrigger className="bg-orange-950/50 border-orange-700 text-white">
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent className="bg-orange-900 border-orange-700">
                {columns.map((col, i) => (
                  <SelectItem key={i} value={String(i)}>{col}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-orange-200">Coluna de Tipo (opcional)</Label>
            <Select value={mapping.type} onValueChange={(val) => setMapping({...mapping, type: val})}>
              <SelectTrigger className="bg-orange-950/50 border-orange-700 text-white">
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent className="bg-orange-900 border-orange-700">
                <SelectItem value={null}>Nenhuma</SelectItem>
                {columns.map((col, i) => (
                  <SelectItem key={i} value={String(i)}>{col}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="bg-orange-950/50 p-3 rounded-lg">
          <Label className="text-orange-200 text-xs mb-2 block">Pré-visualização (Linha {sampleRow + 1})</Label>
          {rawData && rawData[sampleRow] && (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-orange-700">
                    {columns.map((col, i) => (
                      <TableHead key={i} className="text-orange-300 text-xs">{col}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow className="border-orange-700">
                    {(typeof rawData[sampleRow] === 'object' 
                      ? Object.values(rawData[sampleRow])
                      : rawData[sampleRow].split(/\s{2,}|\t/)
                    ).map((cell, i) => (
                      <TableCell key={i} className="text-white text-xs">{cell}</TableCell>
                    ))}
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          )}
        </div>

        <div className="flex gap-3">
          <Button onClick={onCancel} variant="outline" className="flex-1 border-orange-700 text-orange-200 hover:bg-orange-800">
            Cancelar
          </Button>
          <Button onClick={handleApplyMapping} className="flex-1 bg-gradient-to-r from-orange-600 to-orange-500">
            <CheckCircle className="w-4 h-4 mr-2" />
            Aplicar Mapeamento
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}