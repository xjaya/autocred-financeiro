import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";
import { Sparkles, TrendingUp, AlertTriangle, CheckCircle, X, Lightbulb } from "lucide-react";
import { toast } from "sonner";

export default function AIFinancialSuggestions({ transactions, bankAccounts }) {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    generateSuggestions();
  }, [transactions]);

  const generateSuggestions = async () => {
    if (!transactions || transactions.length === 0) return;

    setLoading(true);
    try {
      const totalRevenue = transactions
        .filter(t => t.type === "receita" && t.status === "pago")
        .reduce((sum, t) => sum + t.amount, 0);

      const totalExpenses = transactions
        .filter(t => t.type === "despesa" && t.status === "pago")
        .reduce((sum, t) => sum + t.amount, 0);

      const pendingExpenses = transactions
        .filter(t => t.type === "despesa" && t.status === "pendente")
        .reduce((sum, t) => sum + t.amount, 0);

      const lowBalanceAccounts = bankAccounts.filter(acc => (acc.initial_balance || 0) < 1000);

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Você é um assistente financeiro proativo. Analise os dados e forneça 3-5 sugestões acionáveis:

DADOS FINANCEIROS:
- Receitas totais: R$ ${totalRevenue.toFixed(2)}
- Despesas totais: R$ ${totalExpenses.toFixed(2)}
- Saldo: R$ ${(totalRevenue - totalExpenses).toFixed(2)}
- Despesas pendentes: R$ ${pendingExpenses.toFixed(2)}
- Contas com saldo baixo: ${lowBalanceAccounts.length}

Forneça sugestões práticas em JSON com este formato exato:
{
  "suggestions": [
    {
      "type": "investment|alert|optimization|opportunity",
      "title": "Título curto",
      "description": "Descrição detalhada",
      "priority": "high|medium|low",
      "action": "Ação sugerida"
    }
  ]
}`,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: { type: "string" },
                  title: { type: "string" },
                  description: { type: "string" },
                  priority: { type: "string" },
                  action: { type: "string" }
                },
                required: ["type", "title", "description", "priority", "action"]
              }
            }
          },
          required: ["suggestions"]
        }
      });

      setSuggestions(result.suggestions || []);
    } catch (error) {
      console.error("Erro ao gerar sugestões:", error);
    }
    setLoading(false);
  };

  const dismissSuggestion = (index) => {
    setSuggestions(suggestions.filter((_, i) => i !== index));
    toast.success("Sugestão dispensada");
  };

  const getIcon = (type) => {
    switch (type) {
      case "investment": return <TrendingUp className="w-5 h-5 text-green-400" />;
      case "alert": return <AlertTriangle className="w-5 h-5 text-yellow-400" />;
      case "optimization": return <Lightbulb className="w-5 h-5 text-blue-400" />;
      case "opportunity": return <Sparkles className="w-5 h-5 text-purple-400" />;
      default: return <Lightbulb className="w-5 h-5 text-blue-400" />;
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case "high": return "bg-red-500/20 text-red-300 border-red-500";
      case "medium": return "bg-yellow-500/20 text-yellow-300 border-yellow-500";
      case "low": return "bg-blue-500/20 text-blue-300 border-blue-500";
      default: return "bg-gray-500/20 text-gray-300 border-gray-500";
    }
  };

  if (loading) {
    return (
      <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-400 animate-spin" />
            Gerando Sugestões Inteligentes...
          </CardTitle>
        </CardHeader>
      </Card>
    );
  }

  if (suggestions.length === 0) return null;

  return (
    <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-400" />
          Sugestões Inteligentes da IA
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {suggestions.map((suggestion, index) => (
          <div
            key={index}
            className="bg-purple-950/50 border border-purple-700 rounded-lg p-4"
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                {getIcon(suggestion.type)}
                <h3 className="text-white font-semibold">{suggestion.title}</h3>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={getPriorityColor(suggestion.priority)}>
                  {suggestion.priority}
                </Badge>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => dismissSuggestion(index)}
                  className="text-purple-300 hover:text-white h-6 w-6 p-0"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <p className="text-sm text-purple-200 mb-2">{suggestion.description}</p>
            <div className="flex items-center gap-2 mt-3">
              <CheckCircle className="w-4 h-4 text-purple-400" />
              <p className="text-sm text-purple-300 font-medium">{suggestion.action}</p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}