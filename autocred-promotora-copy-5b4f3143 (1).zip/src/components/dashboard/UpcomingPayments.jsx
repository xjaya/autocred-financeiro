import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, TrendingUp, TrendingDown } from "lucide-react";
import { format, differenceInDays, addDays } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function UpcomingPayments({ transactions }) {
  const today = new Date();
  const next7Days = addDays(today, 7);

  const upcoming = transactions
    .filter(t => {
      const dueDate = new Date(t.due_date);
      return t.status === "pendente" && dueDate >= today && dueDate <= next7Days;
    })
    .sort((a, b) => new Date(a.due_date) - new Date(b.due_date))
    .slice(0, 5);

  if (upcoming.length === 0) return null;

  return (
    <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Calendar className="w-5 h-5 text-yellow-400" />
          Próximos Vencimentos (7 dias)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {upcoming.map((transaction) => {
            const daysUntil = differenceInDays(new Date(transaction.due_date), today);
            return (
              <div
                key={transaction.id}
                className="bg-blue-950/50 border border-blue-700 rounded-lg p-3 flex items-center justify-between"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    {transaction.type === "receita" ? (
                      <TrendingUp className="w-4 h-4 text-green-400" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-400" />
                    )}
                    <span className="text-white font-medium text-sm">{transaction.description}</span>
                  </div>
                  <p className="text-xs text-blue-300">
                    {format(new Date(transaction.due_date), "dd/MM/yyyy")} • 
                    {daysUntil === 0 ? " Hoje" : daysUntil === 1 ? " Amanhã" : ` ${daysUntil} dias`}
                  </p>
                </div>
                <div className="text-right">
                  <p className={`text-lg font-bold ${transaction.type === "receita" ? "text-green-300" : "text-red-300"}`}>
                    R$ {transaction.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </p>
                  <Badge className={daysUntil <= 2 ? "bg-red-500/20 text-red-300 border-red-500" : "bg-yellow-500/20 text-yellow-300 border-yellow-500"}>
                    {transaction.type === "receita" ? "A Receber" : "A Pagar"}
                  </Badge>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}