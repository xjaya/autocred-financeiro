import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp } from "lucide-react";
import { startOfMonth, endOfMonth, subMonths, format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function RevenueVsExpensesChart({ transactions }) {
  // Últimos 6 meses
  const last6Months = Array.from({ length: 6 }, (_, i) => {
    const date = subMonths(new Date(), 5 - i);
    const monthStart = startOfMonth(date);
    const monthEnd = endOfMonth(date);
    
    const monthTransactions = transactions.filter(t => {
      const tDate = new Date(t.due_date);
      return t.status === "pago" && tDate >= monthStart && tDate <= monthEnd;
    });

    const receitas = monthTransactions
      .filter(t => t.type === "receita")
      .reduce((sum, t) => sum + t.amount, 0);
    
    const despesas = monthTransactions
      .filter(t => t.type === "despesa")
      .reduce((sum, t) => sum + t.amount, 0);

    return {
      month: format(date, "MMM/yy", { locale: ptBR }),
      receitas,
      despesas,
      lucro: receitas - despesas,
    };
  });

  return (
    <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-green-400" />
          Receitas vs Despesas (6 meses)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={last6Months}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
            <XAxis dataKey="month" stroke="#93c5fd" fontSize={12} />
            <YAxis stroke="#93c5fd" fontSize={12} />
            <Tooltip
              contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px" }}
              formatter={(value) => `R$ ${value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
            />
            <Legend />
            <Bar dataKey="receitas" fill="#10B981" radius={[8, 8, 0, 0]} name="Receitas" />
            <Bar dataKey="despesas" fill="#EF4444" radius={[8, 8, 0, 0]} name="Despesas" />
            <Bar dataKey="lucro" fill="#3B82F6" radius={[8, 8, 0, 0]} name="Lucro" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}