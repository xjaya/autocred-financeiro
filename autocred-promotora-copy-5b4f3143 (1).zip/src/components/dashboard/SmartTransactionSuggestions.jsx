import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";
import { Sparkles, CheckCircle, X, Tag } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

export default function SmartTransactionSuggestions({ transactions, categories, costCenters }) {
  const [suggestions, setSuggestions] = useState([]);
  const queryClient = useQueryClient();

  useEffect(() => {
    analyzePendingTransactions();
  }, [transactions]);

  const analyzePendingTransactions = () => {
    // Encontrar transações sem categoria ou centro de custo
    const uncategorized = transactions.filter(t => 
      !t.category || !t.cost_center
    ).slice(0, 5);

    const newSuggestions = uncategorized.map(t => {
      // Buscar padrões similares
      const similar = transactions.find(existing => 
        existing.description.toLowerCase().includes(t.description.toLowerCase().split(' ')[0]) &&
        existing.category && existing.cost_center
      );

      return {
        transaction: t,
        suggestedCategory: similar?.category || "Outros",
        suggestedCostCenter: similar?.cost_center || "Geral",
        confidence: similar ? 0.85 : 0.5
      };
    });

    setSuggestions(newSuggestions);
  };

  const applySuggestion = async (suggestion) => {
    try {
      await base44.entities.Transaction.update(suggestion.transaction.id, {
        ...suggestion.transaction,
        category: suggestion.suggestedCategory,
        cost_center: suggestion.suggestedCostCenter
      });
      
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      setSuggestions(suggestions.filter(s => s.transaction.id !== suggestion.transaction.id));
      toast.success("✅ Categorização aplicada!");
    } catch (error) {
      toast.error("Erro ao aplicar sugestão");
    }
  };

  const dismissSuggestion = (transactionId) => {
    setSuggestions(suggestions.filter(s => s.transaction.id !== transactionId));
  };

  if (suggestions.length === 0) return null;

  return (
    <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Tag className="w-5 h-5 text-purple-400" />
          Sugestões de Categorização
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {suggestions.map((suggestion) => (
          <div
            key={suggestion.transaction.id}
            className="bg-purple-950/50 border border-purple-700 rounded-lg p-4"
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <p className="text-white font-medium">{suggestion.transaction.description}</p>
                <p className="text-sm text-purple-300 mt-1">
                  R$ {suggestion.transaction.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </p>
              </div>
              <Badge className={`ml-2 ${
                suggestion.confidence > 0.7 ? "bg-green-500/20 text-green-300 border-green-500" :
                "bg-yellow-500/20 text-yellow-300 border-yellow-500"
              }`}>
                {Math.round(suggestion.confidence * 100)}% confiança
              </Badge>
            </div>
            <div className="flex items-center gap-2 text-sm text-purple-200 mb-3">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>Categoria: <strong>{suggestion.suggestedCategory}</strong></span>
              <span>•</span>
              <span>Centro de Custo: <strong>{suggestion.suggestedCostCenter}</strong></span>
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={() => applySuggestion(suggestion)}
                className="bg-green-600 hover:bg-green-700 flex-1"
              >
                <CheckCircle className="w-4 h-4 mr-1" />
                Aplicar
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => dismissSuggestion(suggestion.transaction.id)}
                className="border-purple-700 text-purple-300 hover:bg-purple-800"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}