import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { base44 } from "@/api/base44Client";
import { TrendingUp, TrendingDown, Calendar } from "lucide-react";
import { addMonths, format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Area, AreaChart } from "recharts";

export default function CashFlowPrediction({ transactions }) {
  const [prediction, setPrediction] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    generatePrediction();
  }, [transactions]);

  const generatePrediction = async () => {
    if (!transactions || transactions.length === 0) return;

    setLoading(true);
    try {
      // Calcular médias mensais dos últimos 3 meses
      const last3MonthsRevenue = transactions
        .filter(t => t.type === "receita" && t.status === "pago")
        .reduce((sum, t) => sum + t.amount, 0) / 3;

      const last3MonthsExpenses = transactions
        .filter(t => t.type === "despesa" && t.status === "pago")
        .reduce((sum, t) => sum + t.amount, 0) / 3;

      const currentBalance = last3MonthsRevenue - last3MonthsExpenses;

      // Gerar previsão para os próximos 6 meses
      const predictionData = [];
      let balance = currentBalance;

      for (let i = 0; i < 6; i++) {
        const month = addMonths(new Date(), i + 1);
        const monthName = format(month, "MMM/yy", { locale: ptBR });

        // Aplicar variação de 5-10% na previsão
        const revenueVariation = (Math.random() * 0.1 - 0.05) + 1; // -5% a +5%
        const expenseVariation = (Math.random() * 0.1 - 0.05) + 1;

        const predictedRevenue = last3MonthsRevenue * revenueVariation;
        const predictedExpense = last3MonthsExpenses * expenseVariation;

        balance += predictedRevenue - predictedExpense;

        predictionData.push({
          month: monthName,
          receita: predictedRevenue,
          despesa: predictedExpense,
          saldo: balance,
        });
      }

      setPrediction(predictionData);
    } catch (error) {
      console.error("Erro ao gerar previsão:", error);
    }
    setLoading(false);
  };

  if (loading || prediction.length === 0) return null;

  const finalBalance = prediction[prediction.length - 1].saldo;
  const isPositive = finalBalance > 0;

  return (
    <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-400" />
            Previsão de Fluxo de Caixa (6 meses)
          </CardTitle>
          <div className="flex items-center gap-2">
            {isPositive ? (
              <TrendingUp className="w-5 h-5 text-green-400" />
            ) : (
              <TrendingDown className="w-5 h-5 text-red-400" />
            )}
            <span className={`text-lg font-bold ${isPositive ? "text-green-300" : "text-red-300"}`}>
              R$ {finalBalance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={prediction}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
            <XAxis dataKey="month" stroke="#93c5fd" fontSize={12} />
            <YAxis stroke="#93c5fd" fontSize={12} />
            <Tooltip
              contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px" }}
              formatter={(value) => `R$ ${value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
            />
            <Legend />
            <Area type="monotone" dataKey="saldo" stroke="#3B82F6" fill="#3B82F6" fillOpacity={0.6} name="Saldo Previsto" />
            <Line type="monotone" dataKey="receita" stroke="#10B981" strokeWidth={2} name="Receitas" />
            <Line type="monotone" dataKey="despesa" stroke="#EF4444" strokeWidth={2} name="Despesas" />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}