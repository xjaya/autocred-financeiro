import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { AlertTriangle, CheckCircle, XCircle, Send, FileWarning } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function ErrorReportPanel({ errors, onRetry, onSkip, fileName }) {
  const [feedback, setFeedback] = useState("");
  const [sending, setSending] = useState(false);

  const handleSendFeedback = async () => {
    if (!feedback.trim()) {
      toast.error("Digite o feedback antes de enviar");
      return;
    }

    setSending(true);
    try {
      // Salvar feedback como nota no sistema
      await base44.integrations.Core.InvokeLLM({
        prompt: `FEEDBACK DO USUÁRIO sobre importação de extrato:
        
Arquivo: ${fileName}
Erros encontrados: ${errors.length}
Feedback: ${feedback}

Por favor, registre este feedback para melhorar futuras extrações.`
      });

      toast.success("✅ Feedback enviado! Obrigado por ajudar a melhorar o sistema.");
      setFeedback("");
    } catch (error) {
      console.error("Erro ao enviar feedback:", error);
      toast.error("❌ Erro ao enviar feedback");
    }
    setSending(false);
  };

  if (!errors || errors.length === 0) return null;

  const criticalErrors = errors.filter(e => e.severity === "critical");
  const warningErrors = errors.filter(e => e.severity === "warning");

  return (
    <Card className="border-red-700/50 bg-gradient-to-br from-red-900/80 to-red-800/80">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-red-400 animate-pulse" />
          Problemas Detectados na Importação
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-red-950/50 p-4 rounded-lg border border-red-700">
            <div className="flex items-center gap-2 mb-2">
              <XCircle className="w-5 h-5 text-red-400" />
              <p className="text-xs text-red-300">Críticos</p>
            </div>
            <p className="text-2xl font-bold text-white">{criticalErrors.length}</p>
          </div>
          <div className="bg-yellow-950/50 p-4 rounded-lg border border-yellow-700">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-5 h-5 text-yellow-400" />
              <p className="text-xs text-yellow-300">Avisos</p>
            </div>
            <p className="text-2xl font-bold text-white">{warningErrors.length}</p>
          </div>
          <div className="bg-green-950/50 p-4 rounded-lg border border-green-700">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <p className="text-xs text-green-300">Sucesso</p>
            </div>
            <p className="text-2xl font-bold text-white">
              {errors.filter(e => e.fixed).length}
            </p>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-white font-semibold">Detalhes dos Problemas:</h3>
          <div className="max-h-96 overflow-y-auto space-y-2">
            {errors.map((error, idx) => (
              <div
                key={idx}
                className={`p-4 rounded-lg border ${
                  error.severity === "critical"
                    ? "bg-red-950/30 border-red-700"
                    : "bg-yellow-950/30 border-yellow-700"
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge
                        className={
                          error.severity === "critical"
                            ? "bg-red-500"
                            : "bg-yellow-500"
                        }
                      >
                        {error.type}
                      </Badge>
                      {error.transactionIndex !== undefined && (
                        <span className="text-xs text-gray-400">
                          Transação #{error.transactionIndex + 1}
                        </span>
                      )}
                    </div>
                    <p className="text-white text-sm font-medium">{error.message}</p>
                    {error.details && (
                      <p className="text-gray-300 text-xs mt-1">{error.details}</p>
                    )}
                    {error.suggestion && (
                      <p className="text-blue-300 text-xs mt-2">
                        💡 Sugestão: {error.suggestion}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-blue-950/30 p-4 rounded-lg border border-blue-700">
          <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
            <FileWarning className="w-4 h-4" />
            Enviar Feedback
          </h3>
          <p className="text-blue-200 text-sm mb-3">
            Encontrou algum problema? Nos ajude a melhorar o sistema reportando o erro:
          </p>
          <Textarea
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            placeholder="Descreva o problema encontrado (ex: 'O sistema não extraiu corretamente as transações do dia 15/11')"
            rows={4}
            className="bg-blue-950/50 border-blue-700 text-white mb-3"
          />
          <Button
            onClick={handleSendFeedback}
            disabled={sending || !feedback.trim()}
            className="w-full bg-gradient-to-r from-blue-600 to-blue-500"
          >
            {sending ? (
              <>
                <Send className="w-4 h-4 mr-2 animate-pulse" />
                Enviando...
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Enviar Feedback
              </>
            )}
          </Button>
        </div>

        <div className="flex gap-3">
          <Button
            onClick={onRetry}
            className="flex-1 bg-gradient-to-r from-blue-600 to-blue-500"
          >
            🔄 Tentar Novamente
          </Button>
          <Button
            onClick={onSkip}
            variant="outline"
            className="flex-1 border-red-700 text-red-200 hover:bg-red-800"
          >
            Pular Transações com Erro
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}