import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Landmark, CreditCard, Hash, Building2 } from "lucide-react";

export default function BankHeaderDetector({ bankInfo }) {
  if (!bankInfo) return null;

  return (
    <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
      <CardContent className="pt-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex items-center gap-3 bg-blue-950/50 p-3 rounded-lg">
            <Landmark className="w-5 h-5 text-blue-400" />
            <div>
              <p className="text-xs text-blue-300">Banco</p>
              <p className="text-sm font-semibold text-white">{bankInfo.bank_name || "Não detectado"}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 bg-blue-950/50 p-3 rounded-lg">
            <Building2 className="w-5 h-5 text-blue-400" />
            <div>
              <p className="text-xs text-blue-300">Agência</p>
              <p className="text-sm font-semibold text-white">{bankInfo.agency || "N/A"}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 bg-blue-950/50 p-3 rounded-lg">
            <Hash className="w-5 h-5 text-blue-400" />
            <div>
              <p className="text-xs text-blue-300">Conta</p>
              <p className="text-sm font-semibold text-white">{bankInfo.account || "N/A"}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 bg-blue-950/50 p-3 rounded-lg">
            <CreditCard className="w-5 h-5 text-blue-400" />
            <div>
              <p className="text-xs text-blue-300">Tipo</p>
              <p className="text-sm font-semibold text-white">{bankInfo.account_type || "Corrente"}</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}