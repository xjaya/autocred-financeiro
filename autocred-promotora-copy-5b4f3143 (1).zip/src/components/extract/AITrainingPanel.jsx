import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Brain, Plus, Trash2, Save, Sparkles, TrendingUp, TrendingDown } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function AITrainingPanel({ categories, costCenters, aiLearnings, onUpdate }) {
  const [newRule, setNewRule] = useState({
    pattern: "",
    type: "despesa",
    category: "",
    subcategory: "",
    cost_center: ""
  });
  const [saving, setSaving] = useState(false);

  const handleAddRule = async () => {
    if (!newRule.pattern || !newRule.category) {
      toast.error("Preencha padrão e categoria");
      return;
    }

    setSaving(true);
    try {
      const existing = aiLearnings.find(l => 
        l.description_pattern === newRule.pattern.toLowerCase() && 
        l.transaction_type === newRule.type
      );

      if (existing) {
        await base44.entities.AILearning.update(existing.id, {
          learned_category: newRule.category,
          learned_subcategory: newRule.subcategory,
          learned_cost_center: newRule.cost_center,
          confidence_score: 10,
          times_used: (existing.times_used || 0) + 1,
          last_used: new Date().toISOString()
        });
        toast.success("✅ Regra atualizada!");
      } else {
        await base44.entities.AILearning.create({
          description_pattern: newRule.pattern.toLowerCase(),
          learned_category: newRule.category,
          learned_subcategory: newRule.subcategory || "",
          learned_cost_center: newRule.cost_center || "",
          learned_supplier: "",
          transaction_type: newRule.type,
          confidence_score: 10,
          times_used: 1,
          last_used: new Date().toISOString()
        });
        toast.success("✅ Regra criada!");
      }

      setNewRule({
        pattern: "",
        type: "despesa",
        category: "",
        subcategory: "",
        cost_center: ""
      });

      onUpdate();
    } catch (error) {
      console.error("Erro ao salvar regra:", error);
      toast.error("❌ Erro ao salvar regra");
    }
    setSaving(false);
  };

  const handleDeleteRule = async (id) => {
    try {
      await base44.entities.AILearning.delete(id);
      toast.success("✅ Regra removida!");
      onUpdate();
    } catch (error) {
      console.error("Erro ao deletar:", error);
      toast.error("❌ Erro ao deletar");
    }
  };

  const sortedLearnings = [...aiLearnings].sort((a, b) => 
    (b.confidence_score || 0) - (a.confidence_score || 0)
  );

  return (
    <Card className="border-purple-700/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Brain className="w-5 h-5 text-purple-400" />
          Treinar IA - Regras de Categorização
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="bg-purple-950/30 p-4 rounded-lg border border-purple-700">
          <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Adicionar Nova Regra
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <Label className="text-purple-200">Padrão de Texto (palavras-chave)</Label>
              <Input
                value={newRule.pattern}
                onChange={(e) => setNewRule({ ...newRule, pattern: e.target.value })}
                placeholder="Ex: uber, ifood, farmacia"
                className="bg-purple-950/50 border-purple-700 text-white"
              />
              <p className="text-xs text-purple-300 mt-1">
                Se a descrição contém este texto, aplicar a regra
              </p>
            </div>

            <div>
              <Label className="text-purple-200">Tipo</Label>
              <Select value={newRule.type} onValueChange={(v) => setNewRule({ ...newRule, type: v })}>
                <SelectTrigger className="bg-purple-950/50 border-purple-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-purple-900 border-purple-700">
                  <SelectItem value="receita">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-green-400" />
                      Receita
                    </div>
                  </SelectItem>
                  <SelectItem value="despesa">
                    <div className="flex items-center gap-2">
                      <TrendingDown className="w-4 h-4 text-red-400" />
                      Despesa
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-purple-200">Categoria*</Label>
              <Select value={newRule.category} onValueChange={(v) => setNewRule({ ...newRule, category: v })}>
                <SelectTrigger className="bg-purple-950/50 border-purple-700 text-white">
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent className="bg-purple-900 border-purple-700">
                  {categories.map(cat => (
                    <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-purple-200">Subcategoria</Label>
              <Input
                value={newRule.subcategory}
                onChange={(e) => setNewRule({ ...newRule, subcategory: e.target.value })}
                placeholder="Opcional"
                className="bg-purple-950/50 border-purple-700 text-white"
              />
            </div>

            <div>
              <Label className="text-purple-200">Centro de Custo</Label>
              <Select value={newRule.cost_center} onValueChange={(v) => setNewRule({ ...newRule, cost_center: v })}>
                <SelectTrigger className="bg-purple-950/50 border-purple-700 text-white">
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent className="bg-purple-900 border-purple-700">
                  {costCenters.map(cc => (
                    <SelectItem key={cc.id} value={cc.name}>{cc.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button
            onClick={handleAddRule}
            disabled={saving}
            className="w-full mt-4 bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600"
          >
            {saving ? (
              <>
                <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                Salvando...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Salvar Regra
              </>
            )}
          </Button>
        </div>

        <div>
          <h3 className="text-white font-semibold mb-3">
            Regras Ativas ({sortedLearnings.length})
          </h3>
          <div className="bg-purple-950/30 rounded-lg border border-purple-700 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-purple-950/50 border-purple-700">
                  <TableHead className="text-purple-300">Padrão</TableHead>
                  <TableHead className="text-purple-300">Tipo</TableHead>
                  <TableHead className="text-purple-300">Categoria</TableHead>
                  <TableHead className="text-purple-300">Centro de Custo</TableHead>
                  <TableHead className="text-purple-300">Confiança</TableHead>
                  <TableHead className="text-purple-300">Usos</TableHead>
                  <TableHead className="text-purple-300"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedLearnings.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-purple-300 py-8">
                      Nenhuma regra cadastrada. Adicione regras acima.
                    </TableCell>
                  </TableRow>
                ) : (
                  sortedLearnings.map((learning) => (
                    <TableRow key={learning.id} className="border-purple-700">
                      <TableCell className="text-white font-mono text-sm">
                        "{learning.description_pattern}"
                      </TableCell>
                      <TableCell>
                        <Badge className={learning.transaction_type === "receita" ? "bg-green-500" : "bg-red-500"}>
                          {learning.transaction_type === "receita" ? "Receita" : "Despesa"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-purple-200">
                        {learning.learned_category}
                        {learning.learned_subcategory && (
                          <span className="text-purple-400 text-xs block">
                            → {learning.learned_subcategory}
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="text-purple-200">
                        {learning.learned_cost_center || "-"}
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-purple-500">
                          {learning.confidence_score || 5}/10
                        </Badge>
                      </TableCell>
                      <TableCell className="text-purple-300">
                        {learning.times_used || 0}x
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            if (confirm("Remover esta regra?")) {
                              handleDeleteRule(learning.id);
                            }
                          }}
                          className="text-red-400 hover:bg-red-900/20"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}