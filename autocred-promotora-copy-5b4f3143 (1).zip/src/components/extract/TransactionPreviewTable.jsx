import React, { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import CurrencyInput from "../CurrencyInput";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Sparkles, Edit2, Save, X, TrendingUp, TrendingDown, Trash2, FileText } from "lucide-react";
import { format } from "date-fns";

export default function TransactionPreviewTable({ 
  transactions, 
  onUpdate, 
  categories, 
  costCenters,
  onSaveMapping,
  onDelete,
  onGenerateReceipt
}) {
  const [editingIndex, setEditingIndex] = useState(null);
  const [editData, setEditData] = useState({});

  const handleEdit = (index, transaction) => {
    setEditingIndex(index);
    setEditData(transaction);
  };

  const handleSave = async (index) => {
    const updated = { ...editData, confidence: 10 };
    onUpdate(index, updated);
    
    // Salvar padrão de aprendizado
    if (editData.description && editData.category) {
      const pattern = editData.description.split(' ').slice(0, 3).join(' ').toLowerCase();
      await onSaveMapping({
        pattern: pattern,
        category: editData.category,
        subcategory: editData.subcategory || "",
        cost_center: editData.cost_center || "",
        type: editData.type
      });
    }
    
    setEditingIndex(null);
    setEditData({});
  };

  const handleCancel = () => {
    setEditingIndex(null);
    setEditData({});
  };

  return (
    <div className="max-h-[600px] overflow-auto border border-blue-700 rounded-lg">
      <Table>
        <TableHeader className="sticky top-0 bg-blue-950 z-10">
          <TableRow className="border-blue-700">
            <TableHead className="text-blue-300 w-12"></TableHead>
            <TableHead className="text-blue-300">Data</TableHead>
            <TableHead className="text-blue-300">Descrição</TableHead>
            <TableHead className="text-blue-300">Tipo</TableHead>
            <TableHead className="text-blue-300">Categoria</TableHead>
            <TableHead className="text-blue-300">Centro Custo</TableHead>
            <TableHead className="text-blue-300 text-right">Valor</TableHead>
            <TableHead className="text-blue-300 w-32">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {transactions.map((trans, index) => (
            <TableRow 
              key={index} 
              className={`border-blue-700 ${trans.isDuplicate ? 'opacity-50 bg-yellow-900/20' : ''} ${editingIndex === index ? 'bg-blue-800/30' : ''}`}
            >
              <TableCell>
                {trans.aiSuggested && (
                  <Sparkles className="w-4 h-4 text-purple-400" title="IA sugeriu categoria" />
                )}
              </TableCell>
              <TableCell className="text-white text-sm">
                {editingIndex === index ? (
                  <Input 
                    type="date" 
                    value={editData.date} 
                    onChange={(e) => setEditData({...editData, date: e.target.value})}
                    className="h-8 text-xs bg-blue-950/50 border-blue-700 text-white"
                  />
                ) : (
                  <>
                    {format(new Date(trans.date), "dd/MM/yyyy")}
                    {trans.isDuplicate && (
                      <Badge className="ml-2 bg-yellow-500/20 text-yellow-300 border-yellow-500 text-xs">
                        Duplicado
                      </Badge>
                    )}
                  </>
                )}
              </TableCell>
              <TableCell className="text-blue-100 text-sm max-w-xs">
                {editingIndex === index ? (
                  <Input 
                    value={editData.description} 
                    onChange={(e) => setEditData({...editData, description: e.target.value})}
                    className="h-8 text-xs bg-blue-950/50 border-blue-700 text-white"
                  />
                ) : (
                  <span className="truncate block">{trans.description}</span>
                )}
              </TableCell>
              <TableCell>
                {editingIndex === index ? (
                  <Select 
                    value={editData.type} 
                    onValueChange={(value) => setEditData({...editData, type: value})}
                  >
                    <SelectTrigger className="h-8 text-xs bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      <SelectItem value="receita">Receita</SelectItem>
                      <SelectItem value="despesa">Despesa</SelectItem>
                    </SelectContent>
                  </Select>
                ) : (
                  <Badge className={trans.type === "receita" 
                    ? "bg-green-500/20 text-green-300 border-green-500" 
                    : "bg-red-500/20 text-red-300 border-red-500"
                  }>
                    {trans.type === "receita" ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                    {trans.type === "receita" ? "Receita" : "Despesa"}
                  </Badge>
                )}
              </TableCell>
              <TableCell className="text-blue-200 text-sm">
               {editingIndex === index ? (
                 <Select 
                   value={editData.category} 
                   onValueChange={(value) => setEditData({...editData, category: value})}
                 >
                   <SelectTrigger className="h-8 text-xs bg-blue-950/50 border-blue-700 text-white">
                     <SelectValue />
                   </SelectTrigger>
                   <SelectContent className="bg-blue-900 border-blue-700">
                     {categories.filter(c => c.type === editData.type || c.type === "ambos").map(cat => (
                       <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                     ))}
                   </SelectContent>
                 </Select>
               ) : (
                 <div className="flex items-center gap-2">
                   <span>{trans.category || "-"}</span>
                   {trans.aiSuggested && trans.confidence && (
                     <Badge 
                       variant="outline" 
                       className={`text-xs ${
                         trans.confidence >= 8 ? 'bg-green-500/20 text-green-300 border-green-500' :
                         trans.confidence >= 6 ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500' :
                         'bg-purple-500/20 text-purple-300 border-purple-500'
                       }`}
                     >
                       {trans.confidence}/10
                     </Badge>
                   )}
                 </div>
               )}
              </TableCell>
              <TableCell className="text-blue-200 text-sm">
                {editingIndex === index ? (
                  <Select 
                    value={editData.cost_center} 
                    onValueChange={(value) => setEditData({...editData, cost_center: value})}
                  >
                    <SelectTrigger className="h-8 text-xs bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      {costCenters.map(cc => (
                        <SelectItem key={cc.id} value={cc.name}>{cc.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  trans.cost_center || "-"
                )}
              </TableCell>
              <TableCell className={`font-semibold text-right ${trans.type === "receita" ? "text-green-300" : "text-red-300"}`}>
                {editingIndex === index ? (
                  <CurrencyInput 
                    value={editData.amount} 
                    onValueChange={(val) => setEditData({...editData, amount: val})}
                    className="h-8 text-xs bg-blue-950/50 border-blue-700 text-white"
                  />
                ) : (
                  `R$ ${trans.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`
                )}
              </TableCell>
              <TableCell>
                {editingIndex === index ? (
                  <div className="flex gap-1">
                    <Button size="sm" onClick={() => handleSave(index)} className="h-7 px-2 bg-green-600 hover:bg-green-700">
                      <Save className="w-3 h-3" />
                    </Button>
                    <Button size="sm" variant="ghost" onClick={handleCancel} className="h-7 px-2 text-red-400 hover:bg-red-900/20">
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ) : (
                  <div className="flex gap-1">
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={() => handleEdit(index, trans)}
                      className="h-7 px-2 text-blue-300 hover:bg-blue-700"
                      disabled={trans.isDuplicate}
                      title="Editar"
                    >
                      <Edit2 className="w-3 h-3" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={() => onDelete && onDelete(index)}
                      className="h-7 px-2 text-red-300 hover:bg-red-700"
                      disabled={trans.isDuplicate}
                      title="Excluir"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                    {trans.type === "receita" && onGenerateReceipt && (
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => onGenerateReceipt(trans)}
                        className="h-7 px-2 text-green-300 hover:bg-green-700"
                        disabled={trans.isDuplicate}
                        title="Gerar Recibo"
                      >
                        <FileText className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}