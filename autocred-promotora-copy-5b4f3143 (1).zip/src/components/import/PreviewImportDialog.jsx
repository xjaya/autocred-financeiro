import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CheckCircle, XCircle, Edit2, Sparkles, TrendingUp, TrendingDown } from "lucide-react";
import { format } from "date-fns";

export default function PreviewImportDialog({ 
  open, 
  onClose, 
  transactions, 
  detectedInfo,
  accounts,
  contacts,
  categories,
  costCenters,
  onConfirmImport 
}) {
  const [editedTransactions, setEditedTransactions] = useState(
    transactions.map((t, idx) => ({ ...t, id: idx }))
  );
  const [selectedAccount, setSelectedAccount] = useState(detectedInfo?.account || "");

  const handleEdit = (id, field, value) => {
    setEditedTransactions(prev =>
      prev.map(t => t.id === id ? { ...t, [field]: value } : t)
    );
  };

  const handleConfirm = () => {
    onConfirmImport(editedTransactions, selectedAccount);
  };

  const totalCredito = editedTransactions
    .filter(t => t.type === "receita")
    .reduce((sum, t) => sum + Math.abs(t.amount), 0);

  const totalDebito = editedTransactions
    .filter(t => t.type === "despesa")
    .reduce((sum, t) => sum + Math.abs(t.amount), 0);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto bg-blue-900 border-blue-700 text-white">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2 text-white">
            <Sparkles className="w-6 h-6 text-purple-400" />
            Conferência de Importação
          </DialogTitle>
        </DialogHeader>

        {/* Informações Detectadas */}
        <div className="bg-blue-950/50 p-4 rounded-lg border border-blue-700 space-y-3">
          <h3 className="font-semibold text-blue-200">Informações Detectadas</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {detectedInfo?.bank && (
              <div>
                <p className="text-xs text-blue-400">Banco</p>
                <p className="text-sm font-medium text-white">{detectedInfo.bank}</p>
              </div>
            )}
            {detectedInfo?.agency && (
              <div>
                <p className="text-xs text-blue-400">Agência</p>
                <p className="text-sm font-medium text-white">{detectedInfo.agency}</p>
              </div>
            )}
            {detectedInfo?.accountNumber && (
              <div>
                <p className="text-xs text-blue-400">Conta</p>
                <p className="text-sm font-medium text-white">{detectedInfo.accountNumber}</p>
              </div>
            )}
            {detectedInfo?.holder && (
              <div>
                <p className="text-xs text-blue-400">Titular</p>
                <p className="text-sm font-medium text-white">{detectedInfo.holder}</p>
              </div>
            )}
          </div>
          
          <div>
            <label className="text-sm text-blue-300 mb-2 block">Conta do Sistema*</label>
            <Select value={selectedAccount} onValueChange={setSelectedAccount}>
              <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                <SelectValue placeholder="Selecione a conta" />
              </SelectTrigger>
              <SelectContent className="bg-blue-900 border-blue-700">
                {accounts.map(acc => (
                  <SelectItem key={acc.id} value={acc.name}>
                    {acc.name} - {acc.bank}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Resumo */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-blue-950/50 p-4 rounded-lg border border-blue-700">
            <p className="text-xs text-blue-300">Total de Lançamentos</p>
            <p className="text-2xl font-bold text-white">{editedTransactions.length}</p>
          </div>
          <div className="bg-green-950/50 p-4 rounded-lg border border-green-700">
            <p className="text-xs text-green-300 flex items-center gap-1">
              <TrendingUp className="w-4 h-4" />
              Total Créditos
            </p>
            <p className="text-2xl font-bold text-green-300">
              R$ {totalCredito.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </p>
          </div>
          <div className="bg-red-950/50 p-4 rounded-lg border border-red-700">
            <p className="text-xs text-red-300 flex items-center gap-1">
              <TrendingDown className="w-4 h-4" />
              Total Débitos
            </p>
            <p className="text-2xl font-bold text-red-300">
              R$ {totalDebito.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </p>
          </div>
        </div>

        {/* Tabela de Transações */}
        <div className="border border-blue-700 rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-blue-950/70 border-blue-700">
                <TableHead className="text-blue-300">Data</TableHead>
                <TableHead className="text-blue-300">Descrição</TableHead>
                <TableHead className="text-blue-300">Tipo</TableHead>
                <TableHead className="text-blue-300">Valor</TableHead>
                <TableHead className="text-blue-300">Categoria</TableHead>
                <TableHead className="text-blue-300">Centro de Custo</TableHead>
                <TableHead className="text-blue-300">Cliente/Fornecedor</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {editedTransactions.map((trans) => (
                <TableRow key={trans.id} className={`border-blue-700 ${trans.isDuplicate ? 'bg-yellow-900/30' : ''}`}>
                  <TableCell className="text-white">
                    {trans.isDuplicate && (
                      <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500 text-xs mr-2">
                        Duplicado?
                      </Badge>
                    )}
                    {format(new Date(trans.date), "dd/MM/yyyy")}
                  </TableCell>
                  <TableCell className="max-w-xs">
                    <Input
                      value={trans.description}
                      onChange={(e) => handleEdit(trans.id, "description", e.target.value)}
                      className="bg-blue-950/50 border-blue-700 text-white text-sm"
                    />
                  </TableCell>
                  <TableCell>
                    <Badge className={trans.type === "receita" ? "bg-green-500/20 text-green-300 border-green-500" : "bg-red-500/20 text-red-300 border-red-500"}>
                      {trans.type === "receita" ? "Receita" : "Despesa"}
                    </Badge>
                  </TableCell>
                  <TableCell className={`font-semibold ${trans.type === "receita" ? "text-green-300" : "text-red-300"}`}>
                    R$ {Math.abs(trans.amount).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </TableCell>
                  <TableCell>
                    <Select
                      value={trans.category}
                      onValueChange={(val) => handleEdit(trans.id, "category", val)}
                    >
                      <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white text-xs w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-blue-900 border-blue-700">
                        {categories
                          .filter(c => c.type === trans.type || c.type === "ambos")
                          .map(cat => (
                            <SelectItem key={cat.id} value={cat.name}>
                              {cat.name}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Select
                      value={trans.cost_center}
                      onValueChange={(val) => handleEdit(trans.id, "cost_center", val)}
                    >
                      <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white text-xs w-40">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent className="bg-blue-900 border-blue-700">
                        {costCenters.map(cc => (
                          <SelectItem key={cc.id} value={cc.name}>
                            {cc.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Select
                      value={trans.type === "receita" ? trans.client_name : trans.supplier_name}
                      onValueChange={(val) => handleEdit(trans.id, trans.type === "receita" ? "client_name" : "supplier_name", val)}
                    >
                      <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white text-xs w-40">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent className="bg-blue-900 border-blue-700">
                        {contacts
                          .filter(c => 
                            trans.type === "receita" 
                              ? (c.type === "cliente" || c.type === "ambos")
                              : (c.type === "fornecedor" || c.type === "ambos")
                          )
                          .map(contact => (
                            <SelectItem key={contact.id} value={contact.name}>
                              {contact.name}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Botões de Ação */}
        <div className="flex justify-end gap-3 pt-4 border-t border-blue-700">
          <Button
            variant="outline"
            onClick={onClose}
            className="border-blue-700 text-blue-200 hover:bg-blue-800"
          >
            Cancelar
          </Button>
          <Button
            onClick={handleConfirm}
            disabled={!selectedAccount}
            className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600"
          >
            <CheckCircle className="w-4 h-4 mr-2" />
            Confirmar Importação ({editedTransactions.length} lançamentos)
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}