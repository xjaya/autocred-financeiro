import React, { forwardRef } from "react";
import { Input } from "@/components/ui/input";

const CurrencyInput = forwardRef(({ value, onChange, onValueChange, className, ...props }, ref) => {
  const formatToBRL = (value) => {
    if (!value) return "";
    
    // Remove tudo que não é número
    const numbers = value.replace(/\D/g, "");
    
    if (!numbers) return "";
    
    // Converte para número com centavos
    const amount = parseFloat(numbers) / 100;
    
    // Formata para BRL
    return amount.toLocaleString("pt-BR", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  };

  const handleChange = (e) => {
    const inputValue = e.target.value;
    const formatted = formatToBRL(inputValue);
    
    // Atualiza o valor formatado
    e.target.value = formatted;
    
    if (onChange) {
      onChange(e);
    }
    
    // Se tem callback para valor numérico
    if (onValueChange) {
      const numbers = inputValue.replace(/\D/g, "");
      const numericValue = numbers ? parseFloat(numbers) / 100 : 0;
      onValueChange(numericValue);
    }
  };

  const displayValue = value ? formatToBRL(String(value)) : "";

  return (
    <div className="relative">
      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
        R$
      </span>
      <Input
        ref={ref}
        type="text"
        inputMode="numeric"
        value={displayValue}
        onChange={handleChange}
        className={`pl-10 ${className}`}
        {...props}
      />
    </div>
  );
});

CurrencyInput.displayName = "CurrencyInput";

export default CurrencyInput;