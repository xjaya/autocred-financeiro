import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Brain, Sparkles } from "lucide-react";
import { toast } from "sonner";

export default function AITrainingButton({ transaction, onTrainingComplete }) {
  const [showDialog, setShowDialog] = useState(false);
  const [training, setTraining] = useState(false);
  const [category, setCategory] = useState(transaction.category || "");
  const [subcategory, setSubcategory] = useState(transaction.subcategory || "");
  const [costCenter, setCostCenter] = useState(transaction.cost_center || "");
  const [supplier, setSupplier] = useState(transaction.supplier_name || transaction.client_name || "");

  const handleTrain = async () => {
    if (!category) {
      toast.error("Selecione uma categoria!");
      return;
    }

    setTraining(true);
    try {
      // Extrair palavras-chave da descrição
      const descriptionPattern = transaction.description
        .toLowerCase()
        .split(/\s+/)
        .filter(word => word.length > 3)
        .slice(0, 3)
        .join(" ");

      // Verificar se já existe aprendizado similar
      const existingLearnings = await base44.entities.AILearning.list();
      const similar = existingLearnings.find(l => 
        l.description_pattern.toLowerCase() === descriptionPattern.toLowerCase()
      );

      if (similar) {
        // Atualizar aprendizado existente
        await base44.entities.AILearning.update(similar.id, {
          learned_category: category,
          learned_subcategory: subcategory,
          learned_cost_center: costCenter,
          learned_supplier: supplier,
          times_used: (similar.times_used || 0) + 1,
          confidence_score: Math.min((similar.confidence_score || 1) + 0.5, 10),
          last_used: new Date().toISOString()
        });
      } else {
        // Criar novo aprendizado
        await base44.entities.AILearning.create({
          description_pattern: descriptionPattern,
          learned_category: category,
          learned_subcategory: subcategory,
          learned_cost_center: costCenter,
          learned_supplier: supplier,
          transaction_type: transaction.type,
          confidence_score: 1,
          times_used: 1,
          last_used: new Date().toISOString()
        });
      }

      // Atualizar a transação atual
      await base44.entities.Transaction.update(transaction.id, {
        category,
        subcategory,
        cost_center: costCenter,
        supplier_name: transaction.type === "despesa" ? supplier : transaction.supplier_name,
        client_name: transaction.type === "receita" ? supplier : transaction.client_name
      });

      toast.success("🤖 IA treinada com sucesso! Ela usará isso em futuras importações.");
      setShowDialog(false);
      if (onTrainingComplete) onTrainingComplete();
    } catch (error) {
      console.error("Erro ao treinar IA:", error);
      toast.error("Erro ao treinar a IA");
    }
    setTraining(false);
  };

  return (
    <>
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogTrigger asChild>
          <Button
            size="sm"
            variant="ghost"
            className="text-purple-400 hover:text-white hover:bg-purple-700"
            title="Treinar IA com esta categorização"
          >
            <Brain className="w-4 h-4" />
          </Button>
        </DialogTrigger>
        <DialogContent className="bg-blue-900 border-blue-700 text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-white">
              <Brain className="w-5 h-5 text-purple-400" />
              Treinar IA para Categorização
            </DialogTitle>
            <p className="text-sm text-blue-300 mt-2">
              Ensine a IA a categorizar "{transaction.description}" automaticamente
            </p>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div>
              <Label className="text-blue-200">Categoria*</Label>
              <Input
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="Ex: Marketing"
                className="bg-blue-950/50 border-blue-700 text-white"
              />
            </div>

            <div>
              <Label className="text-blue-200">Subcategoria</Label>
              <Input
                value={subcategory}
                onChange={(e) => setSubcategory(e.target.value)}
                placeholder="Ex: Google Ads"
                className="bg-blue-950/50 border-blue-700 text-white"
              />
            </div>

            <div>
              <Label className="text-blue-200">Centro de Custo</Label>
              <Input
                value={costCenter}
                onChange={(e) => setCostCenter(e.target.value)}
                placeholder="Ex: Comercial"
                className="bg-blue-950/50 border-blue-700 text-white"
              />
            </div>

            <div>
              <Label className="text-blue-200">
                {transaction.type === "receita" ? "Cliente" : "Fornecedor"}
              </Label>
              <Input
                value={supplier}
                onChange={(e) => setSupplier(e.target.value)}
                placeholder={transaction.type === "receita" ? "Nome do cliente" : "Nome do fornecedor"}
                className="bg-blue-950/50 border-blue-700 text-white"
              />
            </div>

            <div className="bg-purple-950/30 border border-purple-700 rounded-lg p-3">
              <p className="text-xs text-purple-300">
                💡 A IA aprenderá este padrão e aplicará automaticamente em futuras importações com descrições similares.
              </p>
            </div>

            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => setShowDialog(false)}
                className="border-blue-700 text-blue-200 hover:bg-blue-800"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleTrain}
                disabled={training || !category}
                className="bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600"
              >
                {training ? (
                  <>
                    <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                    Treinando...
                  </>
                ) : (
                  <>
                    <Brain className="w-4 h-4 mr-2" />
                    Treinar IA
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}