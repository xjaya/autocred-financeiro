import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Brain, Sparkles, Trash2, TrendingUp, Target, Edit2 } from "lucide-react";
import { toast } from "sonner";

export default function AITrainingPanel() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingLearning, setEditingLearning] = useState(null);

  const queryClient = useQueryClient();

  const { data: learnings = [] } = useQuery({
    queryKey: ["aiLearnings"],
    queryFn: () => base44.entities.AILearning.list("-times_used"),
    initialData: [],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list(),
    initialData: [],
  });

  const { data: costCenters = [] } = useQuery({
    queryKey: ["costCenters"],
    queryFn: () => base44.entities.CostCenter.list(),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.AILearning.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["aiLearnings"] });
      setShowDialog(false);
      setEditingLearning(null);
      toast.success("✅ Padrão de IA treinado com sucesso!");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.AILearning.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["aiLearnings"] });
      setShowDialog(false);
      setEditingLearning(null);
      toast.success("✅ Padrão atualizado!");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.AILearning.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["aiLearnings"] });
      toast.success("Padrão removido!");
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    const data = {
      description_pattern: formData.get("description_pattern"),
      learned_category: formData.get("learned_category"),
      learned_subcategory: formData.get("learned_subcategory") || null,
      learned_cost_center: formData.get("learned_cost_center") || null,
      learned_supplier: formData.get("learned_supplier") || null,
      transaction_type: formData.get("transaction_type"),
      confidence_score: 10,
      times_used: 0,
    };

    if (editingLearning) {
      updateMutation.mutate({ id: editingLearning.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const totalLearnings = learnings.length;
  const totalUsages = learnings.reduce((sum, l) => sum + (l.times_used || 0), 0);
  const avgConfidence = learnings.length > 0 
    ? (learnings.reduce((sum, l) => sum + (l.confidence_score || 0), 0) / learnings.length).toFixed(1)
    : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Brain className="w-6 h-6 text-purple-400" />
            Treinamento de IA
          </h2>
          <p className="text-blue-200 text-sm mt-1">
            Ensine a IA a categorizar transações automaticamente
          </p>
        </div>
        <Button
          onClick={() => {
            setEditingLearning(null);
            setShowDialog(true);
          }}
          className="bg-gradient-to-r from-purple-600 to-purple-500"
        >
          <Sparkles className="w-4 h-4 mr-2" />
          Novo Padrão
        </Button>
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="border-purple-700/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-300">Padrões Treinados</p>
                <p className="text-3xl font-bold text-white mt-1">{totalLearnings}</p>
              </div>
              <Target className="w-10 h-10 text-purple-400 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-300">Vezes Utilizados</p>
                <p className="text-3xl font-bold text-white mt-1">{totalUsages}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-blue-400 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-700/50 bg-gradient-to-br from-green-900/80 to-green-800/80">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-300">Confiança Média</p>
                <p className="text-3xl font-bold text-white mt-1">{avgConfidence}/10</p>
              </div>
              <Sparkles className="w-10 h-10 text-green-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabela de Padrões */}
      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white">Padrões Aprendidos</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-blue-700">
                <TableHead className="text-blue-300">Padrão de Descrição</TableHead>
                <TableHead className="text-blue-300">Tipo</TableHead>
                <TableHead className="text-blue-300">Categoria</TableHead>
                <TableHead className="text-blue-300">Centro de Custo</TableHead>
                <TableHead className="text-blue-300">Usos</TableHead>
                <TableHead className="text-blue-300">Confiança</TableHead>
                <TableHead className="text-right text-blue-300">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {learnings.map((learning) => (
                <TableRow key={learning.id} className="border-blue-700">
                  <TableCell className="text-white font-medium max-w-xs truncate">
                    {learning.description_pattern}
                  </TableCell>
                  <TableCell>
                    <Badge className={learning.transaction_type === "receita" 
                      ? "bg-green-500/20 text-green-300 border-green-500"
                      : "bg-red-500/20 text-red-300 border-red-500"
                    }>
                      {learning.transaction_type === "receita" ? "Receita" : "Despesa"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-blue-200">{learning.learned_category}</TableCell>
                  <TableCell className="text-blue-200 text-sm">
                    {learning.learned_cost_center || "-"}
                  </TableCell>
                  <TableCell className="text-white font-medium">
                    {learning.times_used || 0}x
                  </TableCell>
                  <TableCell>
                    <Badge className="bg-purple-500/20 text-purple-300 border-purple-500">
                      {learning.confidence_score || 0}/10
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setEditingLearning(learning);
                          setShowDialog(true);
                        }}
                        className="text-blue-400 hover:bg-blue-900/20"
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          if (confirm("Remover este padrão?")) {
                            deleteMutation.mutate(learning.id);
                          }
                        }}
                        className="text-red-400 hover:bg-red-900/20"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {learnings.length === 0 && (
            <div className="text-center py-12">
              <Brain className="w-16 h-16 text-blue-400 mx-auto mb-4 opacity-50" />
              <p className="text-blue-200">Nenhum padrão treinado ainda</p>
              <p className="text-sm text-blue-300 mt-1">
                Crie padrões para a IA aprender a categorizar automaticamente
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dialog de Criação/Edição */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-blue-900 border-blue-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-white">
              {editingLearning ? "Editar Padrão" : "Novo Padrão de IA"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-blue-200 text-sm mb-2 block">Padrão de Descrição*</label>
              <Input
                name="description_pattern"
                defaultValue={editingLearning?.description_pattern}
                placeholder="Ex: PIX ENVIADO, COMPRA CARTAO, etc."
                required
                className="bg-blue-950/50 border-blue-700 text-white"
              />
              <p className="text-xs text-blue-400 mt-1">
                Use palavras-chave que aparecem nas descrições das transações
              </p>
            </div>

            <div>
              <label className="text-blue-200 text-sm mb-2 block">Tipo de Transação*</label>
              <Select name="transaction_type" defaultValue={editingLearning?.transaction_type || "despesa"} required>
                <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-blue-900 border-blue-700">
                  <SelectItem value="receita">Receita</SelectItem>
                  <SelectItem value="despesa">Despesa</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-blue-200 text-sm mb-2 block">Categoria*</label>
              <Select name="learned_category" defaultValue={editingLearning?.learned_category} required>
                <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                  <SelectValue placeholder="Selecione a categoria" />
                </SelectTrigger>
                <SelectContent className="bg-blue-900 border-blue-700">
                  {categories.map(cat => (
                    <SelectItem key={cat.id} value={cat.name}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-blue-200 text-sm mb-2 block">Subcategoria</label>
              <Input
                name="learned_subcategory"
                defaultValue={editingLearning?.learned_subcategory}
                placeholder="Ex: Anúncios Online"
                className="bg-blue-950/50 border-blue-700 text-white"
              />
            </div>

            <div>
              <label className="text-blue-200 text-sm mb-2 block">Centro de Custo</label>
              <Select name="learned_cost_center" defaultValue={editingLearning?.learned_cost_center}>
                <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent className="bg-blue-900 border-blue-700">
                  {costCenters.map(cc => (
                    <SelectItem key={cc.id} value={cc.name}>
                      {cc.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-blue-200 text-sm mb-2 block">Fornecedor/Cliente</label>
              <Input
                name="learned_supplier"
                defaultValue={editingLearning?.learned_supplier}
                placeholder="Nome do fornecedor ou cliente"
                className="bg-blue-950/50 border-blue-700 text-white"
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowDialog(false)}
                className="flex-1 border-blue-700 text-blue-200"
              >
                Cancelar
              </Button>
              <Button type="submit" className="flex-1 bg-gradient-to-r from-purple-600 to-purple-500">
                {editingLearning ? "Atualizar" : "Criar Padrão"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}