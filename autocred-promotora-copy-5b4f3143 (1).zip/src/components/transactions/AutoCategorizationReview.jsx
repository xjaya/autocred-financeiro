import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle, X, Brain, TrendingUp, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function AutoCategorizationReview({ transaction, categories, costCenters, onCorrect, onApprove }) {
  const [editing, setEditing] = useState(false);
  const [category, setCategory] = useState(transaction.category);
  const [subcategory, setSubcategory] = useState(transaction.subcategory || "");
  const [costCenter, setCostCenter] = useState(transaction.cost_center || "");
  
  const queryClient = useQueryClient();

  const learnMutation = useMutation({
    mutationFn: async (data) => {
      const pattern = transaction.description.split(' ').slice(0, 3).join(' ').toLowerCase();
      
      // Buscar padrão existente
      const existing = await base44.entities.AILearning.list();
      const found = existing.find(l => 
        l.description_pattern === pattern && 
        l.transaction_type === transaction.type
      );

      if (found) {
        // Atualizar padrão existente
        return await base44.entities.AILearning.update(found.id, {
          learned_category: data.category,
          learned_subcategory: data.subcategory,
          learned_cost_center: data.cost_center,
          times_used: (found.times_used || 0) + 1,
          confidence_score: Math.min((found.confidence_score || 5) + 0.5, 10),
          last_used: new Date().toISOString()
        });
      } else {
        // Criar novo padrão
        return await base44.entities.AILearning.create({
          description_pattern: pattern,
          learned_category: data.category,
          learned_subcategory: data.subcategory,
          learned_cost_center: data.cost_center,
          transaction_type: transaction.type,
          confidence_score: 7,
          times_used: 1,
          last_used: new Date().toISOString()
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["aiLearnings"] });
      toast.success("🧠 IA aprendeu com sua correção!");
    }
  });

  const handleApprove = async () => {
    await learnMutation.mutateAsync({
      category: transaction.category,
      subcategory: transaction.subcategory,
      cost_center: transaction.cost_center
    });
    onApprove && onApprove();
  };

  const handleCorrect = async () => {
    await learnMutation.mutateAsync({
      category,
      subcategory,
      cost_center
    });
    onCorrect && onCorrect({ category, subcategory, cost_center });
    setEditing(false);
  };

  const confidenceColor = transaction.aiSuggested 
    ? transaction.confidence >= 8 ? "bg-green-500" 
      : transaction.confidence >= 6 ? "bg-yellow-500" 
      : "bg-red-500"
    : "bg-gray-500";

  return (
    <Card className="border-purple-700/50 bg-gradient-to-br from-purple-900/30 to-purple-800/30">
      <CardHeader>
        <CardTitle className="text-white text-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="w-4 h-4 text-purple-400" />
            Revisão de Categorização Automática
          </div>
          {transaction.aiSuggested && (
            <Badge className={`${confidenceColor} text-white text-xs`}>
              IA: {transaction.confidence}/10
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-purple-950/30 p-3 rounded-lg border border-purple-700">
          <p className="text-purple-200 text-xs mb-1">Descrição:</p>
          <p className="text-white font-medium text-sm">{transaction.description}</p>
        </div>

        {!editing ? (
          <div className="space-y-3">
            <div className="grid grid-cols-3 gap-2">
              <div>
                <p className="text-purple-300 text-xs mb-1">Categoria:</p>
                <Badge className="bg-blue-500 text-white">{transaction.category}</Badge>
              </div>
              {transaction.subcategory && (
                <div>
                  <p className="text-purple-300 text-xs mb-1">Subcategoria:</p>
                  <Badge className="bg-blue-400 text-white">{transaction.subcategory}</Badge>
                </div>
              )}
              {transaction.cost_center && (
                <div>
                  <p className="text-purple-300 text-xs mb-1">Centro de Custo:</p>
                  <Badge className="bg-indigo-500 text-white">{transaction.cost_center}</Badge>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={handleApprove}
                className="flex-1 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600"
              >
                <CheckCircle className="w-4 h-4 mr-1" />
                Aprovar
              </Button>
              <Button
                size="sm"
                onClick={() => setEditing(true)}
                variant="outline"
                className="flex-1 border-orange-500 text-orange-300 hover:bg-orange-900/20"
              >
                <AlertCircle className="w-4 h-4 mr-1" />
                Corrigir
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div>
              <label className="text-purple-200 text-xs mb-1 block">Categoria</label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="bg-purple-950/50 border-purple-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-purple-900 border-purple-700">
                  {categories.map(cat => (
                    <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-purple-200 text-xs mb-1 block">Centro de Custo</label>
              <Select value={costCenter} onValueChange={setCostCenter}>
                <SelectTrigger className="bg-purple-950/50 border-purple-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-purple-900 border-purple-700">
                  {costCenters.map(cc => (
                    <SelectItem key={cc.id} value={cc.name}>{cc.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={handleCorrect}
                className="flex-1 bg-gradient-to-r from-green-600 to-green-500"
              >
                <CheckCircle className="w-4 h-4 mr-1" />
                Salvar e Ensinar IA
              </Button>
              <Button
                size="sm"
                onClick={() => setEditing(false)}
                variant="outline"
                className="border-red-500 text-red-300"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}