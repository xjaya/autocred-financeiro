import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export const sendWhatsAppMessage = async (phoneNumber, message) => {
  try {
    if (!phoneNumber) {
      throw new Error("Número WhatsApp não configurado");
    }

    // Limpar número (remover espaços, caracteres especiais)
    const cleanPhone = phoneNumber.replace(/\D/g, "");
    
    if (cleanPhone.length < 10) {
      throw new Error("Número WhatsApp inválido");
    }

    // Enviar via API do WhatsApp (usando link direto)
    const whatsappURL = `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(message)}`;
    
    // Abrir WhatsApp em nova aba
    window.open(whatsappURL, '_blank');
    
    // Registrar notificação no sistema
    await base44.entities.Notification.create({
      title: "Mensagem WhatsApp",
      message: message.substring(0, 200),
      type: "info",
      status: "enviada",
      recipient_phone: phoneNumber,
      send_via: ["whatsapp"],
      sent_date: new Date().toISOString()
    });

    toast.success("✅ WhatsApp aberto! Envie a mensagem.");
    return true;
  } catch (error) {
    console.error("Erro ao enviar WhatsApp:", error);
    toast.error(`❌ ${error.message}`);
    return false;
  }
};

export const sendWhatsAppReport = async (phoneNumber, reportTitle, summary) => {
  const message = `🏦 *${reportTitle}*

📊 *RESUMO FINANCEIRO*

${summary.receitas !== undefined ? `💰 Receitas: R$ ${summary.receitas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : ''}

${summary.despesas !== undefined ? `💸 Despesas: R$ ${summary.despesas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : ''}

${summary.saldo !== undefined ? `📈 Saldo: R$ ${summary.saldo.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : ''}

${summary.pendentes !== undefined ? `⏳ Pendentes: R$ ${summary.pendentes.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : ''}

---
_Relatório gerado automaticamente_
_AUTOCRED PROMOTORA_`;

  return await sendWhatsAppMessage(phoneNumber, message);
};

export const sendDailyGoalsSummary = async (phoneNumber, goals) => {
  if (!goals || goals.length === 0) {
    return;
  }

  let message = `🎯 *RESUMO DIÁRIO DE METAS*\n\n`;
  
  goals.forEach((goal, index) => {
    const progress = goal.progress_percentage || 0;
    const emoji = progress >= 100 ? '✅' : progress >= 75 ? '🟢' : progress >= 50 ? '🟡' : '🔴';
    
    message += `${emoji} *${goal.name}*\n`;
    message += `   Progresso: ${progress.toFixed(1)}%\n`;
    message += `   Meta: R$ ${goal.target_value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}\n`;
    message += `   Atual: R$ ${(goal.current_value || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}\n\n`;
  });

  message += `---\n_Relatório automático do dia ${new Date().toLocaleDateString('pt-BR')}_`;

  return await sendWhatsAppMessage(phoneNumber, message);
};