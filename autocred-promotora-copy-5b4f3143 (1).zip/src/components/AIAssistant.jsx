import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { base44 } from "@/api/base44Client";
import { Sparkles, Send, X, MessageCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function AIAssistant({ context = "", pageInfo = "" }) {
  const [isOpen, setIsOpen] = useState(false);
  const [question, setQuestion] = useState("");
  const [response, setResponse] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleAsk = async () => {
    if (!question.trim()) return;

    setLoading(true);
    setResponse(null);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Você é um assistente financeiro especializado da AUTOCRED PROMOTORA.

CONTEXTO DA PÁGINA: ${pageInfo}
DADOS RELEVANTES: ${context}

PERGUNTA DO USUÁRIO: ${question}

Forneça uma resposta clara, objetiva e profissional em português brasileiro.`
      });

      setResponse(result);
      setQuestion("");
    } catch (error) {
      console.error("Erro ao consultar IA:", error);
      setResponse("Desculpe, ocorreu um erro. Por favor, tente novamente.");
    }
    setLoading(false);
  };

  return (
    <>
      {/* Botão Flutuante */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <Button
              onClick={() => setIsOpen(true)}
              className="h-14 w-14 rounded-full bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600 shadow-2xl shadow-purple-500/50 hover:shadow-purple-500/70 transition-all"
            >
              <Sparkles className="w-6 h-6" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Painel do Assistente */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 w-96 max-w-[calc(100vw-3rem)]"
          >
            <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/95 to-blue-900/95 backdrop-blur-xl shadow-2xl">
              <CardHeader className="border-b border-purple-700/50 pb-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-purple-100 flex items-center gap-2">
                    <MessageCircle className="w-5 h-5 text-purple-400" />
                    Assistente IA
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setIsOpen(false)}
                    className="text-purple-300 hover:text-white hover:bg-purple-800"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-purple-300 mt-1">
                  Pergunte qualquer coisa sobre suas finanças
                </p>
              </CardHeader>
              <CardContent className="pt-4 space-y-4">
                {response && (
                  <div className="bg-purple-950/50 p-4 rounded-lg border border-purple-700 max-h-60 overflow-y-auto">
                    <p className="text-sm text-purple-100 whitespace-pre-wrap leading-relaxed">
                      {response}
                    </p>
                  </div>
                )}

                <div className="space-y-2">
                  <Textarea
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    placeholder="Ex: Como está meu fluxo de caixa este mês?"
                    rows={3}
                    className="bg-purple-950/50 border-purple-700 text-white placeholder:text-purple-400"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleAsk();
                      }
                    }}
                  />
                  <Button
                    onClick={handleAsk}
                    disabled={loading || !question.trim()}
                    className="w-full bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600"
                  >
                    {loading ? (
                      <>
                        <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                        Pensando...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Perguntar
                      </>
                    )}
                  </Button>
                </div>

                <div className="border-t border-purple-700/50 pt-3">
                  <p className="text-xs text-purple-300 font-medium mb-2">Sugestões de perguntas:</p>
                  <div className="space-y-1">
                    {[
                      "Como posso reduzir custos?",
                      "Quais são minhas maiores despesas?",
                      "Como está minha lucratividade?",
                      "Dicas para melhorar fluxo de caixa",
                    ].map((suggestion, i) => (
                      <button
                        key={i}
                        onClick={() => setQuestion(suggestion)}
                        className="text-xs text-purple-300 hover:text-white bg-purple-950/30 hover:bg-purple-800 px-3 py-1.5 rounded-lg transition-all w-full text-left"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}