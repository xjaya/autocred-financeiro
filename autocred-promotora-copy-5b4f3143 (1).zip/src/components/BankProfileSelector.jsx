import React from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Landmark } from "lucide-react";

const BANK_PROFILES = {
  santander: {
    name: "Santander",
    dateFormat: "extenso", // "Segunda, 29 de outubro de 2025"
    columnsHint: "Data | Histórico | Valor | Tipo",
    identifiers: ["SANTANDER", "033"]
  },
  itau: {
    name: "Itaú",
    dateFormat: "dd/MM/yyyy",
    columnsHint: "Data | Lançamento | Valor | Saldo",
    identifiers: ["ITAU", "341"]
  },
  bradesco: {
    name: "Bradesco",
    dateFormat: "dd/MM/yyyy",
    columnsHint: "Data | Histórico | Docto | Valor | Saldo",
    identifiers: ["BRADESCO", "237"]
  },
  bb: {
    name: "Banco do Brasil",
    dateFormat: "dd/MM/yyyy",
    columnsHint: "Data | Histórico | Nr Docto | Valor | Saldo",
    identifiers: ["BANCO DO BRASIL", "001"]
  },
  caixa: {
    name: "Caixa Econômica",
    dateFormat: "dd/MM/yyyy",
    columnsHint: "Data | Histórico | Valor | Saldo",
    identifiers: ["CAIXA", "104"]
  },
  nubank: {
    name: "Nubank",
    dateFormat: "dd MMM",
    columnsHint: "Data | Descrição | Categoria | Valor",
    identifiers: ["NUBANK", "260"]
  },
  inter: {
    name: "Banco Inter",
    dateFormat: "dd/MM/yyyy",
    columnsHint: "Data | Descrição | Valor",
    identifiers: ["INTER", "077"]
  },
  custom: {
    name: "Personalizado",
    dateFormat: "dd/MM/yyyy",
    columnsHint: "Configuração manual",
    identifiers: []
  }
};

export default function BankProfileSelector({ value, onChange }) {
  return (
    <div className="space-y-3">
      <Label className="text-blue-200">Perfil do Banco</Label>
      <Select value={value || "santander"} onValueChange={onChange}>
        <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
          <SelectValue placeholder="Selecione o banco do extrato" />
        </SelectTrigger>
        <SelectContent className="bg-blue-900 border-blue-700">
          {Object.entries(BANK_PROFILES).map(([key, profile]) => (
            <SelectItem key={key} value={key}>
              <div className="flex items-center gap-2">
                <Landmark className="w-4 h-4" />
                <span>{profile.name}</span>
                <Badge variant="outline" className="text-xs ml-2">
                  {profile.dateFormat}
                </Badge>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {value && BANK_PROFILES[value] && (
        <div className="bg-blue-950/50 p-3 rounded-lg text-xs">
          <p className="text-blue-300 mb-1">Formato esperado:</p>
          <p className="text-blue-100 font-mono">{BANK_PROFILES[value].columnsHint}</p>
        </div>
      )}
    </div>
  );
}

export { BANK_PROFILES };