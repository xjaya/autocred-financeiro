import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Sparkles, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  CheckCircle,
  Target,
  Brain,
  Zap,
  Shield,
  DollarSign,
  Calendar,
  Users,
  PieChart,
  BarChart3,
  Activity,
  RefreshCw
} from "lucide-react";
import { motion } from "framer-motion";

export default function AdvancedAIAnalysis({ transactions }) {
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);

  useEffect(() => {
    if (transactions && transactions.length > 0 && autoRefresh && !analysis) {
      generateAnalysis();
    }
  }, [transactions]);

  const generateAnalysis = async () => {
    if (!transactions || transactions.length === 0) return;
    
    setLoading(true);
    try {
      const totalReceitas = transactions.filter(t => t.type === "receita" && t.status === "pago").reduce((s, t) => s + (t.amount || 0), 0);
      const totalDespesas = transactions.filter(t => t.type === "despesa" && t.status === "pago").reduce((s, t) => s + (t.amount || 0), 0);
      const saldo = totalReceitas - totalDespesas;

      // Análise por categoria
      const categorias = {};
      transactions.forEach(t => {
        if (t.category && t.status === "pago" && t.amount) {
          categorias[t.category] = (categorias[t.category] || 0) + t.amount;
        }
      });

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Você é um analista financeiro sênior da AUTOCRED PROMOTORA. Analise PROFUNDAMENTE estes dados:

📊 DADOS FINANCEIROS:
- Total Transações: ${transactions.length}
- Receitas: R$ ${totalReceitas.toFixed(2)}
- Despesas: R$ ${totalDespesas.toFixed(2)}
- Saldo: R$ ${saldo.toFixed(2)}
- Margem: ${totalReceitas > 0 ? ((saldo / totalReceitas) * 100).toFixed(1) : 0}%

📈 CATEGORIAS (Top 5):
${Object.entries(categorias).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([cat, val]) => `- ${cat}: R$ ${val.toFixed(2)}`).join('\n')}

Forneça uma análise SUPER DETALHADA em JSON com EXATAMENTE estas 30+ análises:`,
        response_json_schema: {
          type: "object",
          properties: {
            saude_financeira: { type: "object", properties: { score: { type: "number" }, status: { type: "string" }, descricao: { type: "string" } } },
            fluxo_caixa: { type: "object", properties: { tendencia: { type: "string" }, previsao_30_dias: { type: "string" }, alerta: { type: "string" } } },
            analise_receitas: { type: "object", properties: { crescimento: { type: "string" }, fontes_principais: { type: "array", items: { type: "string" } }, oportunidades: { type: "array", items: { type: "string" } } } },
            analise_despesas: { type: "object", properties: { eficiencia: { type: "string" }, areas_otimizacao: { type: "array", items: { type: "string" } }, gastos_desnecessarios: { type: "array", items: { type: "string" } } } },
            lucratividade: { type: "object", properties: { margem_atual: { type: "number" }, comparacao: { type: "string" }, sugestoes_melhoria: { type: "array", items: { type: "string" } } } },
            gestao_categorias: { type: "object", properties: { melhor_categoria: { type: "string" }, pior_categoria: { type: "string" }, recomendacoes: { type: "array", items: { type: "string" } } } },
            alertas_criticos: { type: "array", items: { type: "object", properties: { tipo: { type: "string" }, mensagem: { type: "string" }, prioridade: { type: "string" } } } },
            oportunidades: { type: "array", items: { type: "object", properties: { titulo: { type: "string" }, descricao: { type: "string" }, impacto: { type: "string" } } } },
            riscos_identificados: { type: "array", items: { type: "object", properties: { risco: { type: "string" }, probabilidade: { type: "string" }, mitigacao: { type: "string" } } } },
            eficiencia_operacional: { type: "object", properties: { score: { type: "number" }, areas_melhoria: { type: "array", items: { type: "string" } } } },
            analise_fornecedores: { type: "object", properties: { mais_caros: { type: "array", items: { type: "string" } }, sugestoes_negociacao: { type: "array", items: { type: "string" } } } },
            planejamento_tributario: { type: "object", properties: { economia_possivel: { type: "string" }, estrategias: { type: "array", items: { type: "string" } } } },
            capital_giro: { type: "object", properties: { situacao: { type: "string" }, recomendacoes: { type: "array", items: { type: "string" } } } },
            analise_sazonalidade: { type: "object", properties: { periodos_fortes: { type: "array", items: { type: "string" } }, periodos_fracos: { type: "array", items: { type: "string" } } } },
            benchmarking: { type: "object", properties: { comparacao_mercado: { type: "string" }, posicionamento: { type: "string" } } },
            investimentos_sugeridos: { type: "array", items: { type: "object", properties: { area: { type: "string" }, valor_sugerido: { type: "string" }, roi_esperado: { type: "string" } } } },
            acoes_imediatas: { type: "array", items: { type: "string" } },
            estrategias_medio_prazo: { type: "array", items: { type: "string" } },
            visao_longo_prazo: { type: "array", items: { type: "string" } },
            kpis_monitorar: { type: "array", items: { type: "string" } }
          }
        }
      });

      setAnalysis(result);
    } catch (error) {
      console.error("Erro na análise:", error);
    }
    setLoading(false);
  };

  if (!analysis && !loading) {
    return (
      <Card className="border-purple-700/50 bg-gradient-to-br from-purple-900/90 via-blue-900/90 to-indigo-900/90 backdrop-blur-xl shadow-2xl">
        <CardContent className="py-12">
          <div className="text-center">
            <Brain className="w-16 h-16 text-purple-400 mx-auto mb-4 animate-pulse" />
            <p className="text-white text-lg mb-4">Análise de IA Avançada Disponível</p>
            <Button
              onClick={generateAnalysis}
              className="bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Gerar Análise Completa
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="border-purple-700/50 bg-gradient-to-br from-purple-900/90 via-blue-900/90 to-indigo-900/90">
        <CardContent className="py-12">
          <div className="text-center">
            <Sparkles className="w-12 h-12 text-purple-400 mx-auto mb-4 animate-spin" />
            <p className="text-white">Processando análise avançada com IA...</p>
            <p className="text-purple-300 text-sm mt-2">Analisando mais de 30 indicadores...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getSaudeColor = (score) => {
    if (score >= 80) return "text-green-400";
    if (score >= 60) return "text-yellow-400";
    return "text-red-400";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="border-purple-700/50 bg-gradient-to-r from-purple-900/90 via-indigo-900/90 to-blue-900/90 backdrop-blur-xl shadow-2xl">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl text-white flex items-center gap-3">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              >
                <Brain className="w-8 h-8 text-purple-400" />
              </motion.div>
              Análise de IA Avançada - 30+ Indicadores
            </CardTitle>
            <Button
              size="sm"
              variant="outline"
              onClick={generateAnalysis}
              disabled={loading}
              className="border-purple-600 text-purple-300 hover:bg-purple-800"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Atualizar
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Saúde Financeira */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="border-purple-700/50 bg-gradient-to-br from-purple-900/80 to-blue-900/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-purple-400" />
              Saúde Financeira Geral
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-6">
              <div className="text-center">
                <div className={`text-6xl font-bold ${getSaudeColor(analysis.saude_financeira?.score || 0)}`}>
                  {analysis.saude_financeira?.score || 0}
                </div>
                <p className="text-purple-300 text-sm mt-2">{analysis.saude_financeira?.status}</p>
              </div>
              <div className="flex-1">
                <p className="text-purple-100">{analysis.saude_financeira?.descricao}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Fluxo de Caixa */}
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-indigo-900/80 h-full">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-400" />
                Fluxo de Caixa
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-xs text-blue-300">Tendência</p>
                <p className="text-white font-semibold">{analysis.fluxo_caixa?.tendencia}</p>
              </div>
              <div>
                <p className="text-xs text-blue-300">Previsão 30 Dias</p>
                <p className="text-white">{analysis.fluxo_caixa?.previsao_30_dias}</p>
              </div>
              {analysis.fluxo_caixa?.alerta && (
                <Badge className="bg-yellow-500/20 text-yellow-300">
                  <AlertTriangle className="w-3 h-3 mr-1" />
                  {analysis.fluxo_caixa.alerta}
                </Badge>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Lucratividade */}
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
          <Card className="border-green-700/50 bg-gradient-to-br from-green-900/80 to-emerald-900/80 h-full">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-green-400" />
                Lucratividade
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-xs text-green-300">Margem Atual</p>
                <p className="text-3xl font-bold text-white">{analysis.lucratividade?.margem_atual}%</p>
              </div>
              <div>
                <p className="text-xs text-green-300">Comparação</p>
                <p className="text-white text-sm">{analysis.lucratividade?.comparacao}</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Alertas Críticos */}
      {analysis.alertas_criticos?.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="border-red-700/50 bg-gradient-to-br from-red-900/80 to-orange-900/80">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-400" />
                Alertas Críticos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {analysis.alertas_criticos.map((alerta, i) => (
                  <div key={i} className="bg-red-950/30 p-4 rounded-lg border border-red-700">
                    <div className="flex items-start gap-3">
                      <Badge className={`${alerta.prioridade === "alta" ? "bg-red-500" : "bg-yellow-500"}`}>
                        {alerta.prioridade}
                      </Badge>
                      <div className="flex-1">
                        <p className="text-white font-semibold">{alerta.tipo}</p>
                        <p className="text-red-200 text-sm mt-1">{alerta.mensagem}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Oportunidades */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
        <Card className="border-green-700/50 bg-gradient-to-br from-emerald-900/80 to-teal-900/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Target className="w-5 h-5 text-green-400" />
              Oportunidades Identificadas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {analysis.oportunidades?.map((op, i) => (
                <div key={i} className="bg-green-950/30 p-4 rounded-lg border border-green-700">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <p className="text-white font-semibold">{op.titulo}</p>
                      <p className="text-green-200 text-sm mt-1">{op.descricao}</p>
                    </div>
                    <Badge className="bg-green-500/20 text-green-300">
                      {op.impacto}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Ações Recomendadas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Card className="border-purple-700/50 bg-gradient-to-br from-purple-900/80 to-pink-900/80 h-full">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Zap className="w-5 h-5 text-purple-400" />
                Ações Imediatas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {analysis.acoes_imediatas?.map((acao, i) => (
                  <li key={i} className="flex items-start gap-2 text-purple-100 text-sm">
                    <CheckCircle className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
                    {acao}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-cyan-900/80 h-full">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-400" />
                Médio Prazo
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {analysis.estrategias_medio_prazo?.map((estrategia, i) => (
                  <li key={i} className="flex items-start gap-2 text-blue-100 text-sm">
                    <CheckCircle className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                    {estrategia}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }}>
          <Card className="border-indigo-700/50 bg-gradient-to-br from-indigo-900/80 to-violet-900/80 h-full">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Target className="w-5 h-5 text-indigo-400" />
                Longo Prazo
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {analysis.visao_longo_prazo?.map((visao, i) => (
                  <li key={i} className="flex items-start gap-2 text-indigo-100 text-sm">
                    <CheckCircle className="w-4 h-4 text-indigo-400 mt-0.5 flex-shrink-0" />
                    {visao}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}