import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Calendar, Filter, X } from "lucide-react";
import { format, startOfMonth, endOfMonth, subMonths, startOfYear } from "date-fns";

export default function ReportFilters({ 
  startDate, 
  endDate, 
  onStartDateChange, 
  onEndDateChange,
  selectedCategory,
  onCategoryChange,
  selectedCostCenter,
  onCostCenterChange,
  categories = [],
  costCenters = [],
  onReset
}) {
  const quickRanges = [
    { label: "Este Mês", start: startOfMonth(new Date()), end: endOfMonth(new Date()) },
    { label: "Mês Passado", start: startOfMonth(subMonths(new Date(), 1)), end: endOfMonth(subMonths(new Date(), 1)) },
    { label: "Últimos 3 Meses", start: subMonths(new Date(), 3), end: new Date() },
    { label: "Este Ano", start: startOfYear(new Date()), end: new Date() },
  ];

  return (
    <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Filter className="w-5 h-5 text-blue-400" />
          Filtros do Relatório
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Quick Date Ranges */}
        <div className="flex flex-wrap gap-2">
          {quickRanges.map((range) => (
            <Button
              key={range.label}
              size="sm"
              variant="outline"
              onClick={() => {
                onStartDateChange(format(range.start, "yyyy-MM-dd"));
                onEndDateChange(format(range.end, "yyyy-MM-dd"));
              }}
              className="border-blue-700 text-blue-200 hover:bg-blue-800"
            >
              <Calendar className="w-3 h-3 mr-1" />
              {range.label}
            </Button>
          ))}
        </div>

        {/* Date Inputs */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-blue-200">Data Inicial</Label>
            <Input
              type="date"
              value={startDate}
              onChange={(e) => onStartDateChange(e.target.value)}
              className="bg-blue-950/50 border-blue-700 text-white"
            />
          </div>
          <div>
            <Label className="text-blue-200">Data Final</Label>
            <Input
              type="date"
              value={endDate}
              onChange={(e) => onEndDateChange(e.target.value)}
              className="bg-blue-950/50 border-blue-700 text-white"
            />
          </div>
        </div>

        {/* Category and Cost Center Filters */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-blue-200">Categoria</Label>
            <Select value={selectedCategory} onValueChange={onCategoryChange}>
              <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                <SelectValue placeholder="Todas as categorias" />
              </SelectTrigger>
              <SelectContent className="bg-blue-900 border-blue-700">
                <SelectItem value="all">Todas as categorias</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.name}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-blue-200">Centro de Custo</Label>
            <Select value={selectedCostCenter} onValueChange={onCostCenterChange}>
              <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                <SelectValue placeholder="Todos os centros" />
              </SelectTrigger>
              <SelectContent className="bg-blue-900 border-blue-700">
                <SelectItem value="all">Todos os centros</SelectItem>
                {costCenters.map((cc) => (
                  <SelectItem key={cc.id} value={cc.name}>
                    {cc.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {(selectedCategory !== "all" || selectedCostCenter !== "all") && (
          <Button
            size="sm"
            variant="outline"
            onClick={onReset}
            className="w-full border-red-700 text-red-300 hover:bg-red-900/20"
          >
            <X className="w-4 h-4 mr-2" />
            Limpar Filtros
          </Button>
        )}
      </CardContent>
    </Card>
  );
}