import React from "react";
import { Button } from "@/components/ui/button";
import { Download, FileSpreadsheet, FileText } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function ReportExportButtons({ 
  reportTitle,
  data,
  columns,
  startDate,
  endDate,
  companyName = "AUTOCRED PROMOTORA",
  onPdfExport
}) {
  const exportToCSV = () => {
    try {
      const headers = columns.map(col => col.header).join(",");
      const rows = data.map(row => 
        columns.map(col => {
          const value = col.accessor(row);
          return typeof value === 'string' ? `"${value}"` : value;
        }).join(",")
      );
      
      const csv = [headers, ...rows].join("\n");
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = `${reportTitle}_${format(new Date(), "yyyy-MM-dd")}.csv`;
      link.click();
      
      toast.success("✅ CSV exportado com sucesso!");
    } catch (error) {
      console.error("Erro ao exportar CSV:", error);
      toast.error("❌ Erro ao exportar CSV");
    }
  };

  const exportToExcel = () => {
    try {
      const headers = columns.map(col => col.header).join("\t");
      const rows = data.map(row => 
        columns.map(col => col.accessor(row)).join("\t")
      );
      
      const tsv = [headers, ...rows].join("\n");
      const blob = new Blob([tsv], { type: "application/vnd.ms-excel;charset=utf-8;" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = `${reportTitle}_${format(new Date(), "yyyy-MM-dd")}.xls`;
      link.click();
      
      toast.success("✅ Excel exportado com sucesso!");
    } catch (error) {
      console.error("Erro ao exportar Excel:", error);
      toast.error("❌ Erro ao exportar Excel");
    }
  };

  return (
    <div className="flex gap-2">
      <Button
        onClick={exportToCSV}
        variant="outline"
        className="border-green-700 text-green-300 hover:bg-green-900/20"
      >
        <FileSpreadsheet className="w-4 h-4 mr-2" />
        CSV
      </Button>
      <Button
        onClick={exportToExcel}
        variant="outline"
        className="border-blue-700 text-blue-300 hover:bg-blue-900/20"
      >
        <FileSpreadsheet className="w-4 h-4 mr-2" />
        Excel
      </Button>
      {onPdfExport && (
        <Button
          onClick={onPdfExport}
          variant="outline"
          className="border-red-700 text-red-300 hover:bg-red-900/20"
        >
          <FileText className="w-4 h-4 mr-2" />
          PDF
        </Button>
      )}
    </div>
  );
}