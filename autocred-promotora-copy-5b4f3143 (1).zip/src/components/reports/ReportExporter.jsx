import { toast } from "sonner";

export const exportToExcel = (data, filename) => {
  try {
    // Criar CSV com codificação UTF-8 para Excel
    const headers = Object.keys(data[0]);
    const csvContent = [
      headers.join(";"),
      ...data.map(row => 
        headers.map(header => {
          const value = row[header];
          // Tratar valores monetários
          if (typeof value === 'number' && header.includes('valor')) {
            return value.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
          }
          return `"${String(value || '').replace(/"/g, '""')}"`;
        }).join(";")
      )
    ].join("\n");

    // Adicionar BOM para UTF-8
    const BOM = "\uFEFF";
    const blob = new Blob([BOM + csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `${filename}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success("✅ Excel exportado com sucesso!");
  } catch (error) {
    console.error("Erro ao exportar Excel:", error);
    toast.error("❌ Erro ao exportar Excel");
  }
};

export const exportToPDF = (title, data, summary) => {
  try {
    const now = new Date().toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

    const headers = Object.keys(data[0]);
    
    const pdfHTML = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <style>
    @page {
      size: A4;
      margin: 2cm;
    }
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      font-size: 11pt;
      color: #333;
      line-height: 1.4;
    }
    .header {
      text-align: center;
      margin-bottom: 30px;
      padding-bottom: 20px;
      border-bottom: 3px solid #0047AB;
    }
    .header h1 {
      color: #0047AB;
      font-size: 24pt;
      margin-bottom: 5px;
    }
    .header .subtitle {
      color: #666;
      font-size: 12pt;
    }
    .info-box {
      background: #f5f8fa;
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 25px;
      border-left: 4px solid #0047AB;
    }
    .info-box p {
      margin: 5px 0;
      font-size: 10pt;
    }
    .summary {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 15px;
      margin-bottom: 30px;
    }
    .summary-card {
      background: linear-gradient(135deg, #0047AB 0%, #003d99 100%);
      color: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .summary-card .label {
      font-size: 9pt;
      opacity: 0.9;
      margin-bottom: 5px;
    }
    .summary-card .value {
      font-size: 18pt;
      font-weight: bold;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    thead {
      background: linear-gradient(135deg, #0047AB 0%, #003d99 100%);
      color: white;
    }
    th {
      padding: 12px 8px;
      text-align: left;
      font-weight: 600;
      font-size: 10pt;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    tbody tr {
      border-bottom: 1px solid #e0e0e0;
    }
    tbody tr:nth-child(even) {
      background-color: #f9f9f9;
    }
    tbody tr:hover {
      background-color: #f0f7ff;
    }
    td {
      padding: 10px 8px;
      font-size: 9pt;
    }
    .text-right {
      text-align: right;
    }
    .text-center {
      text-align: center;
    }
    .badge {
      display: inline-block;
      padding: 4px 10px;
      border-radius: 12px;
      font-size: 8pt;
      font-weight: 600;
    }
    .badge-receita {
      background: #10b981;
      color: white;
    }
    .badge-despesa {
      background: #ef4444;
      color: white;
    }
    .footer {
      margin-top: 40px;
      padding-top: 20px;
      border-top: 2px solid #e0e0e0;
      text-align: center;
      font-size: 9pt;
      color: #666;
    }
    @media print {
      body {
        print-color-adjust: exact;
        -webkit-print-color-adjust: exact;
      }
      .page-break {
        page-break-before: always;
      }
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>AUTOCRED PROMOTORA</h1>
    <p class="subtitle">${title}</p>
  </div>

  <div class="info-box">
    <p><strong>Data de Geração:</strong> ${now}</p>
    <p><strong>Total de Registros:</strong> ${data.length}</p>
  </div>

  ${summary ? `
    <div class="summary">
      ${summary.receitas !== undefined ? `
        <div class="summary-card">
          <div class="label">Receitas</div>
          <div class="value">R$ ${summary.receitas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
        </div>
      ` : ''}
      ${summary.despesas !== undefined ? `
        <div class="summary-card">
          <div class="label">Despesas</div>
          <div class="value">R$ ${summary.despesas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
        </div>
      ` : ''}
      ${summary.saldo !== undefined ? `
        <div class="summary-card">
          <div class="label">Saldo</div>
          <div class="value">R$ ${summary.saldo.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
        </div>
      ` : ''}
    </div>
  ` : ''}

  <table>
    <thead>
      <tr>
        ${headers.map(h => `<th>${h}</th>`).join('')}
      </tr>
    </thead>
    <tbody>
      ${data.map(row => `
        <tr>
          ${headers.map(header => {
            const value = row[header];
            let formatted = value;
            
            if (typeof value === 'number' && header.toLowerCase().includes('valor')) {
              formatted = `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
            } else if (header.toLowerCase() === 'tipo') {
              formatted = `<span class="badge badge-${value}">${value}</span>`;
            }
            
            return `<td>${formatted || '-'}</td>`;
          }).join('')}
        </tr>
      `).join('')}
    </tbody>
  </table>

  <div class="footer">
    <p>Relatório gerado automaticamente pelo Sistema de Gestão Financeira AUTOCRED PROMOTORA</p>
    <p>© ${new Date().getFullYear()} - Todos os direitos reservados</p>
  </div>
</body>
</html>`;

    const printWindow = window.open('', '_blank');
    printWindow.document.write(pdfHTML);
    printWindow.document.close();
    
    setTimeout(() => {
      printWindow.focus();
      printWindow.print();
    }, 250);
    
    toast.success("✅ PDF sendo gerado - use a opção Salvar como PDF na impressora");
  } catch (error) {
    console.error("Erro ao gerar PDF:", error);
    toast.error("❌ Erro ao gerar PDF");
  }
};