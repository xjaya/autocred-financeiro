import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { base44 } from "@/api/base44Client";
import {
  Sparkles,
  Send,
  X,
  TrendingUp,
  AlertTriangle,
  Target,
  PieChart,
  DollarSign,
  Users,
  FileText,
  Calculator,
  Brain,
  Shield,
  Zap,
  Search,
  RefreshCw,
  BarChart3,
  LineChart,
  Activity,
  Briefcase,
  Calendar,
  CreditCard,
  Globe,
  Heart,
  Home,
  Layers,
  MessageCircle,
  Phone,
  ShoppingCart,
  Star,
  TrendingDown,
  Wallet,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

const aiFeatures = [
  { id: "analysis", name: "Análise Financeira Completa", icon: BarChart3, color: "blue" },
  { id: "cashflow", name: "Previsão de Fluxo de Caixa", icon: TrendingUp, color: "green" },
  { id: "alerts", name: "Alertas Inteligentes", icon: AlertTriangle, color: "red" },
  { id: "goals", name: "Análise de Metas", icon: Target, color: "purple" },
  { id: "categories", name: "Otimização de Categorias", icon: PieChart, color: "yellow" },
  { id: "savings", name: "Sugestões de Economia", icon: DollarSign, color: "green" },
  { id: "clients", name: "Insights de Clientes", icon: Users, color: "blue" },
  { id: "reports", name: "Relatórios Automatizados", icon: FileText, color: "indigo" },
  { id: "taxes", name: "Otimização Fiscal", icon: Calculator, color: "orange" },
  { id: "fraud", name: "Detecção de Fraudes", icon: Shield, color: "red" },
  { id: "trends", name: "Análise de Tendências", icon: LineChart, color: "purple" },
  { id: "budget", name: "Planejamento Orçamentário", icon: Wallet, color: "blue" },
  { id: "investments", name: "Recomendações de Investimento", icon: TrendingUp, color: "green" },
  { id: "suppliers", name: "Análise de Fornecedores", icon: Briefcase, color: "indigo" },
  { id: "seasonal", name: "Padrões Sazonais", icon: Calendar, color: "yellow" },
  { id: "credit", name: "Gestão de Crédito", icon: CreditCard, color: "blue" },
  { id: "market", name: "Inteligência de Mercado", icon: Globe, color: "purple" },
  { id: "health", name: "Saúde Financeira", icon: Heart, color: "red" },
  { id: "assets", name: "Gestão de Ativos", icon: Home, color: "green" },
  { id: "consolidation", name: "Consolidação de Dados", icon: Layers, color: "blue" },
  { id: "chat", name: "Consultor Virtual", icon: MessageCircle, color: "indigo" },
  { id: "notifications", name: "Alertas Personalizados", icon: Phone, color: "yellow" },
  { id: "sales", name: "Análise de Vendas", icon: ShoppingCart, color: "green" },
  { id: "performance", name: "Indicadores de Performance", icon: Activity, color: "purple" },
  { id: "recommendations", name: "Recomendações Personalizadas", icon: Star, color: "yellow" },
  { id: "risks", name: "Análise de Riscos", icon: AlertTriangle, color: "red" },
  { id: "opportunities", name: "Identificação de Oportunidades", icon: Zap, color: "yellow" },
  { id: "competitors", name: "Análise Competitiva", icon: Search, color: "blue" },
  { id: "automation", name: "Automação Inteligente", icon: RefreshCw, color: "indigo" },
  { id: "forecasting", name: "Previsões Avançadas", icon: Brain, color: "purple" },
];

export default function AdvancedAIAssistant({ context = "", pageInfo = "" }) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("features");
  const [question, setQuestion] = useState("");
  const [response, setResponse] = useState(null);
  const [loading, setLoading] = useState(false);
  const [selectedFeature, setSelectedFeature] = useState(null);

  const handleFeatureAnalysis = async (feature) => {
    setSelectedFeature(feature.id);
    setLoading(true);
    setResponse(null);

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Você é um consultor financeiro especializado da AUTOCRED PROMOTORA.

FUNCIONALIDADE SOLICITADA: ${feature.name}

CONTEXTO DA PÁGINA: ${pageInfo}
DADOS RELEVANTES: ${context}

Forneça uma análise COMPLETA e DETALHADA sobre ${feature.name}:
1. Status atual e indicadores
2. Insights principais
3. Recomendações acionáveis (mínimo 5)
4. Alertas e riscos identificados
5. Oportunidades de melhoria
6. Próximos passos sugeridos

Seja específico, detalhado e profissional.`,
      });

      setResponse(result);
    } catch (error) {
      console.error("Erro ao consultar IA:", error);
      toast.error("Erro ao processar análise. Tente novamente.");
      setResponse("Desculpe, ocorreu um erro. Por favor, tente novamente.");
    } finally {
      setLoading(false);
      setSelectedFeature(null);
    }
  };

  const handleAsk = async () => {
    if (!question.trim()) return;

    setLoading(true);
    setResponse(null);

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Você é um consultor financeiro especializado da AUTOCRED PROMOTORA.

CONTEXTO DA PÁGINA: ${pageInfo}
DADOS RELEVANTES: ${context}

PERGUNTA DO USUÁRIO: ${question}

Forneça uma resposta clara, objetiva, detalhada e profissional em português brasileiro.`,
      });

      setResponse(result);
      setQuestion("");
    } catch (error) {
      console.error("Erro ao consultar IA:", error);
      toast.error("Erro ao processar pergunta. Tente novamente.");
      setResponse("Desculpe, ocorreu um erro. Por favor, tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <Button
              onClick={() => setIsOpen(true)}
              className="h-16 w-16 rounded-full bg-gradient-to-r from-purple-600 via-blue-600 to-purple-600 hover:from-purple-500 hover:via-blue-500 hover:to-purple-500 shadow-2xl shadow-purple-500/50 hover:shadow-purple-500/70 transition-all animate-pulse"
            >
              <Sparkles className="w-7 h-7" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 w-[600px] max-w-[calc(100vw-3rem)] max-h-[80vh]"
          >
            <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/95 to-blue-900/95 backdrop-blur-xl shadow-2xl overflow-hidden">
              <CardHeader className="border-b border-purple-700/50 pb-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-purple-100 flex items-center gap-2">
                    <Brain className="w-5 h-5 text-purple-400" />
                    Assistente IA Avançado
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setIsOpen(false)}
                    className="text-purple-300 hover:text-white hover:bg-purple-800"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-purple-300 mt-1">
                  30 Funcionalidades Inteligentes para sua Gestão Financeira
                </p>
              </CardHeader>

              <CardContent className="pt-4 max-h-[calc(80vh-120px)] overflow-y-auto">
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid w-full grid-cols-2 mb-4 bg-purple-950/50">
                    <TabsTrigger value="features" className="text-purple-200 data-[state=active]:bg-purple-700">
                      Funcionalidades
                    </TabsTrigger>
                    <TabsTrigger value="chat" className="text-purple-200 data-[state=active]:bg-purple-700">
                      Consultor Virtual
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="features" className="space-y-3">
                    <div className="grid grid-cols-2 gap-2 max-h-[calc(80vh-250px)] overflow-y-auto pr-2">
                      {aiFeatures.map((feature) => {
                        const Icon = feature.icon;
                        return (
                          <Button
                            key={feature.id}
                            onClick={() => handleFeatureAnalysis(feature)}
                            disabled={loading}
                            variant="outline"
                            className={`h-auto py-3 px-3 flex flex-col items-start gap-2 bg-purple-950/30 border-purple-700 hover:bg-purple-800 hover:border-purple-500 transition-all ${
                              selectedFeature === feature.id ? 'ring-2 ring-purple-400' : ''
                            }`}
                          >
                            <Icon className={`w-5 h-5 text-${feature.color}-400`} />
                            <span className="text-xs text-left text-purple-200 leading-tight">
                              {feature.name}
                            </span>
                            {selectedFeature === feature.id && (
                              <RefreshCw className="w-3 h-3 text-purple-400 animate-spin absolute top-2 right-2" />
                            )}
                          </Button>
                        );
                      })}
                    </div>

                    {response && (
                      <div className="bg-purple-950/50 p-4 rounded-lg border border-purple-700 mt-4 max-h-60 overflow-y-auto">
                        <p className="text-sm text-purple-100 whitespace-pre-wrap leading-relaxed">
                          {response}
                        </p>
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="chat" className="space-y-4">
                    {response && (
                      <div className="bg-purple-950/50 p-4 rounded-lg border border-purple-700 max-h-60 overflow-y-auto">
                        <p className="text-sm text-purple-100 whitespace-pre-wrap leading-relaxed">
                          {response}
                        </p>
                      </div>
                    )}

                    <div className="space-y-2">
                      <Textarea
                        value={question}
                        onChange={(e) => setQuestion(e.target.value)}
                        placeholder="Ex: Como posso reduzir custos operacionais?"
                        rows={3}
                        className="bg-purple-950/50 border-purple-700 text-white placeholder:text-purple-400"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleAsk();
                          }
                        }}
                      />
                      <Button
                        onClick={handleAsk}
                        disabled={loading || !question.trim()}
                        className="w-full bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600"
                      >
                        {loading ? (
                          <>
                            <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                            Processando...
                          </>
                        ) : (
                          <>
                            <Send className="w-4 h-4 mr-2" />
                            Perguntar ao Consultor
                          </>
                        )}
                      </Button>
                    </div>

                    <div className="border-t border-purple-700/50 pt-3">
                      <p className="text-xs text-purple-300 font-medium mb-2">Sugestões:</p>
                      <div className="space-y-1">
                        {[
                          "Análise completa da minha situação financeira",
                          "Como aumentar a lucratividade?",
                          "Quais são meus maiores gastos?",
                          "Dicas para otimizar o fluxo de caixa",
                        ].map((suggestion, i) => (
                          <button
                            key={i}
                            onClick={() => setQuestion(suggestion)}
                            className="text-xs text-purple-300 hover:text-white bg-purple-950/30 hover:bg-purple-800 px-3 py-1.5 rounded-lg transition-all w-full text-left"
                          >
                            {suggestion}
                          </button>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}