import { base44 } from './base44Client';


export const Transaction = base44.entities.Transaction;

export const Contract = base44.entities.Contract;

export const Client = base44.entities.Client;

export const Supplier = base44.entities.Supplier;

export const Report = base44.entities.Report;

export const Notification = base44.entities.Notification;

export const CompanySettings = base44.entities.CompanySettings;

export const AuditLog = base44.entities.AuditLog;

export const CostCenter = base44.entities.CostCenter;

export const Category = base44.entities.Category;

export const BankAccount = base44.entities.BankAccount;

export const Goal = base44.entities.Goal;

export const Transfer = base44.entities.Transfer;

export const BankIntegration = base44.entities.BankIntegration;

export const ExtractImport = base44.entities.ExtractImport;

export const AILearning = base44.entities.AILearning;



// auth sdk:
export const User = base44.auth;