import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "691c58d67871acf85b4f3143", 
  requiresAuth: true // Ensure authentication is required for all operations
});
