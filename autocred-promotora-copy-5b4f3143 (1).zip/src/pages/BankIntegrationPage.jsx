import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import {
  Plus,
  RefreshCw,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Sparkles,
  Link as LinkIcon,
  Unlink,
  Clock,
  Shield
} from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import AIAssistant from "../components/AIAssistant";

const BANKS = [
  { code: "001", name: "Banco do Brasil" },
  { code: "237", name: "Bradesco" },
  { code: "104", name: "Caixa Econômica" },
  { code: "341", name: "Itaú" },
  { code: "033", name: "Santander" },
  { code: "077", name: "Inter" },
  { code: "260", name: "Nubank" },
  { code: "336", name: "C6 Bank" },
  { code: "290", name: "PagBank" },
  { code: "212", name: "Banco Original" },
];

export default function BankIntegrationPage() {
  const [showDialog, setShowDialog] = useState(false);
  const [selectedBank, setSelectedBank] = useState("");
  const [selectedAccount, setSelectedAccount] = useState("");
  const [syncing, setSyncing] = useState({});
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [loadingAI, setLoadingAI] = useState(false);

  const queryClient = useQueryClient();

  const { data: integrations = [], isLoading } = useQuery({
    queryKey: ["bankIntegrations"],
    queryFn: () => base44.entities.BankIntegration.list("-created_date"),
    initialData: [],
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ["bankAccounts"],
    queryFn: () => base44.entities.BankAccount.list(),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.BankIntegration.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bankIntegrations"] });
      setShowDialog(false);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.BankIntegration.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bankIntegrations"] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.BankIntegration.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bankIntegrations"] });
    },
  });

  const handleConnect = async () => {
    if (!selectedBank || !selectedAccount) {
      alert("Selecione o banco e a conta!");
      return;
    }

    const bankData = BANKS.find(b => b.code === selectedBank);

    try {
      await createMutation.mutateAsync({
        bank_name: bankData.name,
        bank_code: selectedBank,
        account_linked: selectedAccount,
        integration_type: "open_finance",
        status: "aguardando_autorizacao",
        auto_sync_enabled: true,
        sync_frequency: "diaria",
        consent_expires_at: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(),
      });

      alert("✅ Integração iniciada! Aguardando autorização do banco...");
    } catch (error) {
      console.error("Erro ao conectar:", error);
      alert("❌ Erro ao conectar com o banco");
    }
  };

  const handleSync = async (integration) => {
    setSyncing(prev => ({ ...prev, [integration.id]: true }));

    try {
      // Simular sincronização (em produção, chamaria API do banco via Open Finance)
      await new Promise(resolve => setTimeout(resolve, 2000));

      await updateMutation.mutateAsync({
        id: integration.id,
        data: {
          ...integration,
          last_sync: new Date().toISOString(),
          status: "ativa",
        },
      });

      alert("✅ Sincronização concluída!");
    } catch (error) {
      console.error("Erro ao sincronizar:", error);
      alert("❌ Erro na sincronização");
    } finally {
      setSyncing(prev => ({ ...prev, [integration.id]: false }));
    }
  };

  const handleToggleAutoSync = async (integration, enabled) => {
    await updateMutation.mutateAsync({
      id: integration.id,
      data: {
        ...integration,
        auto_sync_enabled: enabled,
      },
    });
  };

  const generateAIReport = async () => {
    setLoadingAI(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analise o status das integrações bancárias via Open Finance:

INTEGRAÇÕES ATIVAS: ${integrations.length}
DETALHES: ${JSON.stringify(integrations)}

Forneça:
1. Avaliação do nível de automação atual
2. Identificação de contas sem integração
3. Recomendações para otimizar sincronizações
4. Alertas sobre consentimentos próximos do vencimento
5. Sugestões de melhores práticas de segurança
6. Análise de frequência de sincronização ideal
7. Identificação de oportunidades de melhoria
8. Checklist de segurança e conformidade`,
      });

      setAiAnalysis(result);
    } catch (error) {
      console.error("Erro ao gerar relatório:", error);
    }
    setLoadingAI(false);
  };

  const activeIntegrations = integrations.filter(i => i.status === "ativa").length;
  const pendingIntegrations = integrations.filter(i => i.status === "aguardando_autorizacao").length;
  const errorIntegrations = integrations.filter(i => i.status === "erro").length;

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white drop-shadow-lg">Integração Bancária - Open Finance</h1>
          <p className="text-blue-200 mt-1">Conecte suas contas bancárias automaticamente</p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={generateAIReport}
            disabled={loadingAI}
            className="bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600"
          >
            <Sparkles className={`w-4 h-4 mr-2 ${loadingAI ? "animate-spin" : ""}`} />
            Análise IA
          </Button>
          <Dialog open={showDialog} onOpenChange={setShowDialog}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600 shadow-lg">
                <Plus className="w-4 h-4 mr-2" />
                Nova Integração
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg bg-blue-900 border-blue-700 text-white">
              <DialogHeader>
                <DialogTitle className="text-xl text-white flex items-center gap-2">
                  <Shield className="w-5 h-5 text-green-400" />
                  Conectar Banco via Open Finance
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label className="text-blue-200">Selecione o Banco*</Label>
                  <Select value={selectedBank} onValueChange={setSelectedBank}>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue placeholder="Escolha o banco" />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      {BANKS.map((bank) => (
                        <SelectItem key={bank.code} value={bank.code}>
                          {bank.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-blue-200">Vincular à Conta*</Label>
                  <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue placeholder="Escolha a conta" />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      {bankAccounts.map((acc) => (
                        <SelectItem key={acc.id} value={acc.name}>
                          {acc.name} - {acc.bank}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="bg-blue-950/50 p-4 rounded-lg border border-blue-700">
                  <p className="text-sm text-blue-200 font-medium mb-2">🔒 Segurança Open Finance:</p>
                  <ul className="text-xs text-blue-300 space-y-1">
                    <li>✅ Conexão segura e criptografada</li>
                    <li>✅ Regulamentado pelo Banco Central</li>
                    <li>✅ Você controla os dados compartilhados</li>
                    <li>✅ Consentimento renovável a cada 90 dias</li>
                    <li>✅ Pode ser revogado a qualquer momento</li>
                  </ul>
                </div>

                <div className="flex justify-end gap-2 pt-4 border-t border-blue-700">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowDialog(false)}
                    className="border-blue-700 text-blue-200 hover:bg-blue-800"
                  >
                    Cancelar
                  </Button>
                  <Button
                    onClick={handleConnect}
                    className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600"
                  >
                    <LinkIcon className="w-4 h-4 mr-2" />
                    Conectar
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-green-500/50 bg-gradient-to-br from-green-800/80 to-green-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <CheckCircle className="w-8 h-8 text-green-300 mx-auto mb-2" />
              <p className="text-sm text-green-200">Integrações Ativas</p>
              <p className="text-3xl font-bold text-white mt-1">{activeIntegrations}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-yellow-500/50 bg-gradient-to-br from-yellow-800/80 to-yellow-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <Clock className="w-8 h-8 text-yellow-300 mx-auto mb-2" />
              <p className="text-sm text-yellow-200">Aguardando Autorização</p>
              <p className="text-3xl font-bold text-white mt-1">{pendingIntegrations}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-red-500/50 bg-gradient-to-br from-red-800/80 to-red-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <AlertTriangle className="w-8 h-8 text-red-300 mx-auto mb-2" />
              <p className="text-sm text-red-200">Com Erro</p>
              <p className="text-3xl font-bold text-white mt-1">{errorIntegrations}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-blue-500/50 bg-gradient-to-br from-blue-800/80 to-blue-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <LinkIcon className="w-8 h-8 text-blue-300 mx-auto mb-2" />
              <p className="text-sm text-blue-200">Total de Integrações</p>
              <p className="text-3xl font-bold text-white mt-1">{integrations.length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Análise de IA */}
      {aiAnalysis && (
        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
          <CardHeader>
            <CardTitle className="text-purple-100 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-400" />
              Análise Inteligente de Integrações
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose prose-invert prose-sm max-w-none text-purple-100 whitespace-pre-wrap leading-relaxed">
              {aiAnalysis}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Lista de Integrações */}
      <div className="space-y-4">
        {integrations.map((integration) => {
          const daysUntilExpiry = integration.consent_expires_at 
            ? differenceInDays(new Date(integration.consent_expires_at), new Date())
            : null;

          return (
            <Card 
              key={integration.id}
              className={`border-2 ${
                integration.status === "ativa" 
                  ? "border-green-500/50 bg-gradient-to-br from-green-900/30 to-blue-900/80"
                  : integration.status === "erro"
                  ? "border-red-500/50 bg-gradient-to-br from-red-900/30 to-blue-900/80"
                  : "border-yellow-500/50 bg-gradient-to-br from-yellow-900/30 to-blue-900/80"
              } backdrop-blur-sm shadow-xl`}
            >
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row justify-between gap-4">
                  <div className="flex items-start gap-4 flex-1">
                    <div className={`p-3 rounded-xl ${
                      integration.status === "ativa" ? "bg-green-500/20" :
                      integration.status === "erro" ? "bg-red-500/20" : "bg-yellow-500/20"
                    }`}>
                      {integration.status === "ativa" && <CheckCircle className="w-8 h-8 text-green-400" />}
                      {integration.status === "erro" && <XCircle className="w-8 h-8 text-red-400" />}
                      {integration.status === "aguardando_autorizacao" && <Clock className="w-8 h-8 text-yellow-400" />}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-white">{integration.bank_name}</h3>
                      <p className="text-sm text-blue-300 mt-1">
                        Conta: {integration.account_linked} • Código: {integration.bank_code}
                      </p>
                      <div className="flex flex-wrap items-center gap-2 mt-3">
                        <Badge 
                          className={
                            integration.status === "ativa" 
                              ? "bg-green-500 text-white"
                              : integration.status === "erro"
                              ? "bg-red-500 text-white"
                              : "bg-yellow-500 text-white"
                          }
                        >
                          {integration.status === "ativa" ? "Ativa" : 
                           integration.status === "erro" ? "Erro" : "Aguardando Autorização"}
                        </Badge>
                        <Badge variant="outline" className="text-blue-200 border-blue-500">
                          Sinc: {integration.sync_frequency}
                        </Badge>
                        {integration.last_sync && (
                          <Badge variant="outline" className="text-green-200 border-green-500">
                            Última sinc: {format(new Date(integration.last_sync), "dd/MM HH:mm")}
                          </Badge>
                        )}
                      </div>

                      {daysUntilExpiry !== null && daysUntilExpiry <= 15 && (
                        <div className="mt-3 bg-yellow-900/30 border border-yellow-500 rounded-lg p-3">
                          <p className="text-sm text-yellow-300 flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4" />
                            Consentimento expira em {daysUntilExpiry} dias
                          </p>
                        </div>
                      )}

                      <div className="flex items-center gap-3 mt-4">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={integration.auto_sync_enabled}
                            onCheckedChange={(checked) => handleToggleAutoSync(integration, checked)}
                          />
                          <span className="text-sm text-blue-200">Sinc. Automática</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <Button
                      onClick={() => handleSync(integration)}
                      disabled={syncing[integration.id] || integration.status !== "ativa"}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <RefreshCw className={`w-4 h-4 mr-2 ${syncing[integration.id] ? "animate-spin" : ""}`} />
                      {syncing[integration.id] ? "Sincronizando..." : "Sincronizar"}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        if (confirm("Deseja desconectar esta integração?")) {
                          deleteMutation.mutate(integration.id);
                        }
                      }}
                      className="border-red-500 text-red-300 hover:bg-red-900"
                    >
                      <Unlink className="w-4 h-4 mr-2" />
                      Desconectar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}

        {integrations.length === 0 && !isLoading && (
          <Card className="border-blue-700/50 bg-blue-900/50">
            <CardContent className="py-12 text-center">
              <Shield className="w-16 h-16 text-blue-400 mx-auto mb-4 opacity-50" />
              <p className="text-blue-200 text-lg">Nenhuma integração bancária configurada</p>
              <p className="text-sm text-blue-300 mt-2">Conecte seus bancos via Open Finance para automação total</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Assistente IA */}
      <AIAssistant 
        context={`Integrações Ativas: ${activeIntegrations}, Total: ${integrations.length}`}
        pageInfo="Integração Bancária - Open Finance para automação total"
      />
    </div>
  );
}