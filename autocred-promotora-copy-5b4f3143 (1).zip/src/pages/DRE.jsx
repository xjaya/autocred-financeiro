import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, RefreshCw, TrendingUp, TrendingDown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { startOfMonth, endOfMonth, format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import ReportFilters from "../components/reports/ReportFilters";
import ReportExportButtons from "../components/reports/ReportExportButtons";

export default function DRE() {
  const [startDate, setStartDate] = useState(format(startOfMonth(new Date()), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(endOfMonth(new Date()), "yyyy-MM-dd"));
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [loadingAI, setLoadingAI] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedCostCenter, setSelectedCostCenter] = useState("all");

  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list(),
    initialData: [],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list(),
    initialData: [],
  });

  const { data: costCenters = [] } = useQuery({
    queryKey: ["costCenters"],
    queryFn: () => base44.entities.CostCenter.list(),
    initialData: [],
  });

  const filteredTransactions = transactions.filter((t) => {
    const tDate = new Date(t.due_date);
    const dateMatch = tDate >= new Date(startDate) && tDate <= new Date(endDate);
    const categoryMatch = selectedCategory === "all" || t.category === selectedCategory;
    const costCenterMatch = selectedCostCenter === "all" || t.cost_center === selectedCostCenter;
    return dateMatch && categoryMatch && costCenterMatch;
  });

  const receitaBruta = filteredTransactions
    .filter((t) => t.type === "receita" && t.status === "pago")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const despesasByCategory = filteredTransactions
    .filter((t) => t.type === "despesa" && t.status === "pago")
    .reduce((acc, t) => {
      const category = t.category || "Outras";
      acc[category] = (acc[category] || 0) + t.amount;
      return acc;
    }, {});

  const despesasOperacionais = Object.values(despesasByCategory).reduce((sum, val) => sum + val, 0);
  const lucroOperacional = receitaBruta - despesasOperacionais;
  const margemOperacional = receitaBruta > 0 ? (lucroOperacional / receitaBruta) * 100 : 0;

  const chartData = Object.entries(despesasByCategory)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 8);

  const generateAIAnalysis = async () => {
    setLoadingAI(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analise DRE de ${format(new Date(startDate), "dd/MM/yyyy")} a ${format(new Date(endDate), "dd/MM/yyyy")}:

RECEITA: R$ ${receitaBruta.toFixed(2)}
DESPESAS: R$ ${despesasOperacionais.toFixed(2)}
LUCRO: R$ ${lucroOperacional.toFixed(2)}
MARGEM: ${margemOperacional.toFixed(2)}%

DESPESAS: ${Object.entries(despesasByCategory).map(([cat, val]) => `${cat}: R$ ${val.toFixed(2)}`).join(', ')}

DIAGNÓSTICO EM 3 SEÇÕES:

🟢 PONTOS POSITIVOS
- Elogios específicos
- O que está funcionando bem

🟠 ALERTAS
- Atenção necessária
- Sugestões de melhoria

🔴 CRÍTICO
- Problemas urgentes
- Ações imediatas necessárias

Seja direto, objetivo e use números.`,
      });

      setAiAnalysis(result);
    } catch (error) {
      console.error("Erro:", error);
    }
    setLoadingAI(false);
  };

  useEffect(() => {
    if (!isLoading && transactions.length > 0) {
      generateAIAnalysis();
    }
  }, [startDate, endDate, isLoading]);

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="w-8 h-8 text-blue-400 animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white drop-shadow-lg">DRE - Demonstração do Resultado</h1>
          <p className="text-blue-200 mt-1">Diagnóstico com IA em tempo real</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={generateAIAnalysis} disabled={loadingAI} variant="outline" className="border-purple-600 text-purple-300 hover:bg-purple-700">
            <Sparkles className={`w-4 h-4 mr-2 ${loadingAI ? "animate-spin" : ""}`} />
            {loadingAI ? "Analisando..." : "IA Analisar"}
          </Button>
          <ReportExportButtons
            reportTitle="DRE"
            data={filteredTransactions}
            columns={[
              { header: "Data", accessor: (t) => format(new Date(t.due_date), "dd/MM/yyyy") },
              { header: "Descrição", accessor: (t) => t.description },
              { header: "Categoria", accessor: (t) => t.category || "-" },
              { header: "Tipo", accessor: (t) => t.type },
              { header: "Valor", accessor: (t) => t.amount.toFixed(2) }
            ]}
            startDate={startDate}
            endDate={endDate}
            onPdfExport={() => {
            const printWindow = window.open('', '_blank');
            const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>DRE - ${format(new Date(startDate), "dd/MM/yyyy")} a ${format(new Date(endDate), "dd/MM/yyyy")}</title>
  <style>
    @page { size: A4; margin: 15mm; }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: 'Segoe UI', Arial, sans-serif; 
      color: #1a1a1a;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 20px;
    }
    .container { 
      max-width: 210mm; 
      background: white; 
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.1);
    }
    .header { 
      text-align: center; 
      border-bottom: 3px solid #667eea; 
      padding-bottom: 20px; 
      margin-bottom: 30px;
    }
    .header h1 { font-size: 28px; color: #667eea; font-weight: 700; }
    .info-box { 
      background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
      padding: 15px; 
      border-radius: 8px; 
      margin-bottom: 25px;
      border-left: 4px solid #667eea;
    }
    .cards { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 30px; }
    .card { padding: 20px; border-radius: 10px; text-align: center; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    .card.green { background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%); border-left: 5px solid #10b981; }
    .card.red { background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%); border-left: 5px solid #ef4444; }
    .card.blue { background: linear-gradient(135deg, #d299c2 0%, #fef9d7 100%); border-left: 5px solid #3b82f6; }
    .card-label { font-size: 12px; color: #666; text-transform: uppercase; font-weight: 600; }
    .card-value { font-size: 22px; font-weight: 700; color: #1a1a1a; margin-top: 8px; }
    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
    th { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 12px; text-align: left; font-size: 13px; }
    td { padding: 12px; border-bottom: 1px solid #e5e7eb; font-size: 13px; }
    .total-row { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white !important; font-weight: 700; }
    .total-row td { border: none; padding: 15px 12px; font-size: 15px; }
    .footer { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 2px solid #e5e7eb; color: #666; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>📊 DRE - Demonstração do Resultado</h1>
      <p>AUTOCRED PROMOTORA</p>
    </div>
    <div class="info-box">
      <p><strong>Período:</strong> ${format(new Date(startDate), "dd/MM/yyyy")} a ${format(new Date(endDate), "dd/MM/yyyy")}</p>
      <p><strong>Gerado em:</strong> ${format(new Date(), "dd/MM/yyyy 'às' HH:mm")}</p>
    </div>
    <div class="cards">
      <div class="card green">
        <div class="card-label">Receita Bruta</div>
        <div class="card-value">R$ ${receitaBruta.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
      </div>
      <div class="card red">
        <div class="card-label">Despesas</div>
        <div class="card-value">R$ ${despesasOperacionais.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
      </div>
      <div class="card blue">
        <div class="card-label">Lucro</div>
        <div class="card-value">R$ ${lucroOperacional.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
      </div>
    </div>
    <table>
      <thead>
        <tr><th>Descrição</th><th style="text-align: right;">Valor (R$)</th><th style="text-align: right;">%</th></tr>
      </thead>
      <tbody>
        <tr><td><strong>RECEITA BRUTA</strong></td><td style="text-align: right; color: #10b981; font-weight: 600;">R$ ${receitaBruta.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</td><td style="text-align: right;">100%</td></tr>
        <tr><td colspan="3" style="padding: 8px 12px; background: #f3f4f6; font-weight: 600;">(-) DESPESAS OPERACIONAIS</td></tr>
        ${Object.entries(despesasByCategory).sort((a, b) => b[1] - a[1]).map(([cat, val]) => `
        <tr>
          <td style="padding-left: 30px;">${cat}</td>
          <td style="text-align: right; color: #ef4444;">R$ ${val.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</td>
          <td style="text-align: right;">${((val / despesasOperacionais) * 100).toFixed(1)}%</td>
        </tr>`).join('')}
        <tr><td><strong>TOTAL DESPESAS</strong></td><td style="text-align: right; color: #ef4444; font-weight: 600;">R$ ${despesasOperacionais.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</td><td style="text-align: right; font-weight: 600;">${((despesasOperacionais / receitaBruta) * 100).toFixed(1)}%</td></tr>
        <tr class="total-row"><td><strong>= LUCRO OPERACIONAL</strong></td><td style="text-align: right;"><strong>R$ ${lucroOperacional.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</strong></td><td style="text-align: right;"><strong>${margemOperacional.toFixed(1)}%</strong></td></tr>
      </tbody>
    </table>
    <div class="footer">
      <p>AUTOCRED PROMOTORA - Sistema Financeiro</p>
      <p>Documento Confidencial</p>
    </div>
  </div>
</body>
</html>`;
            printWindow.document.write(html);
            printWindow.document.close();
            setTimeout(() => printWindow.print(), 500);
            }}
          />
        </div>
      </div>

      <ReportFilters
        startDate={startDate}
        endDate={endDate}
        onStartDateChange={setStartDate}
        onEndDateChange={setEndDate}
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
        selectedCostCenter={selectedCostCenter}
        onCostCenterChange={setSelectedCostCenter}
        categories={categories}
        costCenters={costCenters}
        onReset={() => {
          setSelectedCategory("all");
          setSelectedCostCenter("all");
        }}
      />

      <div className="grid grid-cols-3 gap-6">
        <Card className="border-green-500/50 bg-gradient-to-br from-green-800/80 to-green-700/80">
          <CardContent className="pt-6">
            <p className="text-sm text-green-200">Receita Bruta</p>
            <p className="text-3xl font-bold text-white mt-1">R$ {receitaBruta.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
          </CardContent>
        </Card>

        <Card className="border-red-500/50 bg-gradient-to-br from-red-800/80 to-red-700/80">
          <CardContent className="pt-6">
            <p className="text-sm text-red-200">Despesas Operacionais</p>
            <p className="text-3xl font-bold text-white mt-1">R$ {despesasOperacionais.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
          </CardContent>
        </Card>

        <Card className="border-blue-500/50 bg-gradient-to-br from-blue-800/80 to-blue-700/80">
          <CardContent className="pt-6">
            <p className="text-sm text-blue-200">Lucro Operacional</p>
            <p className={`text-3xl font-bold mt-1 ${lucroOperacional >= 0 ? "text-white" : "text-red-300"}`}>
              R$ {lucroOperacional.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </p>
            <p className="text-sm text-blue-300 mt-1">Margem: {margemOperacional.toFixed(1)}%</p>
          </CardContent>
        </Card>
      </div>

      {aiAnalysis && (
        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/90 to-blue-900/90 shadow-2xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Sparkles className="w-6 h-6 text-purple-400" />
              Diagnóstico Financeiro com IA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose prose-invert max-w-none text-sm whitespace-pre-wrap leading-relaxed text-white">
              {aiAnalysis}
            </div>
          </CardContent>
        </Card>
      )}

      {loadingAI && (
        <Card className="border-purple-500/50 bg-purple-900/50">
          <CardContent className="py-8">
            <div className="flex items-center justify-center gap-3">
              <RefreshCw className="w-5 h-5 animate-spin text-purple-400" />
              <span className="text-purple-200">Gerando diagnóstico...</span>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white">Detalhamento DRE</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between pb-3 border-b border-blue-700">
              <span className="font-semibold text-white">RECEITA BRUTA</span>
              <span className="font-bold text-green-300">R$ {receitaBruta.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
            </div>

            <div className="pb-3 border-b border-blue-700">
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-white">(-) DESPESAS OPERACIONAIS</span>
                <span className="font-bold text-red-300">R$ {despesasOperacionais.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="ml-4 space-y-1">
                {Object.entries(despesasByCategory).sort((a, b) => b[1] - a[1]).map(([cat, val]) => (
                  <div key={cat} className="flex justify-between text-sm">
                    <span className="text-blue-200">{cat}</span>
                    <span className="text-white">R$ {val.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-blue-800/50 p-4 rounded-lg">
              <div className="flex justify-between">
                <span className="font-bold text-xl text-white">= LUCRO OPERACIONAL</span>
                <span className={`font-bold text-2xl ${lucroOperacional >= 0 ? "text-blue-300" : "text-red-300"}`}>
                  R$ {lucroOperacional.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="flex justify-between mt-2">
                <span className="text-blue-200">Margem</span>
                <span className="text-white">{margemOperacional.toFixed(2)}%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white">Despesas por Categoria</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
              <XAxis dataKey="name" stroke="#93c5fd" fontSize={12} angle={-45} textAnchor="end" height={100} />
              <YAxis stroke="#93c5fd" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px", color: "#fff" }} />
              <Bar dataKey="value" fill="#3b82f6" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}