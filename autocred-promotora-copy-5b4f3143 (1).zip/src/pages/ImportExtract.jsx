import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Upload,
  FileText,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Loader2,
  X,
  Mic,
  Search,
  AlertTriangle,
  Check,
} from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { format } from "date-fns";
import { Progress } from "@/components/ui/progress";

export default function ImportExtract() {
  const [file, setFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [processingStage, setProcessingStage] = useState("");
  const [extractedTransactions, setExtractedTransactions] = useState([]);
  const [selectedTransactions, setSelectedTransactions] = useState(new Set());
  const [processing, setProcessing] = useState(false);
  const [detectedBank, setDetectedBank] = useState(null);
  const [detectedAccount, setDetectedAccount] = useState(null);
  const [detectedAgency, setDetectedAgency] = useState(null);
  const [selectedBankAccount, setSelectedBankAccount] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [showReview, setShowReview] = useState(false);

  const queryClient = useQueryClient();

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ["bankAccounts"],
    queryFn: () => base44.entities.BankAccount.list(),
    initialData: [],
  });

  const createTransactionsMutation = useMutation({
    mutationFn: (transactions) => 
      base44.entities.Transaction.bulkCreate(transactions),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      setExtractedTransactions([]);
      setSelectedTransactions(new Set());
      setFile(null);
      setDetectedBank(null);
      setDetectedAccount(null);
      setDetectedAgency(null);
      setShowReview(false);
      setProcessingStage("completed");
      toast.success("✅ Lançamentos importados com sucesso!");
    },
    onError: () => {
      toast.error("❌ Erro ao importar lançamentos");
    },
  });

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile && selectedFile.type === "application/pdf") {
      setFile(selectedFile);
      setExtractedTransactions([]);
      setSelectedTransactions(new Set());
      setDetectedBank(null);
      setDetectedAccount(null);
      setDetectedAgency(null);
      setShowReview(false);
      setProcessingStage("");
      setUploadProgress(0);
    } else {
      toast.error("❌ Por favor, selecione um arquivo PDF");
    }
  };

  const handleUploadAndExtract = async () => {
    if (!file) {
      toast.error("❌ Selecione um arquivo PDF");
      return;
    }

    setProcessingStage("uploading");
    setUploadProgress(10);
    
    try {
      toast.info("📤 Fazendo upload do extrato...");
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setUploadProgress(30);
      
      setProcessingStage("analyzing");
      toast.info("🔍 Analisando cabeçalho do extrato...");
      setUploadProgress(40);

      setProcessingStage("extracting");
      toast.info("🤖 IA processando TODAS as transações (aguarde)...");
      setUploadProgress(50);

      const extractionPrompt = `Você é um especialista em análise de extratos bancários brasileiros. Analise MINUCIOSAMENTE e COMPLETAMENTE este extrato bancário em PDF.

**TAREFA 1 - IDENTIFICAÇÃO DO CABEÇALHO (PRIMEIRA PÁGINA)**
Localize no TOPO/INÍCIO da PRIMEIRA PÁGINA do extrato e extraia:
- Nome completo do BANCO (ex: "Banco do Brasil S.A.", "Banco Bradesco", "Caixa Econômica Federal", "Itaú Unibanco", "Santander Brasil", "Nubank", "Banco Inter", etc.)
- Número da AGÊNCIA (pode estar como "AG:", "Agência:", "Agency:", etc.)
- Número da CONTA com dígito verificador (pode estar como "C/C:", "Conta:", "Account:", "Conta Corrente:", etc.) - INCLUA O DÍGITO
- Nome do TITULAR/CORRENTISTA (se disponível)
- Período do extrato (datas de início e fim)

**TAREFA 2 - EXTRAÇÃO COMPLETA DE TRANSAÇÕES**
Processe TODO O DOCUMENTO, PÁGINA POR PÁGINA, LINHA POR LINHA.
CRITICAL: NÃO pare em 50, 100 ou 200 transações. Continue até a ÚLTIMA PÁGINA e ÚLTIMA TRANSAÇÃO.

Para CADA transação identifique:
- Data no formato DD/MM/YYYY (converta para YYYY-MM-DD)
- Descrição COMPLETA (texto original sem abreviações)
- Valor numérico
- Tipo: "C" se for CRÉDITO/ENTRADA (dinheiro entrando), "D" se for DÉBITO/SAÍDA (dinheiro saindo)
- Documento/Referência (número de operação, NSU, código, etc.)
- Beneficiário/Pagador (extraia da descrição se possível)

**REGRAS CRÍTICAS:**
1. SEMPRE extraia TODAS as transações do extrato - não há limite
2. Ignore linhas de saldo inicial/final - apenas transações
3. Valores de DÉBITO devem ser NEGATIVOS
4. Valores de CRÉDITO devem ser POSITIVOS
5. Se houver "+", "Cr" ou "C" = CRÉDITO (positivo)
6. Se houver "-", "Db" ou "D" = DÉBITO (negativo)
7. Mantenha descrições completas e legíveis
8. Se a data estiver em DD/MM/YYYY, converta para YYYY-MM-DD
9. Se encontrar "SALDO ANTERIOR" ou "SALDO INICIAL", ignore
10. Processe ATÉ O FIM DO DOCUMENTO

Retorne em JSON estruturado conforme schema.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: extractionPrompt,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            banco: { 
              type: "string", 
              description: "Nome completo do banco" 
            },
            agencia: { 
              type: "string", 
              description: "Número da agência" 
            },
            conta: { 
              type: "string", 
              description: "Número da conta com dígito" 
            },
            titular: { 
              type: "string", 
              description: "Nome do titular" 
            },
            periodo: { 
              type: "string", 
              description: "Período do extrato" 
            },
            total_transacoes: {
              type: "number",
              description: "Total de transações extraídas"
            },
            transactions: {
              type: "array",
              description: "TODAS as transações do extrato",
              items: {
                type: "object",
                properties: {
                  date: { 
                    type: "string", 
                    description: "Data YYYY-MM-DD" 
                  },
                  description: { 
                    type: "string", 
                    description: "Descrição completa" 
                  },
                  amount: { 
                    type: "number", 
                    description: "Valor (+ crédito, - débito)" 
                  },
                  type: { 
                    type: "string", 
                    enum: ["C", "D"],
                    description: "C=crédito, D=débito" 
                  },
                  document_number: { 
                    type: "string", 
                    description: "Documento/referência" 
                  },
                  beneficiary: { 
                    type: "string", 
                    description: "Beneficiário/pagador" 
                  },
                },
              },
            },
          },
        },
      });

      setUploadProgress(80);

      if (result?.transactions && result.transactions.length > 0) {
        const bankName = result.banco || "Banco não identificado";
        const agency = result.agencia || "N/A";
        const account = result.conta || "N/A";
        
        setDetectedBank(bankName);
        setDetectedAgency(agency);
        setDetectedAccount(account);

        setUploadProgress(90);
        toast.info(`📊 Processando ${result.transactions.length} transações identificadas...`);

        const processed = result.transactions.map((t, index) => {
          const isCredit = t.type === "C" || t.amount > 0;
          const absoluteAmount = Math.abs(t.amount);
          
          return {
            id: `temp-${index}`,
            type: isCredit ? "receita" : "despesa",
            description: t.description || "Transação importada",
            amount: absoluteAmount,
            due_date: t.date || format(new Date(), "yyyy-MM-dd"),
            issue_date: t.date || format(new Date(), "yyyy-MM-dd"),
            payment_date: t.date || format(new Date(), "yyyy-MM-dd"),
            status: "pago",
            supplier_name: !isCredit ? (t.beneficiary || null) : null,
            client_name: isCredit ? (t.beneficiary || null) : null,
            document_number: t.document_number || null,
            category: null,
            payment_method: "transferencia_bancaria",
            bank_account: null,
          };
        });

        setExtractedTransactions(processed);
        
        const allIds = new Set(processed.map((t) => t.id));
        setSelectedTransactions(allIds);

        setUploadProgress(100);
        setProcessingStage("review");
        setShowReview(true);

        const matchedAccount = bankAccounts.find(ba => 
          ba.bank?.toLowerCase().includes(bankName.toLowerCase()) ||
          ba.agency === agency ||
          ba.account_number?.includes(account.replace(/\D/g, ''))
        );

        if (matchedAccount) {
          setSelectedBankAccount(matchedAccount.name);
          toast.success(`✅ ${processed.length} transações processadas! Conta "${matchedAccount.name}" detectada.`);
        } else {
          toast.success(`✅ ${processed.length} transações processadas! Selecione a conta correspondente.`);
        }

      } else {
        setUploadProgress(100);
        toast.error("❌ Não foi possível extrair transações. Verifique se o PDF está legível.");
        setProcessingStage("");
      }
    } catch (error) {
      console.error("Erro ao processar extrato:", error);
      toast.error("❌ Erro ao processar o extrato PDF. Tente novamente.");
      setProcessingStage("");
      setUploadProgress(0);
    }
  };

  const toggleTransaction = (id) => {
    const newSelected = new Set(selectedTransactions);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedTransactions(newSelected);
  };

  const toggleAll = () => {
    if (selectedTransactions.size === extractedTransactions.length) {
      setSelectedTransactions(new Set());
    } else {
      const allIds = new Set(extractedTransactions.map((t) => t.id));
      setSelectedTransactions(allIds);
    }
  };

  const handleConfirmImport = async () => {
    if (selectedTransactions.size === 0) {
      toast.error("❌ Selecione ao menos uma transação");
      return;
    }

    if (!selectedBankAccount) {
      toast.error("❌ Selecione a conta bancária para importação");
      return;
    }

    setProcessing(true);
    toast.info("💾 Salvando lançamentos no sistema...");
    
    const transactionsToImport = extractedTransactions
      .filter((t) => selectedTransactions.has(t.id))
      .map(({ id, ...transaction }) => ({
        ...transaction,
        bank_account: selectedBankAccount,
      }));

    await createTransactionsMutation.mutateAsync(transactionsToImport);
    setProcessing(false);
  };

  const handleClearFile = () => {
    setFile(null);
    setExtractedTransactions([]);
    setSelectedTransactions(new Set());
    setDetectedBank(null);
    setDetectedAccount(null);
    setDetectedAgency(null);
    setShowReview(false);
    setProcessingStage("");
    setUploadProgress(0);
  };

  // Lançamento por VOZ
  const handleVoiceInput = async () => {
    if (!('webkitSpeechRecognition' in window)) {
      toast.error("❌ Seu navegador não suporta reconhecimento de voz");
      return;
    }

    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'pt-BR';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => {
      setIsRecording(true);
      toast.info("🎤 Fale agora...");
    };

    recognition.onresult = async (event) => {
      const transcript = event.results[0][0].transcript;
      setIsRecording(false);
      
      toast.info("🤖 Processando com IA...");
      
      try {
        const result = await base44.integrations.Core.InvokeLLM({
          prompt: `Analise este comando de voz para lançamento financeiro: "${transcript}"

Identifique: tipo (receita/despesa), valor, descrição, categoria, data.
Retorne em JSON estruturado.`,
          response_json_schema: {
            type: "object",
            properties: {
              type: { type: "string", enum: ["receita", "despesa"] },
              amount: { type: "number" },
              description: { type: "string" },
              category: { type: "string" },
              date: { type: "string" },
            },
          },
        });

        if (result) {
          const transaction = {
            ...result,
            due_date: result.date || format(new Date(), "yyyy-MM-dd"),
            status: "pago",
            payment_date: format(new Date(), "yyyy-MM-dd"),
            payment_method: "dinheiro",
          };

          if (!bankAccounts.length) {
            toast.error("❌ Cadastre uma conta bancária antes");
            return;
          }

          await base44.entities.Transaction.create({
            ...transaction,
            bank_account: bankAccounts[0].name,
          });

          queryClient.invalidateQueries({ queryKey: ["transactions"] });
          toast.success("✅ Lançamento criado por voz!");
        }
      } catch (error) {
        toast.error("❌ Erro ao processar comando de voz");
      }
    };

    recognition.onerror = () => {
      setIsRecording(false);
      toast.error("❌ Erro no reconhecimento de voz");
    };

    recognition.onend = () => {
      setIsRecording(false);
    };

    recognition.start();
  };

  // Importação de RECIBO/NOTA com IA
  const handleReceiptUpload = async (e) => {
    const receiptFile = e.target.files[0];
    if (!receiptFile) return;

    const validTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
    if (!validTypes.includes(receiptFile.type)) {
      toast.error("❌ Formato inválido. Use PDF, JPG ou PNG");
      return;
    }

    toast.info("🤖 Processando recibo/nota com IA...");

    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: receiptFile });

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analise este recibo/nota fiscal e extraia TODOS os dados: tipo, valor total, data, fornecedor/cliente, descrição, documento, categoria, forma de pagamento.
Retorne em JSON estruturado.`,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            type: { type: "string", enum: ["receita", "despesa"] },
            amount: { type: "number" },
            description: { type: "string" },
            supplier_name: { type: "string" },
            client_name: { type: "string" },
            document_number: { type: "string" },
            invoice_number: { type: "string" },
            category: { type: "string" },
            date: { type: "string" },
            payment_method: { type: "string" },
          },
        },
      });

      if (result) {
        if (!bankAccounts.length) {
          toast.error("❌ Cadastre uma conta bancária antes");
          return;
        }

        await base44.entities.Transaction.create({
          ...result,
          due_date: result.date || format(new Date(), "yyyy-MM-dd"),
          issue_date: result.date || format(new Date(), "yyyy-MM-dd"),
          payment_date: format(new Date(), "yyyy-MM-dd"),
          status: "pago",
          bank_account: bankAccounts[0].name,
        });

        queryClient.invalidateQueries({ queryKey: ["transactions"] });
        toast.success("✅ Lançamento criado a partir do recibo/nota!");
      }
    } catch (error) {
      toast.error("❌ Erro ao processar recibo/nota");
    }
  };

  const getProgressMessage = () => {
    switch (processingStage) {
      case "uploading":
        return "📤 Fazendo upload do arquivo...";
      case "analyzing":
        return "🔍 Analisando cabeçalho e identificando banco/conta...";
      case "extracting":
        return "🤖 IA extraindo TODAS as transações (aguarde)...";
      case "review":
        return "✅ Processamento concluído! Revise as transações abaixo.";
      case "completed":
        return "🎉 Importação concluída com sucesso!";
      default:
        return "";
    }
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div>
        <h1 className="text-4xl font-bold text-white drop-shadow-lg">Importar Transações</h1>
        <p className="text-blue-200 mt-1">
          Importação inteligente: Extrato bancário, Recibo, Nota Fiscal ou por Voz
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Lançamento por VOZ */}
        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-800/80 to-purple-700/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Mic className="w-5 h-5" />
              Lançamento por Voz
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button
              onClick={handleVoiceInput}
              disabled={isRecording}
              className="w-full bg-purple-600 hover:bg-purple-700"
              size="lg"
            >
              {isRecording ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Ouvindo...
                </>
              ) : (
                <>
                  <Mic className="w-5 h-5 mr-2" />
                  Clique para Falar
                </>
              )}
            </Button>
            <p className="text-sm text-purple-200 mt-3 text-center">
              Exemplo: "Despesa de 500 reais no supermercado"
            </p>
          </CardContent>
        </Card>

        {/* Importação de RECIBO/NOTA */}
        <Card className="border-orange-500/50 bg-gradient-to-br from-orange-800/80 to-orange-700/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5" />
              Importar Recibo/Nota
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Label
              htmlFor="receipt-upload"
              className="flex items-center justify-center w-full h-20 border-2 border-dashed border-orange-300 rounded-lg cursor-pointer hover:border-orange-400 transition-colors bg-orange-900/30"
            >
              <div className="text-center">
                <Upload className="w-8 h-8 text-orange-300 mx-auto mb-2" />
                <span className="text-sm text-orange-200">Clique para enviar PDF/JPG/PNG</span>
              </div>
              <Input
                id="receipt-upload"
                type="file"
                accept=".pdf,.jpg,.jpeg,.png"
                onChange={handleReceiptUpload}
                className="hidden"
              />
            </Label>
            <p className="text-sm text-orange-200 mt-3 text-center">
              IA fará leitura automática e criará o lançamento
            </p>
          </CardContent>
        </Card>
      </div>

      <Alert className="border-blue-400/50 bg-blue-900/50">
        <Sparkles className="h-4 w-4 text-blue-400" />
        <AlertDescription className="text-blue-200">
          <strong>Importação de Extrato Inteligente:</strong> Nossa IA lê o cabeçalho do PDF, identifica o banco e conta automaticamente, 
          processa TODAS as transações (mesmo centenas), e permite conferência antes de importar.
        </AlertDescription>
      </Alert>

      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Upload className="w-5 h-5" />
            Upload do Extrato Bancário (PDF)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="border-2 border-dashed border-blue-700 rounded-lg p-8 text-center hover:border-blue-500 transition-colors bg-blue-950/30">
            {!file ? (
              <div className="space-y-4">
                <div className="flex justify-center">
                  <div className="p-4 bg-blue-800/50 rounded-full">
                    <FileText className="w-12 h-12 text-blue-400" />
                  </div>
                </div>
                <div>
                  <Label
                    htmlFor="file-upload"
                    className="cursor-pointer text-blue-300 hover:text-blue-200 font-medium text-lg"
                  >
                    Clique para selecionar o extrato em PDF
                  </Label>
                  <Input
                    id="file-upload"
                    type="file"
                    accept=".pdf"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <p className="text-sm text-blue-400 mt-2">
                    ✅ Suporta extratos com 100, 500, 1000+ transações
                  </p>
                  <p className="text-xs text-blue-500 mt-1">
                    A IA lerá TODO o extrato, identificará banco/conta e processará linha por linha
                  </p>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between p-4 bg-blue-800/50 rounded-lg">
                <div className="flex items-center gap-3">
                  <FileText className="w-8 h-8 text-blue-400" />
                  <div className="text-left">
                    <p className="font-medium text-white">{file.name}</p>
                    <p className="text-sm text-blue-300">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={handleClearFile} className="text-blue-300 hover:text-white">
                  <X className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>

          {file && !showReview && (
            <Button
              onClick={handleUploadAndExtract}
              disabled={processingStage !== ""}
              className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600"
              size="lg"
            >
              {processingStage ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Processando...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  Processar Extrato com IA
                </>
              )}
            </Button>
          )}

          {/* Barra de Progresso */}
          {processingStage && processingStage !== "completed" && (
            <div className="space-y-3 bg-blue-950/50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <p className="text-sm text-blue-200 font-medium">{getProgressMessage()}</p>
                <span className="text-xs text-blue-400">{uploadProgress}%</span>
              </div>
              <Progress value={uploadProgress} className="h-2" />
              <div className="flex items-center gap-2 text-xs text-blue-400">
                {processingStage === "uploading" && <><Loader2 className="w-3 h-3 animate-spin" /> Enviando arquivo...</>}
                {processingStage === "analyzing" && <><Search className="w-3 h-3 animate-pulse" /> Analisando cabeçalho...</>}
                {processingStage === "extracting" && <><Sparkles className="w-3 h-3 animate-pulse" /> IA processando todas as linhas...</>}
                {processingStage === "review" && <><Check className="w-3 h-3 text-green-400" /> Pronto para revisão!</>}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detecção Automática */}
      {detectedBank && detectedAccount && (
        <Card className="border-green-500/50 bg-gradient-to-br from-green-900/80 to-green-800/80 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <CheckCircle2 className="w-6 h-6 text-green-400" />
              ✅ Detecção Automática Concluída
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="border-green-400/50 bg-green-950/50">
              <CheckCircle2 className="h-4 w-4 text-green-400" />
              <AlertDescription className="text-green-200">
                <strong>Dados extraídos do cabeçalho do extrato:</strong>
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-green-950/50 p-4 rounded-lg border border-green-700/50">
                <p className="text-sm text-green-300 font-medium">Banco:</p>
                <p className="text-xl font-bold text-white mt-1">{detectedBank}</p>
              </div>
              <div className="bg-green-950/50 p-4 rounded-lg border border-green-700/50">
                <p className="text-sm text-green-300 font-medium">Agência:</p>
                <p className="text-xl font-bold text-white mt-1">{detectedAgency}</p>
              </div>
              <div className="bg-green-950/50 p-4 rounded-lg border border-green-700/50">
                <p className="text-sm text-green-300 font-medium">Conta:</p>
                <p className="text-xl font-bold text-white mt-1">{detectedAccount}</p>
              </div>
            </div>

            <div>
              <Label className="text-green-200 font-medium">Selecione a Conta Bancária Correspondente no Sistema:</Label>
              <Select value={selectedBankAccount} onValueChange={setSelectedBankAccount}>
                <SelectTrigger className="bg-green-950/50 border-green-700 text-white mt-2">
                  <SelectValue placeholder="⚠️ Escolha a conta que corresponde aos dados acima" />
                </SelectTrigger>
                <SelectContent className="bg-green-900 border-green-700">
                  {bankAccounts.map((ba) => (
                    <SelectItem key={ba.id} value={ba.name}>
                      {ba.name} - {ba.bank} {ba.agency ? `(Ag: ${ba.agency})` : ""} {ba.account_number ? `/ Conta: ${ba.account_number}` : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {!selectedBankAccount && (
                <p className="text-xs text-yellow-300 mt-2 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" />
                  Selecione a conta antes de importar
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Transações Extraídas */}
      {extractedTransactions.length > 0 && (
        <>
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-white">
                  <FileText className="w-5 h-5 text-blue-400" />
                  ✅ {extractedTransactions.length} Transações Processadas
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-sm text-blue-300 border-blue-500 bg-blue-950/50">
                    {selectedTransactions.size} selecionadas
                  </Badge>
                  <Button variant="outline" size="sm" onClick={toggleAll} className="border-blue-600 text-blue-300 hover:bg-blue-800">
                    {selectedTransactions.size === extractedTransactions.length
                      ? "Desmarcar Todas"
                      : "Selecionar Todas"}
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Alert className="mb-4 border-yellow-500/50 bg-yellow-900/30">
                <AlertCircle className="h-4 w-4 text-yellow-400" />
                <AlertDescription className="text-yellow-200">
                  <strong>⚠️ Conferência:</strong> Revise as transações abaixo. Marque apenas as que deseja importar.
                </AlertDescription>
              </Alert>

              <div className="overflow-x-auto max-h-[500px] overflow-y-auto border border-blue-700/50 rounded-lg">
                <Table>
                  <TableHeader className="sticky top-0 bg-blue-950/90 z-10">
                    <TableRow className="border-blue-700">
                      <TableHead className="w-12 text-blue-300">
                        <Checkbox
                          checked={selectedTransactions.size === extractedTransactions.length}
                          onCheckedChange={toggleAll}
                        />
                      </TableHead>
                      <TableHead className="text-blue-300">Data</TableHead>
                      <TableHead className="text-blue-300">Descrição</TableHead>
                      <TableHead className="text-blue-300">Fornecedor/Cliente</TableHead>
                      <TableHead className="text-blue-300">Tipo</TableHead>
                      <TableHead className="text-blue-300">Valor</TableHead>
                      <TableHead className="text-blue-300">Doc</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {extractedTransactions.map((transaction) => (
                      <TableRow
                        key={transaction.id}
                        className={`border-blue-700 hover:bg-blue-800/30 ${selectedTransactions.has(transaction.id) ? "bg-blue-800/50" : ""}`}
                      >
                        <TableCell>
                          <Checkbox
                            checked={selectedTransactions.has(transaction.id)}
                            onCheckedChange={() => toggleTransaction(transaction.id)}
                          />
                        </TableCell>
                        <TableCell className="font-medium text-white">
                          {format(new Date(transaction.due_date), "dd/MM/yyyy")}
                        </TableCell>
                        <TableCell className="max-w-xs text-blue-100">
                          <div className="truncate">{transaction.description}</div>
                        </TableCell>
                        <TableCell className="text-sm text-blue-200">{transaction.supplier_name || transaction.client_name || "-"}</TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              transaction.type === "receita"
                                ? "text-green-300 border-green-500 bg-green-900/30"
                                : "text-red-300 border-red-500 bg-red-900/30"
                            }
                          >
                            {transaction.type === "receita" ? "Receita" : "Despesa"}
                          </Badge>
                        </TableCell>
                        <TableCell
                          className={`font-semibold ${
                            transaction.type === "receita" ? "text-green-300" : "text-red-300"
                          }`}
                        >
                          R$ {transaction.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                        </TableCell>
                        <TableCell className="text-sm text-blue-300">
                          {transaction.document_number || "-"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* Botão de Confirmação */}
          <Card className="border-2 border-green-500/50 bg-gradient-to-br from-green-900/80 to-green-800/80 backdrop-blur-sm shadow-2xl">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold text-white flex items-center gap-2">
                    <CheckCircle2 className="w-6 h-6 text-green-400" />
                    Confirmar Importação
                  </h3>
                  <p className="text-sm text-green-200 mt-2">
                    ✅ {selectedTransactions.size} transação(ões) será(ão) importada(s) para: <strong>{selectedBankAccount || "Nenhuma conta selecionada"}</strong>
                  </p>
                  {!selectedBankAccount && (
                    <p className="text-xs text-red-300 mt-1 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      ⚠️ Selecione a conta bancária acima antes de continuar
                    </p>
                  )}
                </div>
                <Button
                  onClick={handleConfirmImport}
                  disabled={selectedTransactions.size === 0 || processing || !selectedBankAccount}
                  className="bg-green-600 hover:bg-green-700 disabled:opacity-50"
                  size="lg"
                >
                  {processing ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Importando...
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-5 h-5 mr-2" />
                      Confirmar e Importar
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}