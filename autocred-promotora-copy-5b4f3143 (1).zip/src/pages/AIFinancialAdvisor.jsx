import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Brain,
  Send,
  TrendingUp,
  AlertCircle,
  Lightbulb,
  DollarSign,
  Target,
  BarChart3,
  Sparkles,
  RefreshCw,
  User,
  Bot,
  Shield,
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";

export default function AIFinancialAdvisor() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [riskProfile, setRiskProfile] = useState("moderado");
  const [investmentGoals, setInvestmentGoals] = useState("");
  const messagesEndRef = useRef(null);

  const { data: transactions = [] } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list("-due_date"),
    initialData: [],
  });

  const { data: goals = [] } = useQuery({
    queryKey: ["goals"],
    queryFn: () => base44.entities.Goal.list(),
    initialData: [],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list(),
    initialData: [],
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (transactions.length > 0 && messages.length === 0) {
      generateWelcomeMessage();
    }
  }, [transactions]);

  const generateWelcomeMessage = async () => {
    const totalReceitas = transactions.filter(t => t.type === "receita" && t.status === "pago").reduce((s, t) => s + t.amount, 0);
    const totalDespesas = transactions.filter(t => t.type === "despesa" && t.status === "pago").reduce((s, t) => s + t.amount, 0);
    const saldo = totalReceitas - totalDespesas;

    const welcomeMsg = {
      role: "assistant",
      content: `👋 Olá! Sou seu **Assessor Financeiro com IA**.

📊 Analisei suas finanças:
- **Receitas:** R$ ${totalReceitas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
- **Despesas:** R$ ${totalDespesas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
- **Saldo:** R$ ${saldo.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}

Como posso ajudar você hoje? Posso:
- 💡 Sugerir investimentos personalizados
- 📈 Analisar oportunidades de otimização
- 🎯 Criar estratégias para suas metas
- 🚨 Alertar sobre riscos e tendências
- 💰 Recomendar alocação de recursos`,
      timestamp: new Date().toISOString(),
    };

    setMessages([welcomeMsg]);
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage = {
      role: "user",
      content: input,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      // Preparar contexto financeiro
      const totalReceitas = transactions.filter(t => t.type === "receita" && t.status === "pago").reduce((s, t) => s + t.amount, 0);
      const totalDespesas = transactions.filter(t => t.type === "despesa" && t.status === "pago").reduce((s, t) => s + t.amount, 0);
      const saldo = totalReceitas - totalDespesas;

      const categoriesBreakdown = categories.map(cat => {
        const total = transactions.filter(t => t.category === cat.name && t.status === "pago").reduce((s, t) => s + t.amount, 0);
        return `${cat.name}: R$ ${total.toFixed(2)}`;
      }).join('\n');

      const goalsInfo = goals.map(g => `${g.name} - Meta: R$ ${g.target_value} - Atual: R$ ${g.current_value || 0}`).join('\n');

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Você é um ASSESSOR FINANCEIRO EXPERT certificado CFA/CFP.

CONTEXTO FINANCEIRO DO CLIENTE:
- Receitas Totais: R$ ${totalReceitas.toFixed(2)}
- Despesas Totais: R$ ${totalDespesas.toFixed(2)}
- Saldo Atual: R$ ${saldo.toFixed(2)}
- Perfil de Risco: ${riskProfile}
- Objetivos de Investimento: ${investmentGoals || "Não especificado"}

CATEGORIAS:
${categoriesBreakdown}

METAS:
${goalsInfo || "Nenhuma meta cadastrada"}

HISTÓRICO DE CONVERSA:
${messages.slice(-5).map(m => `${m.role}: ${m.content}`).join('\n')}

PERGUNTA DO CLIENTE:
${input}

INSTRUÇÕES:
1. Forneça uma resposta PROFISSIONAL e PERSONALIZADA
2. Baseie-se nos dados financeiros reais do cliente
3. Se sugerir investimentos, considere o perfil de risco
4. Seja específico e acionável
5. Explique riscos e oportunidades
6. Use dados do mercado brasileiro (Tesouro Direto, CDB, LCI/LCA, Fundos, Ações)
7. Inclua números e percentuais quando relevante
8. Use formatação Markdown para facilitar leitura

RESPONDA DE FORMA CLARA E OBJETIVA:`,
        add_context_from_internet: true, // Adiciona contexto de tendências de mercado
      });

      const aiMessage = {
        role: "assistant",
        content: response,
        timestamp: new Date().toISOString(),
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      toast.error("Erro ao consultar assessor");
      console.error(error);
    }

    setLoading(false);
  };

  const quickQuestions = [
    "Como posso otimizar meus gastos?",
    "Quais investimentos me recomenda?",
    "Como atingir minhas metas financeiras?",
    "Quais são os riscos na minha situação?",
    "Como preparar reserva de emergência?",
  ];

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-4xl font-bold text-white flex items-center gap-3">
            <Brain className="w-10 h-10 text-blue-400" />
            Assessor Financeiro com IA
          </h1>
          <p className="text-blue-200 mt-2">Consultoria personalizada com análise em tempo real</p>
        </div>
        <Button onClick={generateWelcomeMessage} variant="outline" className="border-blue-600 text-blue-300">
          <RefreshCw className="w-4 h-4 mr-2" />
          Reiniciar
        </Button>
      </div>

      {/* Perfil e Configuração */}
      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-400" />
            Configuração do Perfil de Investimento
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-blue-200 mb-2 block">Perfil de Risco</label>
              <Select value={riskProfile} onValueChange={setRiskProfile}>
                <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-blue-900 border-blue-700">
                  <SelectItem value="conservador">🛡️ Conservador (Baixo Risco)</SelectItem>
                  <SelectItem value="moderado">⚖️ Moderado (Risco Equilibrado)</SelectItem>
                  <SelectItem value="agressivo">🚀 Agressivo (Alto Risco)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm text-blue-200 mb-2 block">Objetivo Principal</label>
              <Input
                value={investmentGoals}
                onChange={(e) => setInvestmentGoals(e.target.value)}
                placeholder="Ex: Aposentadoria, Casa própria..."
                className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Chat Interface */}
      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-blue-400" />
            Conversa com o Assessor
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Messages */}
          <div className="h-[500px] overflow-y-auto space-y-4 bg-blue-950/30 p-4 rounded-lg border border-blue-700">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                {msg.role === "assistant" && (
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                )}
                <div className={`max-w-[80%] ${msg.role === "user" ? "bg-blue-600" : "bg-blue-800/80"} p-4 rounded-lg`}>
                  <ReactMarkdown className="prose prose-invert prose-sm max-w-none text-white">
                    {msg.content}
                  </ReactMarkdown>
                  <p className="text-xs text-blue-300 mt-2 opacity-60">
                    {new Date(msg.timestamp).toLocaleTimeString("pt-BR")}
                  </p>
                </div>
                {msg.role === "user" && (
                  <div className="w-10 h-10 bg-gradient-to-br from-green-600 to-green-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="w-5 h-5 text-white" />
                  </div>
                )}
              </div>
            ))}
            {loading && (
              <div className="flex gap-3 justify-start">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-500 rounded-full flex items-center justify-center">
                  <Bot className="w-5 h-5 text-white" />
                </div>
                <div className="bg-blue-800/80 p-4 rounded-lg">
                  <div className="flex gap-2">
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Questions */}
          <div className="flex flex-wrap gap-2">
            {quickQuestions.map((q, i) => (
              <Button
                key={i}
                onClick={() => {
                  setInput(q);
                  setTimeout(() => handleSend(), 100);
                }}
                size="sm"
                variant="outline"
                className="border-blue-600 text-blue-300 hover:bg-blue-700"
              >
                {q}
              </Button>
            ))}
          </div>

          {/* Input */}
          <div className="flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Digite sua pergunta financeira..."
              rows={2}
              className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
            />
            <Button onClick={handleSend} disabled={loading || !input.trim()} className="bg-gradient-to-r from-blue-600 to-blue-500">
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Informações */}
      <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-purple-400" />
            Sobre o Assessor Financeiro
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-purple-200 text-sm">
          <p>✅ Análise em tempo real dos seus dados financeiros</p>
          <p>✅ Recomendações personalizadas baseadas no seu perfil de risco</p>
          <p>✅ Sugestões de investimentos do mercado brasileiro</p>
          <p>✅ Alertas proativos sobre tendências e oportunidades</p>
          <p>✅ Integração com suas metas e objetivos financeiros</p>
        </CardContent>
      </Card>
    </div>
  );
}