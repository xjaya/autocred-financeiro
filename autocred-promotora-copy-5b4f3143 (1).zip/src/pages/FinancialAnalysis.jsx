import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, RefreshCw, TrendingUp, TrendingDown, AlertTriangle, DollarSign, Target, Users } from "lucide-react";
import { startOfMonth, endOfMonth } from "date-fns";

export default function FinancialAnalysis() {
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);

  const { data: transactions = [] } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list("-due_date"),
    initialData: [],
  });

  const { data: goals = [] } = useQuery({
    queryKey: ["goals"],
    queryFn: () => base44.entities.Goal.list(),
    initialData: [],
  });

  const currentMonth = new Date();
  const startMonth = startOfMonth(currentMonth);
  const endMonth = endOfMonth(currentMonth);

  const monthTransactions = transactions.filter((t) => {
    const tDate = new Date(t.due_date);
    return tDate >= startMonth && tDate <= endMonth;
  });

  const totalReceitas = monthTransactions.filter(t => t.type === "receita" && t.status === "pago").reduce((sum, t) => sum + t.amount, 0);
  const totalDespesas = monthTransactions.filter(t => t.type === "despesa" && t.status === "pago").reduce((sum, t) => sum + t.amount, 0);
  const saldo = totalReceitas - totalDespesas;
  const margemLucro = totalReceitas > 0 ? ((saldo / totalReceitas) * 100) : 0;

  const despesasPorCategoria = monthTransactions
    .filter(t => t.type === "despesa" && t.status === "pago")
    .reduce((acc, t) => {
      const cat = t.category || "Outras";
      acc[cat] = (acc[cat] || 0) + t.amount;
      return acc;
    }, {});

  const topDespesas = Object.entries(despesasPorCategoria)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  const generateAnalysis = async () => {
    setLoading(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Análise Financeira Completa:

FATURAMENTO: R$ ${totalReceitas.toFixed(2)}
DESPESAS: R$ ${totalDespesas.toFixed(2)}
LUCRO: R$ ${saldo.toFixed(2)}
MARGEM: ${margemLucro.toFixed(2)}%

TOP 5 DESPESAS: ${topDespesas.map(([cat, val]) => `${cat}: R$ ${val.toFixed(2)}`).join(', ')}

METAS: ${goals.length} metas cadastradas

FORNEÇA ANÁLISE FINANCEIRA COMPLETA EM 3 SEÇÕES:

🟢 PONTOS POSITIVOS
- Liste tudo que está funcionando bem
- Indicadores saudáveis
- Práticas acertadas

🟠 ALERTAS
- Tendências preocupantes
- Áreas que precisam atenção
- Riscos moderados
- Sugestões de melhoria

🔴 CRÍTICO
- Problemas urgentes
- Ameaças graves
- Ações imediatas necessárias

Seja específico, direto e prático em cada ponto.`,
      });
      setAiAnalysis(result);
    } catch (error) {
      console.error("Erro:", error);
    }
    setLoading(false);
  };

  useEffect(() => {
    if (transactions.length > 0) generateAnalysis();
  }, [transactions.length]);

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold text-white">Análise Financeira</h1>
          <p className="text-blue-200 mt-1">Diagnóstico completo com IA</p>
        </div>
        <Button onClick={generateAnalysis} disabled={loading} className="bg-gradient-to-r from-purple-600 to-purple-500">
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} />
          Atualizar Análise
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-green-500/50 bg-gradient-to-br from-green-900/80 to-green-800/80">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-200">Receitas</p>
                <p className="text-2xl font-bold text-white mt-1">R$ {totalReceitas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-green-300 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-red-500/50 bg-gradient-to-br from-red-900/80 to-red-800/80">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-200">Despesas</p>
                <p className="text-2xl font-bold text-white mt-1">R$ {totalDespesas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
              </div>
              <TrendingDown className="w-10 h-10 text-red-300 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-500/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-200">Lucro</p>
                <p className={`text-2xl font-bold mt-1 ${saldo >= 0 ? "text-white" : "text-red-300"}`}>
                  R$ {saldo.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </p>
              </div>
              <DollarSign className="w-10 h-10 text-blue-300 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-200">Margem</p>
                <p className="text-2xl font-bold text-white mt-1">{margemLucro.toFixed(1)}%</p>
              </div>
              <Target className="w-10 h-10 text-purple-300 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {aiAnalysis && (
        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/90 to-blue-900/90 backdrop-blur-sm shadow-2xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-white">
              <Sparkles className="w-6 h-6 text-purple-400" />
              Diagnóstico Financeiro com IA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose prose-invert max-w-none text-sm whitespace-pre-wrap text-white leading-relaxed">
              {aiAnalysis}
            </div>
          </CardContent>
        </Card>
      )}

      {loading && (
        <Card className="border-purple-500/50 bg-purple-900/50">
          <CardContent className="py-8">
            <div className="flex items-center justify-center gap-3">
              <RefreshCw className="w-5 h-5 animate-spin text-purple-400" />
              <span className="text-purple-200">Gerando análise inteligente...</span>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white">Top 5 Categorias de Despesas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topDespesas.map(([cat, val], i) => (
              <div key={i} className="flex items-center justify-between bg-blue-950/50 p-4 rounded-lg">
                <span className="text-white font-medium">{cat}</span>
                <span className="text-red-300 font-bold">R$ {val.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}