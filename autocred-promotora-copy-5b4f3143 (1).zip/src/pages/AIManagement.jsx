import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Brain,
  Sparkles,
  TrendingUp,
  Edit,
  Trash2,
  Plus,
  RefreshCw,
  Target,
  Zap,
  Database,
  CheckCircle,
  AlertCircle,
} from "lucide-react";
import { toast } from "sonner";

export default function AIManagement() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingPattern, setEditingPattern] = useState(null);
  const [filterConfidence, setFilterConfidence] = useState("all");
  const queryClient = useQueryClient();

  const { data: aiLearnings = [], isLoading } = useQuery({
    queryKey: ["aiLearnings"],
    queryFn: () => base44.entities.AILearning.list("-last_used"),
    initialData: [],
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list("-due_date", 100),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.AILearning.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["aiLearnings"] });
      setShowDialog(false);
      setEditingPattern(null);
      toast.success("✅ Padrão criado com sucesso!");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.AILearning.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["aiLearnings"] });
      setShowDialog(false);
      setEditingPattern(null);
      toast.success("✅ Padrão atualizado!");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.AILearning.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["aiLearnings"] });
      toast.success("✅ Padrão excluído!");
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = {
      description_pattern: formData.get("description_pattern"),
      learned_category: formData.get("learned_category"),
      learned_subcategory: formData.get("learned_subcategory") || "",
      learned_cost_center: formData.get("learned_cost_center") || "",
      learned_supplier: formData.get("learned_supplier") || "",
      transaction_type: formData.get("transaction_type"),
      confidence_score: parseFloat(formData.get("confidence_score")) || 5,
      times_used: parseInt(formData.get("times_used")) || 0,
    };

    if (editingPattern) {
      updateMutation.mutate({ id: editingPattern.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filteredLearnings = aiLearnings.filter(l => {
    if (filterConfidence === "all") return true;
    if (filterConfidence === "high") return l.confidence_score >= 7;
    if (filterConfidence === "medium") return l.confidence_score >= 4 && l.confidence_score < 7;
    if (filterConfidence === "low") return l.confidence_score < 4;
    return true;
  });

  const performanceStats = {
    total: aiLearnings.length,
    highConfidence: aiLearnings.filter(l => l.confidence_score >= 7).length,
    mediumConfidence: aiLearnings.filter(l => l.confidence_score >= 4 && l.confidence_score < 7).length,
    lowConfidence: aiLearnings.filter(l => l.confidence_score < 4).length,
    totalUses: aiLearnings.reduce((sum, l) => sum + (l.times_used || 0), 0),
    avgConfidence: (aiLearnings.reduce((sum, l) => sum + (l.confidence_score || 0), 0) / (aiLearnings.length || 1)).toFixed(1),
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-4xl font-bold text-white flex items-center gap-3">
            <Brain className="w-10 h-10 text-purple-400" />
            Gerenciamento de IA
          </h1>
          <p className="text-blue-200 mt-2">Visualize, edite e monitore os padrões de aprendizado da IA</p>
        </div>
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingPattern(null)} className="bg-gradient-to-r from-purple-600 to-purple-500">
              <Plus className="w-4 h-4 mr-2" />
              Novo Padrão
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl bg-blue-900 border-blue-700">
            <DialogHeader>
              <DialogTitle className="text-white">
                {editingPattern ? "Editar Padrão de IA" : "Novo Padrão de IA"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Tipo de Transação*</Label>
                  <Select name="transaction_type" defaultValue={editingPattern?.transaction_type || "despesa"} required>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      <SelectItem value="receita">Receita</SelectItem>
                      <SelectItem value="despesa">Despesa</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-blue-200">Confiança (0-10)*</Label>
                  <Input
                    name="confidence_score"
                    type="number"
                    step="0.1"
                    min="0"
                    max="10"
                    defaultValue={editingPattern?.confidence_score || 5}
                    required
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
              </div>
              <div>
                <Label className="text-blue-200">Padrão de Descrição*</Label>
                <Input
                  name="description_pattern"
                  defaultValue={editingPattern?.description_pattern}
                  placeholder="Ex: pix, transferencia, cartao"
                  required
                  className="bg-blue-950/50 border-blue-700 text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Categoria Aprendida*</Label>
                  <Input
                    name="learned_category"
                    defaultValue={editingPattern?.learned_category}
                    required
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Subcategoria</Label>
                  <Input
                    name="learned_subcategory"
                    defaultValue={editingPattern?.learned_subcategory}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Centro de Custo</Label>
                  <Input
                    name="learned_cost_center"
                    defaultValue={editingPattern?.learned_cost_center}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Fornecedor/Cliente</Label>
                  <Input
                    name="learned_supplier"
                    defaultValue={editingPattern?.learned_supplier}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
              </div>
              <div>
                <Label className="text-blue-200">Vezes Utilizado</Label>
                <Input
                  name="times_used"
                  type="number"
                  defaultValue={editingPattern?.times_used || 0}
                  className="bg-blue-950/50 border-blue-700 text-white"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setShowDialog(false)} className="border-blue-700 text-blue-200">
                  Cancelar
                </Button>
                <Button type="submit" className="bg-gradient-to-r from-purple-600 to-purple-500">
                  {editingPattern ? "Atualizar" : "Criar"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* ESTATÍSTICAS */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
          <CardContent className="pt-6">
            <p className="text-xs text-purple-200">Total Padrões</p>
            <p className="text-2xl font-bold text-white">{performanceStats.total}</p>
          </CardContent>
        </Card>
        <Card className="border-green-500/50 bg-gradient-to-br from-green-900/80 to-green-800/80">
          <CardContent className="pt-6">
            <p className="text-xs text-green-200">Alta Confiança</p>
            <p className="text-2xl font-bold text-white">{performanceStats.highConfidence}</p>
          </CardContent>
        </Card>
        <Card className="border-yellow-500/50 bg-gradient-to-br from-yellow-900/80 to-yellow-800/80">
          <CardContent className="pt-6">
            <p className="text-xs text-yellow-200">Média Confiança</p>
            <p className="text-2xl font-bold text-white">{performanceStats.mediumConfidence}</p>
          </CardContent>
        </Card>
        <Card className="border-red-500/50 bg-gradient-to-br from-red-900/80 to-red-800/80">
          <CardContent className="pt-6">
            <p className="text-xs text-red-200">Baixa Confiança</p>
            <p className="text-2xl font-bold text-white">{performanceStats.lowConfidence}</p>
          </CardContent>
        </Card>
        <Card className="border-blue-500/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
          <CardContent className="pt-6">
            <p className="text-xs text-blue-200">Total Usos</p>
            <p className="text-2xl font-bold text-white">{performanceStats.totalUses}</p>
          </CardContent>
        </Card>
        <Card className="border-indigo-500/50 bg-gradient-to-br from-indigo-900/80 to-indigo-800/80">
          <CardContent className="pt-6">
            <p className="text-xs text-indigo-200">Confiança Média</p>
            <p className="text-2xl font-bold text-white">{performanceStats.avgConfidence}</p>
          </CardContent>
        </Card>
      </div>

      {/* PADRÕES DE IA */}
      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-400" />
              Padrões de Aprendizado
            </CardTitle>
            <Select value={filterConfidence} onValueChange={setFilterConfidence}>
              <SelectTrigger className="w-40 bg-blue-950/50 border-blue-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-blue-900 border-blue-700">
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="high">Alta Confiança</SelectItem>
                <SelectItem value="medium">Média Confiança</SelectItem>
                <SelectItem value="low">Baixa Confiança</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-blue-950/50 border-blue-700">
                  <TableHead className="text-blue-300">Padrão</TableHead>
                  <TableHead className="text-blue-300">Tipo</TableHead>
                  <TableHead className="text-blue-300">Categoria</TableHead>
                  <TableHead className="text-blue-300">Centro Custo</TableHead>
                  <TableHead className="text-blue-300">Fornecedor</TableHead>
                  <TableHead className="text-blue-300">Confiança</TableHead>
                  <TableHead className="text-blue-300">Usos</TableHead>
                  <TableHead className="text-right text-blue-300">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLearnings.map((learning) => (
                  <TableRow key={learning.id} className="border-blue-700 hover:bg-blue-800/30">
                    <TableCell className="text-white font-medium">{learning.description_pattern}</TableCell>
                    <TableCell>
                      <Badge className={learning.transaction_type === "receita" ? "bg-green-500" : "bg-red-500"}>
                        {learning.transaction_type}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-blue-200">{learning.learned_category}</TableCell>
                    <TableCell className="text-blue-200">{learning.learned_cost_center || "-"}</TableCell>
                    <TableCell className="text-blue-200">{learning.learned_supplier || "-"}</TableCell>
                    <TableCell>
                      <Badge className={
                        learning.confidence_score >= 7 ? "bg-green-500" :
                        learning.confidence_score >= 4 ? "bg-yellow-500" : "bg-red-500"
                      }>
                        {learning.confidence_score?.toFixed(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-blue-200">{learning.times_used || 0}x</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setEditingPattern(learning);
                            setShowDialog(true);
                          }}
                          className="text-blue-300 hover:text-white hover:bg-blue-700"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            if (confirm("Excluir este padrão?")) {
                              deleteMutation.mutate(learning.id);
                            }
                          }}
                          className="text-red-400 hover:text-white hover:bg-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}