import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, RefreshCw, TrendingUp, TrendingDown, DollarSign } from "lucide-react";
import { startOfMonth, endOfMonth, format, eachDayOfInterval } from "date-fns";
import { ptBR } from "date-fns/locale";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import ReportFilters from "../components/reports/ReportFilters";
import ReportExportButtons from "../components/reports/ReportExportButtons";

export default function CashFlow() {
  const [startDate, setStartDate] = useState(format(startOfMonth(new Date()), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(endOfMonth(new Date()), "yyyy-MM-dd"));
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [loadingAI, setLoadingAI] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedCostCenter, setSelectedCostCenter] = useState("all");

  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list(),
    initialData: [],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list(),
    initialData: [],
  });

  const { data: costCenters = [] } = useQuery({
    queryKey: ["costCenters"],
    queryFn: () => base44.entities.CostCenter.list(),
    initialData: [],
  });

  const filteredTransactions = transactions.filter((t) => {
    const tDate = new Date(t.due_date);
    const dateMatch = tDate >= new Date(startDate) && tDate <= new Date(endDate);
    const categoryMatch = selectedCategory === "all" || t.category === selectedCategory;
    const costCenterMatch = selectedCostCenter === "all" || t.cost_center === selectedCostCenter;
    return dateMatch && categoryMatch && costCenterMatch;
  });

  const totalEntradas = filteredTransactions.filter(t => t.type === "receita" && t.status === "pago").reduce((sum, t) => sum + t.amount, 0);
  const totalSaidas = filteredTransactions.filter(t => t.type === "despesa" && t.status === "pago").reduce((sum, t) => sum + t.amount, 0);
  const saldoFinal = totalEntradas - totalSaidas;

  const days = eachDayOfInterval({ start: new Date(startDate), end: new Date(endDate) });
  const dailyFlow = days.map((day) => {
    const dayStr = format(day, "yyyy-MM-dd");
    const dayTrans = filteredTransactions.filter(t => format(new Date(t.due_date), "yyyy-MM-dd") === dayStr && t.status === "pago");
    const entradas = dayTrans.filter(t => t.type === "receita").reduce((sum, t) => sum + t.amount, 0);
    const saidas = dayTrans.filter(t => t.type === "despesa").reduce((sum, t) => sum + t.amount, 0);
    return { date: format(day, "dd/MM", { locale: ptBR }), entradas, saidas, saldo: entradas - saidas };
  });

  const sampledData = dailyFlow.filter((_, index) => index % Math.ceil(dailyFlow.length / 30) === 0);

  const generateAIAnalysis = async () => {
    setLoadingAI(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analise Fluxo de Caixa de ${format(new Date(startDate), "dd/MM/yyyy")} a ${format(new Date(endDate), "dd/MM/yyyy")}:

ENTRADAS: R$ ${totalEntradas.toFixed(2)}
SAÍDAS: R$ ${totalSaidas.toFixed(2)}
SALDO: R$ ${saldoFinal.toFixed(2)}

DIAGNÓSTICO EM 3 SEÇÕES:

🟢 PONTOS POSITIVOS
- Fluxo saudável
- Liquidez adequada

🟠 ALERTAS
- Riscos de caixa
- Melhorias necessárias

🔴 CRÍTICO
- Problemas urgentes
- Falta de liquidez

Seja direto e objetivo.`,
      });

      setAiAnalysis(result);
    } catch (error) {
      console.error("Erro:", error);
    }
    setLoadingAI(false);
  };

  useEffect(() => {
    if (!isLoading && transactions.length > 0) {
      generateAIAnalysis();
    }
  }, [startDate, endDate, isLoading]);

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="w-8 h-8 text-blue-400 animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold text-white">Fluxo de Caixa</h1>
          <p className="text-blue-200 mt-1">Diagnóstico com IA</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={generateAIAnalysis} disabled={loadingAI} variant="outline" className="border-purple-600 text-purple-300 hover:bg-purple-700">
            <Sparkles className={`w-4 h-4 mr-2 ${loadingAI ? "animate-spin" : ""}`} />
            {loadingAI ? "Analisando..." : "IA Analisar"}
          </Button>
          <ReportExportButtons
            reportTitle="FluxoCaixa"
            data={filteredTransactions.filter(t => t.status === "pago")}
            columns={[
              { header: "Data", accessor: (t) => format(new Date(t.due_date), "dd/MM/yyyy") },
              { header: "Descrição", accessor: (t) => t.description },
              { header: "Tipo", accessor: (t) => t.type },
              { header: "Valor", accessor: (t) => t.amount.toFixed(2) }
            ]}
            startDate={startDate}
            endDate={endDate}
            onPdfExport={() => {
              const detailedTransactions = filteredTransactions.filter(t => t.status === "pago").sort((a, b) => new Date(a.due_date) - new Date(b.due_date));
            const printWindow = window.open('', '_blank');
            const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Fluxo de Caixa - ${format(new Date(startDate), "dd/MM/yyyy")} a ${format(new Date(endDate), "dd/MM/yyyy")}</title>
  <style>
    @page { size: A4; margin: 15mm; }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: 'Segoe UI', Arial, sans-serif;
      background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
      padding: 20px;
    }
    .container { 
      max-width: 210mm; 
      background: white; 
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.1);
    }
    .header { 
      text-align: center; 
      border-bottom: 3px solid #fa709a; 
      padding-bottom: 20px; 
      margin-bottom: 30px;
    }
    .header h1 { font-size: 28px; color: #fa709a; font-weight: 700; }
    .info-box { 
      background: linear-gradient(135deg, #fff1eb 0%, #ace0f9 100%);
      padding: 15px; 
      border-radius: 8px; 
      margin-bottom: 25px;
      border-left: 4px solid #fa709a;
    }
    .cards { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 30px; }
    .card { padding: 20px; border-radius: 10px; text-align: center; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    .card.green { background: linear-gradient(135deg, #0ba360 0%, #3cba92 100%); color: white; }
    .card.red { background: linear-gradient(135deg, #ee0979 0%, #ff6a00 100%); color: white; }
    .card.blue { background: linear-gradient(135deg, #30cfd0 0%, #330867 100%); color: white; }
    .card-label { font-size: 12px; text-transform: uppercase; font-weight: 600; }
    .card-value { font-size: 22px; font-weight: 700; margin-top: 8px; }
    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
    th { background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); color: #1a1a1a; padding: 12px; text-align: left; font-size: 13px; }
    td { padding: 12px; border-bottom: 1px solid #e5e7eb; font-size: 13px; }
    .total-row { background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); color: #1a1a1a !important; font-weight: 700; }
    .footer { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 2px solid #e5e7eb; color: #666; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>💰 Fluxo de Caixa</h1>
      <p>AUTOCRED PROMOTORA</p>
    </div>
    <div class="info-box">
      <p><strong>Período:</strong> ${format(new Date(startDate), "dd/MM/yyyy")} a ${format(new Date(endDate), "dd/MM/yyyy")}</p>
      <p><strong>Gerado em:</strong> ${format(new Date(), "dd/MM/yyyy 'às' HH:mm")}</p>
    </div>
    <div class="cards">
      <div class="card green">
        <div class="card-label">Entradas</div>
        <div class="card-value">R$ ${totalEntradas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
      </div>
      <div class="card red">
        <div class="card-label">Saídas</div>
        <div class="card-value">R$ ${totalSaidas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
      </div>
      <div class="card blue">
        <div class="card-label">Saldo Final</div>
        <div class="card-value">R$ ${saldoFinal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
      </div>
    </div>
    <table>
      <thead>
        <tr><th>Data</th><th>Descrição</th><th>Tipo</th><th>Categoria</th><th style="text-align: right;">Valor (R$)</th></tr>
      </thead>
      <tbody>
        ${detailedTransactions.map(t => `
        <tr>
          <td>${format(new Date(t.due_date), "dd/MM/yyyy")}</td>
          <td>${t.description || '-'}</td>
          <td><span style="color: ${t.type === 'receita' ? '#0ba360' : '#ee0979'}; font-weight: 600;">${t.type === 'receita' ? '↑ Entrada' : '↓ Saída'}</span></td>
          <td>${t.category || '-'}</td>
          <td style="text-align: right; color: ${t.type === 'receita' ? '#0ba360' : '#ee0979'}; font-weight: 600;">${t.type === 'receita' ? '+' : '-'} R$ ${t.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</td>
        </tr>`).join('')}
        <tr style="background: #f3f4f6;"><td colspan="4"><strong>TOTAL ENTRADAS</strong></td><td style="text-align: right; color: #0ba360; font-weight: 700;">+ R$ ${totalEntradas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</td></tr>
        <tr style="background: #f3f4f6;"><td colspan="4"><strong>TOTAL SAÍDAS</strong></td><td style="text-align: right; color: #ee0979; font-weight: 700;">- R$ ${totalSaidas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</td></tr>
        <tr class="total-row"><td colspan="4"><strong>SALDO FINAL</strong></td><td style="text-align: right;"><strong>R$ ${saldoFinal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</strong></td></tr>
      </tbody>
    </table>
    <div class="footer">
      <p>AUTOCRED PROMOTORA - Fluxo de Caixa</p>
      <p>Confidencial</p>
    </div>
  </div>
</body>
</html>`;
            printWindow.document.write(html);
            printWindow.document.close();
            setTimeout(() => printWindow.print(), 500);
            }}
          />
        </div>
      </div>

      <ReportFilters
        startDate={startDate}
        endDate={endDate}
        onStartDateChange={setStartDate}
        onEndDateChange={setEndDate}
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
        selectedCostCenter={selectedCostCenter}
        onCostCenterChange={setSelectedCostCenter}
        categories={categories}
        costCenters={costCenters}
        onReset={() => {
          setSelectedCategory("all");
          setSelectedCostCenter("all");
        }}
      />

      <div className="grid grid-cols-3 gap-6">
        <Card className="border-green-500/50 bg-gradient-to-br from-green-800/80 to-green-700/80">
          <CardContent className="pt-6">
            <p className="text-sm text-green-200">Entradas</p>
            <p className="text-3xl font-bold text-white mt-1">R$ {totalEntradas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
          </CardContent>
        </Card>

        <Card className="border-red-500/50 bg-gradient-to-br from-red-800/80 to-red-700/80">
          <CardContent className="pt-6">
            <p className="text-sm text-red-200">Saídas</p>
            <p className="text-3xl font-bold text-white mt-1">R$ {totalSaidas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
          </CardContent>
        </Card>

        <Card className="border-blue-500/50 bg-gradient-to-br from-blue-800/80 to-blue-700/80">
          <CardContent className="pt-6">
            <p className="text-sm text-blue-200">Saldo</p>
            <p className={`text-3xl font-bold mt-1 ${saldoFinal >= 0 ? "text-white" : "text-red-300"}`}>
              R$ {saldoFinal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </p>
          </CardContent>
        </Card>
      </div>

      {aiAnalysis && (
        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/90 to-blue-900/90 shadow-2xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Sparkles className="w-6 h-6 text-purple-400" />
              Diagnóstico de Fluxo de Caixa
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose prose-invert max-w-none text-sm whitespace-pre-wrap leading-relaxed text-white">
              {aiAnalysis}
            </div>
          </CardContent>
        </Card>
      )}

      {loadingAI && (
        <Card className="border-purple-500/50 bg-purple-900/50">
          <CardContent className="py-8">
            <div className="flex items-center justify-center gap-3">
              <RefreshCw className="w-5 h-5 animate-spin text-purple-400" />
              <span className="text-purple-200">Gerando diagnóstico...</span>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white">Evolução do Fluxo</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={sampledData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
              <XAxis dataKey="date" stroke="#93c5fd" fontSize={12} />
              <YAxis stroke="#93c5fd" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px", color: "#fff" }} />
              <Legend />
              <Line type="monotone" dataKey="entradas" stroke="#10B981" strokeWidth={2} name="Entradas" />
              <Line type="monotone" dataKey="saidas" stroke="#EF4444" strokeWidth={2} name="Saídas" />
              <Line type="monotone" dataKey="saldo" stroke="#3B82F6" strokeWidth={3} name="Saldo" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}