import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Download,
  Upload,
  Database,
  RefreshCw,
  Trash2,
  Clock,
  CheckCircle,
  AlertCircle,
  Archive,
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";

export default function BackupRestore() {
  const [creating, setCreating] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [progress, setProgress] = useState(0);

  const queryClient = useQueryClient();

  const { data: backups = [], isLoading } = useQuery({
    queryKey: ["backups"],
    queryFn: async () => {
      // Backups são salvos como registros no sistema
      const allBackups = await base44.entities.Report.list("-created_date");
      return allBackups.filter(r => r.type === "backup");
    },
    initialData: [],
  });

  const createBackupMutation = useMutation({
    mutationFn: async () => {
      setCreating(true);
      setProgress(10);

      // Buscar todos os dados
      const [transactions, contacts, categories, costCenters, bankAccounts, goals, transfers] = await Promise.all([
        base44.entities.Transaction.list(),
        base44.entities.Client.list(),
        base44.entities.Category.list(),
        base44.entities.CostCenter.list(),
        base44.entities.BankAccount.list(),
        base44.entities.Goal.list(),
        base44.entities.Transfer.list(),
      ]);

      setProgress(60);

      const backupData = {
        timestamp: new Date().toISOString(),
        version: "1.0",
        data: {
          transactions,
          contacts,
          categories,
          costCenters,
          bankAccounts,
          goals,
          transfers,
        },
        summary: {
          totalTransactions: transactions.length,
          totalContacts: contacts.length,
          totalCategories: categories.length,
          totalCostCenters: costCenters.length,
          totalBankAccounts: bankAccounts.length,
          totalGoals: goals.length,
          totalTransfers: transfers.length,
        }
      };

      setProgress(80);

      // Salvar backup como Report
      const backup = await base44.entities.Report.create({
        title: `Backup - ${format(new Date(), "dd/MM/yyyy HH:mm")}`,
        type: "backup",
        period_start: new Date().toISOString().split('T')[0],
        period_end: new Date().toISOString().split('T')[0],
        data: backupData,
        status: "finalizado",
      });

      setProgress(100);
      return backup;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["backups"] });
      toast.success("✅ Backup criado com sucesso!");
    },
    onError: (error) => {
      toast.error(`Erro ao criar backup: ${error.message}`);
    },
    onSettled: () => {
      setCreating(false);
      setProgress(0);
    }
  });

  const restoreBackupMutation = useMutation({
    mutationFn: async (backupId) => {
      setRestoring(true);
      setProgress(10);

      const backup = backups.find(b => b.id === backupId);
      if (!backup?.data?.data) throw new Error("Dados de backup inválidos");

      const { transactions, contacts, categories, costCenters, bankAccounts, goals, transfers } = backup.data.data;

      // Limpar dados atuais (CUIDADO!)
      setProgress(20);
      const currentTransactions = await base44.entities.Transaction.list();
      for (const trans of currentTransactions) {
        await base44.entities.Transaction.delete(trans.id);
      }

      setProgress(40);
      
      // Restaurar transações
      for (let i = 0; i < transactions.length; i++) {
        const { id, created_date, updated_date, created_by, ...transData } = transactions[i];
        await base44.entities.Transaction.create(transData);
        setProgress(40 + ((i / transactions.length) * 50));
      }

      setProgress(100);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      queryClient.invalidateQueries({ queryKey: ["backups"] });
      toast.success("✅ Backup restaurado com sucesso!");
    },
    onError: (error) => {
      toast.error(`Erro ao restaurar backup: ${error.message}`);
    },
    onSettled: () => {
      setRestoring(false);
      setProgress(0);
    }
  });

  const deleteBackupMutation = useMutation({
    mutationFn: (backupId) => base44.entities.Report.delete(backupId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["backups"] });
      toast.success("Backup excluído!");
    }
  });

  const downloadBackup = (backup) => {
    const dataStr = JSON.stringify(backup.data, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `backup-${backup.title.replace(/\s/g, '-')}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div>
        <h1 className="text-4xl font-bold text-white drop-shadow-lg">Backup e Restauração</h1>
        <p className="text-blue-200 mt-1">Proteja seus dados com backups automáticos</p>
      </div>

      {/* Criar Backup */}
      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Database className="w-5 h-5 text-blue-400" />
            Criar Novo Backup
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-blue-200 text-sm">
            Crie um backup completo de todos os seus dados incluindo transações, contatos, categorias e configurações.
          </p>

          {(creating || restoring) && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-blue-200">{creating ? "Criando backup..." : "Restaurando backup..."}</span>
                <span className="text-white font-medium">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2 bg-blue-950" />
            </div>
          )}

          <Button
            onClick={() => createBackupMutation.mutate()}
            disabled={creating || restoring}
            className="w-full bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600"
          >
            {creating ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Criando Backup...
              </>
            ) : (
              <>
                <Archive className="w-4 h-4 mr-2" />
                Criar Backup Manual
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Lista de Backups */}
      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white">Histórico de Backups</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {backups.map((backup) => (
              <div
                key={backup.id}
                className="bg-blue-950/50 p-4 rounded-lg border border-blue-700 hover:border-blue-500 transition-all"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    <Database className="w-8 h-8 text-blue-400 mt-1" />
                    <div className="flex-1">
                      <p className="text-white font-medium">{backup.title}</p>
                      <p className="text-sm text-blue-300 mt-1 flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        {format(new Date(backup.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                      {backup.data?.summary && (
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Badge className="bg-blue-500/20 text-blue-300 border-blue-500 text-xs">
                            {backup.data.summary.totalTransactions} Transações
                          </Badge>
                          <Badge className="bg-green-500/20 text-green-300 border-green-500 text-xs">
                            {backup.data.summary.totalContacts} Contatos
                          </Badge>
                          <Badge className="bg-purple-500/20 text-purple-300 border-purple-500 text-xs">
                            {backup.data.summary.totalCategories} Categorias
                          </Badge>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => downloadBackup(backup)}
                      className="text-green-400 hover:text-green-300 hover:bg-green-900/20"
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        if (confirm("⚠️ ATENÇÃO: Restaurar este backup irá substituir TODOS os dados atuais. Deseja continuar?")) {
                          restoreBackupMutation.mutate(backup.id);
                        }
                      }}
                      disabled={restoring}
                      className="text-blue-400 hover:text-blue-300 hover:bg-blue-900/20"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        if (confirm("Deseja excluir este backup?")) {
                          deleteBackupMutation.mutate(backup.id);
                        }
                      }}
                      className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}

            {backups.length === 0 && (
              <div className="text-center py-12">
                <Database className="w-16 h-16 text-blue-400 mx-auto mb-4 opacity-50" />
                <p className="text-blue-200">Nenhum backup encontrado</p>
                <p className="text-sm text-blue-300 mt-1">Crie seu primeiro backup acima</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}