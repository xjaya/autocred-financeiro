import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, FileText, Sparkles, CheckCircle, Clock, XCircle, Pencil, Eye } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

const statusColors = {
  analise: "bg-yellow-100 text-yellow-800",
  aprovado: "bg-blue-100 text-blue-800",
  ativo: "bg-green-100 text-green-800",
  finalizado: "bg-slate-100 text-slate-800",
  cancelado: "bg-red-100 text-red-800",
};

export default function Contracts() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingContract, setEditingContract] = useState(null);
  const [selectedContract, setSelectedContract] = useState(null);
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [loadingAI, setLoadingAI] = useState(false);

  const queryClient = useQueryClient();

  const { data: contracts = [], isLoading } = useQuery({
    queryKey: ["contracts"],
    queryFn: () => base44.entities.Contract.list("-created_date"),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Contract.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["contracts"] });
      setShowDialog(false);
      setEditingContract(null);
      toast.success("Contrato criado com sucesso!");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Contract.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["contracts"] });
      setShowDialog(false);
      setEditingContract(null);
      toast.success("Contrato atualizado com sucesso!");
    },
  });

  const activeContracts = contracts.filter((c) => c.status === "ativo");
  const totalValue = activeContracts.reduce((sum, c) => sum + (c.total_amount || 0), 0);
  const totalCommissions = activeContracts.reduce((sum, c) => sum + (c.commission_value || 0), 0);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    const loanAmount = parseFloat(formData.get("loan_amount"));
    const installments = parseInt(formData.get("installments"));
    const interestRate = parseFloat(formData.get("interest_rate"));
    
    const totalAmount = loanAmount * (1 + interestRate / 100);
    const installmentValue = totalAmount / installments;
    const commissionPercentage = parseFloat(formData.get("commission_percentage") || 2.5);
    const commissionValue = loanAmount * (commissionPercentage / 100);

    const data = {
      contract_number: formData.get("contract_number"),
      client_name: formData.get("client_name"),
      client_cpf: formData.get("client_cpf"),
      loan_amount: loanAmount,
      installments: installments,
      installment_value: installmentValue,
      interest_rate: interestRate,
      total_amount: totalAmount,
      margin: parseFloat(formData.get("margin")),
      contract_date: formData.get("contract_date"),
      first_due_date: formData.get("first_due_date"),
      status: formData.get("status"),
      bank: formData.get("bank"),
      seller_name: formData.get("seller_name"),
      commission_percentage: commissionPercentage,
      commission_value: commissionValue,
      notes: formData.get("notes"),
    };

    if (editingContract) {
      updateMutation.mutate({ id: editingContract.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const generateAIAnalysis = async (contract) => {
    setLoadingAI(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analise o seguinte contrato de crédito consignado e forneça insights:

Número do Contrato: ${contract.contract_number}
Cliente: ${contract.client_name}
Valor do Empréstimo: R$ ${contract.loan_amount?.toFixed(2)}
Número de Parcelas: ${contract.installments}
Valor da Parcela: R$ ${contract.installment_value?.toFixed(2)}
Taxa de Juros: ${contract.interest_rate}%
Valor Total: R$ ${contract.total_amount?.toFixed(2)}
Margem Consignável: R$ ${contract.margin?.toFixed(2)}
Status: ${contract.status}

Forneça:
1. Análise de viabilidade e risco
2. Avaliação da margem utilizada
3. Comparação com condições de mercado
4. Sugestões de otimização
5. Pontos de atenção`,
      });

      setAiAnalysis(result);
    } catch (error) {
      console.error("Erro ao gerar análise:", error);
      toast.error("Erro ao gerar análise de IA");
    }
    setLoadingAI(false);
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Contratos de Crédito</h1>
          <p className="text-slate-600 mt-1">Gerencie todos os contratos consignados</p>
        </div>
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingContract(null)} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Novo Contrato
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingContract ? "Editar Contrato" : "Novo Contrato"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Número do Contrato*</Label>
                  <Input name="contract_number" defaultValue={editingContract?.contract_number} required />
                </div>
                <div>
                  <Label>Status*</Label>
                  <Select name="status" defaultValue={editingContract?.status || "analise"} required>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="analise">Em Análise</SelectItem>
                      <SelectItem value="aprovado">Aprovado</SelectItem>
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="finalizado">Finalizado</SelectItem>
                      <SelectItem value="cancelado">Cancelado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Nome do Cliente*</Label>
                  <Input name="client_name" defaultValue={editingContract?.client_name} required />
                </div>
                <div>
                  <Label>CPF do Cliente*</Label>
                  <Input name="client_cpf" defaultValue={editingContract?.client_cpf} placeholder="000.000.000-00" required />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label>Valor do Empréstimo (R$)*</Label>
                  <Input name="loan_amount" type="number" step="0.01" defaultValue={editingContract?.loan_amount} required />
                </div>
                <div>
                  <Label>Número de Parcelas*</Label>
                  <Input name="installments" type="number" defaultValue={editingContract?.installments} required />
                </div>
                <div>
                  <Label>Taxa de Juros (%)*</Label>
                  <Input name="interest_rate" type="number" step="0.01" defaultValue={editingContract?.interest_rate} required />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Margem Consignável (R$)</Label>
                  <Input name="margin" type="number" step="0.01" defaultValue={editingContract?.margin} />
                </div>
                <div>
                  <Label>Banco Conveniado</Label>
                  <Input name="bank" defaultValue={editingContract?.bank} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Data do Contrato*</Label>
                  <Input name="contract_date" type="date" defaultValue={editingContract?.contract_date} required />
                </div>
                <div>
                  <Label>Primeiro Vencimento</Label>
                  <Input name="first_due_date" type="date" defaultValue={editingContract?.first_due_date} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Vendedor</Label>
                  <Input name="seller_name" defaultValue={editingContract?.seller_name} />
                </div>
                <div>
                  <Label>% Comissão</Label>
                  <Input name="commission_percentage" type="number" step="0.01" defaultValue={editingContract?.commission_percentage || 2.5} />
                </div>
              </div>

              <div>
                <Label>Observações</Label>
                <Textarea name="notes" defaultValue={editingContract?.notes} rows={3} />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  {editingContract ? "Atualizar" : "Criar"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Contratos Ativos</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">{activeContracts.length}</p>
              </div>
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Valor Total</p>
                <p className="text-2xl font-bold text-blue-600 mt-1">
                  R$ {totalValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </p>
              </div>
              <FileText className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Comissões Totais</p>
                <p className="text-2xl font-bold text-purple-600 mt-1">
                  R$ {totalCommissions.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {selectedContract && aiAnalysis && (
        <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-900">
              <Sparkles className="w-5 h-5 text-blue-600" />
              Análise Inteligente - Contrato {selectedContract.contract_number}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose prose-slate max-w-none text-sm whitespace-pre-wrap">{aiAnalysis}</div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="pt-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Contrato</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Parcelas</TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                [...Array(5)].map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-8 w-20" /></TableCell>
                  </TableRow>
                ))
              ) : contracts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-slate-500">
                    Nenhum contrato encontrado
                  </TableCell>
                </TableRow>
              ) : (
                contracts.map((contract) => (
                  <TableRow key={contract.id} className="hover:bg-slate-50">
                    <TableCell className="font-medium">{contract.contract_number}</TableCell>
                    <TableCell>{contract.client_name}</TableCell>
                    <TableCell className="font-semibold text-green-600">
                      R$ {contract.loan_amount?.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell>{contract.installments}x</TableCell>
                    <TableCell>{contract.contract_date ? format(new Date(contract.contract_date), "dd/MM/yyyy") : "-"}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={statusColors[contract.status]}>
                        {contract.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setSelectedContract(contract);
                            generateAIAnalysis(contract);
                          }}
                        >
                          <Sparkles className="w-4 h-4 text-blue-600" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setEditingContract(contract);
                            setShowDialog(true);
                          }}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}