import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Plus,
  ArrowRightLeft,
  Search,
  Sparkles,
  Edit,
  Trash2,
  CheckCircle,
  Clock,
  XCircle
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Skeleton } from "@/components/ui/skeleton";
import AIAssistant from "../components/AIAssistant";

export default function Transfers() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingTransfer, setEditingTransfer] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [aiSuggestion, setAiSuggestion] = useState(null);
  const [loadingAI, setLoadingAI] = useState(false);

  const queryClient = useQueryClient();

  const { data: transfers = [], isLoading } = useQuery({
    queryKey: ["transfers"],
    queryFn: () => base44.entities.Transfer.list("-transfer_date"),
    initialData: [],
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ["bankAccounts"],
    queryFn: () => base44.entities.BankAccount.list(),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Transfer.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transfers"] });
      setShowDialog(false);
      setEditingTransfer(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Transfer.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transfers"] });
      setShowDialog(false);
      setEditingTransfer(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Transfer.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transfers"] });
    },
  });

  const getAISuggestions = async () => {
    setLoadingAI(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analise o histórico de transferências e forneça:

HISTÓRICO: ${JSON.stringify(transfers.slice(0, 10))}
CONTAS DISPONÍVEIS: ${bankAccounts.map(a => a.name).join(", ")}

Forneça:
1. Sugestões de otimização de fluxo de caixa entre contas
2. Identificação de padrões de transferência
3. Recomendações para melhor distribuição de recursos
4. Alertas sobre concentração excessiva em uma conta
5. Dicas para reduzir taxas de transferência`,
      });
      setAiSuggestion(result);
    } catch (error) {
      console.error("Erro ao gerar sugestões:", error);
    }
    setLoadingAI(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    const data = {
      description: formData.get("description"),
      from_account: formData.get("from_account"),
      to_account: formData.get("to_account"),
      amount: parseFloat(formData.get("amount")),
      transfer_date: formData.get("transfer_date"),
      status: formData.get("status"),
      transfer_type: formData.get("transfer_type"),
      fee: parseFloat(formData.get("fee") || 0),
      notes: formData.get("notes"),
      reference_number: formData.get("reference_number"),
    };

    if (editingTransfer) {
      updateMutation.mutate({ id: editingTransfer.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filteredTransfers = transfers.filter((t) => {
    const matchesSearch =
      t.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.from_account?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.to_account?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === "all" || t.status === filterStatus;

    return matchesSearch && matchesStatus;
  });

  const totalTransferred = transfers
    .filter(t => t.status === "concluida")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const totalFees = transfers
    .filter(t => t.status === "concluida")
    .reduce((sum, t) => sum + (t.fee || 0), 0);

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white drop-shadow-lg">Transferências</h1>
          <p className="text-blue-200 mt-1">Gestão de transferências entre contas</p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={getAISuggestions}
            disabled={loadingAI}
            className="bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600"
          >
            <Sparkles className={`w-4 h-4 mr-2 ${loadingAI ? "animate-spin" : ""}`} />
            Sugestões IA
          </Button>
          <Dialog open={showDialog} onOpenChange={setShowDialog}>
            <DialogTrigger asChild>
              <Button 
                onClick={() => setEditingTransfer(null)}
                className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600 shadow-lg"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Transferência
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-blue-900 border-blue-700 text-white">
              <DialogHeader>
                <DialogTitle className="text-xl text-white">
                  {editingTransfer ? "Editar Transferência" : "Nova Transferência"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label className="text-blue-200">Descrição*</Label>
                  <Input
                    name="description"
                    defaultValue={editingTransfer?.description}
                    placeholder="Ex: Transferência para pagamento de fornecedores"
                    required
                    className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-blue-200">Conta de Origem*</Label>
                    <Select name="from_account" defaultValue={editingTransfer?.from_account} required>
                      <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent className="bg-blue-900 border-blue-700">
                        {bankAccounts.map((acc) => (
                          <SelectItem key={acc.id} value={acc.name}>
                            {acc.name} - {acc.bank}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-blue-200">Conta de Destino*</Label>
                    <Select name="to_account" defaultValue={editingTransfer?.to_account} required>
                      <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent className="bg-blue-900 border-blue-700">
                        {bankAccounts.map((acc) => (
                          <SelectItem key={acc.id} value={acc.name}>
                            {acc.name} - {acc.bank}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label className="text-blue-200">Valor (R$)*</Label>
                    <Input
                      name="amount"
                      type="number"
                      step="0.01"
                      defaultValue={editingTransfer?.amount}
                      placeholder="0,00"
                      required
                      className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                    />
                  </div>
                  <div>
                    <Label className="text-blue-200">Taxa (R$)</Label>
                    <Input
                      name="fee"
                      type="number"
                      step="0.01"
                      defaultValue={editingTransfer?.fee || 0}
                      placeholder="0,00"
                      className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                    />
                  </div>
                  <div>
                    <Label className="text-blue-200">Data*</Label>
                    <Input
                      name="transfer_date"
                      type="date"
                      defaultValue={editingTransfer?.transfer_date}
                      required
                      className="bg-blue-950/50 border-blue-700 text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-blue-200">Tipo de Transferência</Label>
                    <Select name="transfer_type" defaultValue={editingTransfer?.transfer_type || "interna"}>
                      <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-blue-900 border-blue-700">
                        <SelectItem value="interna">Interna</SelectItem>
                        <SelectItem value="entre_bancos">Entre Bancos</SelectItem>
                        <SelectItem value="investimento">Investimento</SelectItem>
                        <SelectItem value="resgate">Resgate</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-blue-200">Status</Label>
                    <Select name="status" defaultValue={editingTransfer?.status || "pendente"}>
                      <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-blue-900 border-blue-700">
                        <SelectItem value="pendente">Pendente</SelectItem>
                        <SelectItem value="concluida">Concluída</SelectItem>
                        <SelectItem value="cancelada">Cancelada</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label className="text-blue-200">Número de Referência</Label>
                  <Input
                    name="reference_number"
                    defaultValue={editingTransfer?.reference_number}
                    placeholder="Ex: TRF123456"
                    className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                  />
                </div>

                <div>
                  <Label className="text-blue-200">Observações</Label>
                  <Textarea
                    name="notes"
                    defaultValue={editingTransfer?.notes}
                    placeholder="Informações adicionais..."
                    rows={3}
                    className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-4 border-t border-blue-700">
                  <Button type="button" variant="outline" onClick={() => setShowDialog(false)} className="border-blue-700 text-blue-200 hover:bg-blue-800">
                    Cancelar
                  </Button>
                  <Button type="submit" className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600">
                    {editingTransfer ? "Atualizar" : "Criar Transferência"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-blue-500/50 bg-gradient-to-br from-blue-800/80 to-blue-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <ArrowRightLeft className="w-8 h-8 text-blue-300 mx-auto mb-2" />
              <p className="text-sm text-blue-200">Total Transferências</p>
              <p className="text-3xl font-bold text-white mt-1">{transfers.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-green-500/50 bg-gradient-to-br from-green-800/80 to-green-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <CheckCircle className="w-8 h-8 text-green-300 mx-auto mb-2" />
              <p className="text-sm text-green-200">Valor Transferido</p>
              <p className="text-2xl font-bold text-white mt-1">
                R$ {totalTransferred.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-yellow-500/50 bg-gradient-to-br from-yellow-800/80 to-yellow-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <Clock className="w-8 h-8 text-yellow-300 mx-auto mb-2" />
              <p className="text-sm text-yellow-200">Pendentes</p>
              <p className="text-3xl font-bold text-white mt-1">
                {transfers.filter(t => t.status === "pendente").length}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-red-500/50 bg-gradient-to-br from-red-800/80 to-red-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <XCircle className="w-8 h-8 text-red-300 mx-auto mb-2" />
              <p className="text-sm text-red-200">Taxas Totais</p>
              <p className="text-2xl font-bold text-white mt-1">
                R$ {totalFees.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sugestões de IA */}
      {aiSuggestion && (
        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-purple-100">
              <Sparkles className="w-5 h-5 text-purple-400" />
              Sugestões Inteligentes de IA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose prose-invert prose-sm max-w-none text-purple-100 whitespace-pre-wrap leading-relaxed">
              {aiSuggestion}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Lista de Transferências */}
      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <CardTitle className="text-white">Histórico de Transferências</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-400 w-4 h-4" />
              <Input
                placeholder="Buscar transferências..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-40 bg-blue-950/50 border-blue-700 text-white">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent className="bg-blue-900 border-blue-700">
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="pendente">Pendente</SelectItem>
                <SelectItem value="concluida">Concluída</SelectItem>
                <SelectItem value="cancelada">Cancelada</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-blue-950/50 border-blue-700">
                  <TableHead className="text-blue-300">Data</TableHead>
                  <TableHead className="text-blue-300">Descrição</TableHead>
                  <TableHead className="text-blue-300">De</TableHead>
                  <TableHead className="text-blue-300">Para</TableHead>
                  <TableHead className="text-blue-300">Valor</TableHead>
                  <TableHead className="text-blue-300">Taxa</TableHead>
                  <TableHead className="text-blue-300">Status</TableHead>
                  <TableHead className="text-right text-blue-300">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  [...Array(5)].map((_, i) => (
                    <TableRow key={i} className="border-blue-700">
                      <TableCell><Skeleton className="h-4 w-20 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-32 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-20 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-16 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-6 w-20 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-8 w-20 bg-blue-700/50" /></TableCell>
                    </TableRow>
                  ))
                ) : filteredTransfers.length === 0 ? (
                  <TableRow className="border-blue-700">
                    <TableCell colSpan={8} className="text-center py-8 text-blue-300">
                      Nenhuma transferência encontrada
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredTransfers.map((transfer) => (
                    <TableRow key={transfer.id} className="border-blue-700 hover:bg-blue-800/30">
                      <TableCell className="font-medium text-white">
                        {format(new Date(transfer.transfer_date), "dd/MM/yyyy", { locale: ptBR })}
                      </TableCell>
                      <TableCell className="text-blue-100">{transfer.description}</TableCell>
                      <TableCell className="text-sm text-blue-200">{transfer.from_account}</TableCell>
                      <TableCell className="text-sm text-blue-200">{transfer.to_account}</TableCell>
                      <TableCell className="font-semibold text-white">
                        R$ {transfer.amount?.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell className="text-sm text-red-300">
                        R$ {(transfer.fee || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={
                            transfer.status === "concluida" 
                              ? "bg-green-100 text-green-800 border-green-300" 
                              : transfer.status === "pendente"
                              ? "bg-yellow-100 text-yellow-800 border-yellow-300"
                              : "bg-gray-100 text-gray-800 border-gray-300"
                          }
                        >
                          {transfer.status === "concluida" ? "Concluída" : transfer.status === "pendente" ? "Pendente" : "Cancelada"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              setEditingTransfer(transfer);
                              setShowDialog(true);
                            }}
                            className="text-blue-300 hover:text-white hover:bg-blue-700"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              if (confirm("Tem certeza que deseja excluir esta transferência?")) {
                                deleteMutation.mutate(transfer.id);
                              }
                            }}
                            className="text-red-400 hover:text-white hover:bg-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Assistente IA */}
      <AIAssistant 
        context={`Total Transferências: ${transfers.length}, Valor Transferido: ${totalTransferred}`}
        pageInfo="Transferências - Gestão de movimentações entre contas"
      />
    </div>
  );
}