import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Download, Send, TrendingUp, TrendingDown, DollarSign, Calendar, Filter, PieChart, BarChart3 } from "lucide-react";
import { format, startOfMonth, endOfMonth, startOfYear, endOfYear, subDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";
import { PieChart as RechartsPie, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";

export default function FinancialReports() {
  const [reportType, setReportType] = useState("summary");
  const [startDate, setStartDate] = useState(format(startOfMonth(new Date()), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(endOfMonth(new Date()), "yyyy-MM-dd"));
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedCostCenter, setSelectedCostCenter] = useState("all");
  const [selectedBankAccount, setSelectedBankAccount] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [selectedClient, setSelectedClient] = useState("all");
  const [selectedSupplier, setSelectedSupplier] = useState("all");
  const [generating, setGenerating] = useState(false);

  const { data: transactions = [] } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list(),
    initialData: [],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list(),
    initialData: [],
  });

  const { data: costCenters = [] } = useQuery({
    queryKey: ["costCenters"],
    queryFn: () => base44.entities.CostCenter.list(),
    initialData: [],
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ["bankAccounts"],
    queryFn: () => base44.entities.BankAccount.list(),
    initialData: [],
  });

  const { data: settings } = useQuery({
    queryKey: ["companySettings"],
    queryFn: async () => {
      const list = await base44.entities.CompanySettings.list();
      return list[0] || null;
    },
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts"],
    queryFn: () => base44.entities.Client.list(),
    initialData: [],
  });

  // Filtrar transações
  const filteredTransactions = transactions.filter(t => {
    const transDate = new Date(t.due_date);
    const matchesDate = transDate >= new Date(startDate) && transDate <= new Date(endDate);
    const matchesCategory = selectedCategory === "all" || t.category === selectedCategory;
    const matchesCostCenter = selectedCostCenter === "all" || t.cost_center === selectedCostCenter;
    const matchesAccount = selectedBankAccount === "all" || t.bank_account === selectedBankAccount;
    const matchesStatus = selectedStatus === "all" || t.status === selectedStatus;
    const matchesClient = selectedClient === "all" || t.client_name === selectedClient;
    const matchesSupplier = selectedSupplier === "all" || t.supplier_name === selectedSupplier;
    return matchesDate && matchesCategory && matchesCostCenter && matchesAccount && matchesStatus && matchesClient && matchesSupplier;
  });

  // Calcular totais
  const totalReceitas = filteredTransactions
    .filter(t => t.type === "receita" && (t.status === "pago" || t.status === "recebido"))
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const totalDespesas = filteredTransactions
    .filter(t => t.type === "despesa" && t.status === "pago")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const totalPendentePagar = filteredTransactions
    .filter(t => t.type === "despesa" && t.status === "pendente")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const totalPendenteReceber = filteredTransactions
    .filter(t => t.type === "receita" && t.status === "pendente")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  // Dados para gráfico de pizza - Despesas por categoria
  const despesasPorCategoria = filteredTransactions
    .filter(t => t.type === "despesa" && t.status === "pago" && t.category)
    .reduce((acc, t) => {
      const cat = t.category || "Sem Categoria";
      acc[cat] = (acc[cat] || 0) + t.amount;
      return acc;
    }, {});

  const pieData = Object.entries(despesasPorCategoria).map(([name, value]) => ({
    name,
    value: parseFloat(value.toFixed(2))
  }));

  // Dados para gráfico de barras - Receitas vs Despesas por centro de custo
  const dadosPorCentroCusto = filteredTransactions
    .filter(t => t.cost_center && (t.status === "pago" || t.status === "recebido"))
    .reduce((acc, t) => {
      const cc = t.cost_center || "Sem Centro";
      if (!acc[cc]) acc[cc] = { name: cc, receitas: 0, despesas: 0 };
      if (t.type === "receita") acc[cc].receitas += t.amount;
      else acc[cc].despesas += t.amount;
      return acc;
    }, {});

  const barData = Object.values(dadosPorCentroCusto);

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658', '#FF6B9D'];

  // Exportar CSV
  const exportCSV = () => {
    const headers = ["Data", "Descrição", "Tipo", "Categoria", "Centro Custo", "Valor", "Status"];
    const rows = filteredTransactions.map(t => [
      format(new Date(t.due_date), "dd/MM/yyyy"),
      t.description,
      t.type === "receita" ? "Receita" : "Despesa",
      t.category || "-",
      t.cost_center || "-",
      `R$ ${t.amount.toFixed(2)}`,
      t.status
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(","))
    ].join("\n");

    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `relatorio_${reportType}_${format(new Date(), "dd-MM-yyyy")}.csv`;
    link.click();
    toast.success("✅ CSV exportado com sucesso!");
  };

  // Exportar PDF
  const exportPDF = () => {
    const reportTitle = reportType === "summary" ? "Resumo Financeiro" :
                       reportType === "payables" ? "Contas a Pagar" : "Contas a Receber";

    const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${reportTitle}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; padding: 40px; background: white; color: #333; }
    .header { text-align: center; margin-bottom: 30px; border-bottom: 3px solid #1e3a8a; padding-bottom: 20px; }
    .header h1 { font-size: 28px; color: #1e3a8a; margin-bottom: 10px; }
    .header p { font-size: 14px; color: #666; }
    .summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin: 30px 0; }
    .summary-card { background: #f3f4f6; padding: 20px; border-radius: 8px; text-align: center; }
    .summary-card .label { font-size: 12px; color: #666; text-transform: uppercase; margin-bottom: 8px; }
    .summary-card .value { font-size: 24px; font-weight: bold; }
    .summary-card.receitas .value { color: #10b981; }
    .summary-card.despesas .value { color: #ef4444; }
    .summary-card.saldo .value { color: #1e3a8a; }
    table { width: 100%; border-collapse: collapse; margin-top: 30px; }
    table th { background: #1e3a8a; color: white; padding: 12px; text-align: left; font-size: 12px; }
    table td { padding: 10px; border-bottom: 1px solid #e5e7eb; font-size: 12px; }
    table tr:nth-child(even) { background: #f9fafb; }
    .footer { margin-top: 40px; text-align: center; font-size: 11px; color: #999; border-top: 1px solid #e5e7eb; padding-top: 20px; }
  </style>
</head>
<body>
  <div class="header">
    <h1>${settings?.company_name || "AUTOCRED PROMOTORA"}</h1>
    <p>${reportTitle}</p>
    <p>Período: ${format(new Date(startDate), "dd/MM/yyyy")} até ${format(new Date(endDate), "dd/MM/yyyy")}</p>
  </div>

  <div class="summary">
    <div class="summary-card receitas">
      <div class="label">Receitas</div>
      <div class="value">R$ ${totalReceitas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="summary-card despesas">
      <div class="label">Despesas</div>
      <div class="value">R$ ${totalDespesas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="summary-card saldo">
      <div class="label">Saldo</div>
      <div class="value">R$ ${(totalReceitas - totalDespesas).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="summary-card">
      <div class="label">Pendente</div>
      <div class="value" style="color: #f59e0b;">R$ ${(totalPendentePagar + totalPendenteReceber).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th>Data</th>
        <th>Descrição</th>
        <th>Tipo</th>
        <th>Categoria</th>
        <th>Valor</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      ${filteredTransactions.map(t => `
        <tr>
          <td>${format(new Date(t.due_date), "dd/MM/yyyy")}</td>
          <td>${t.description}</td>
          <td>${t.type === "receita" ? "Receita" : "Despesa"}</td>
          <td>${t.category || "-"}</td>
          <td style="color: ${t.type === "receita" ? "#10b981" : "#ef4444"};">
            R$ ${t.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
          </td>
          <td>${t.status}</td>
        </tr>
      `).join("")}
    </tbody>
  </table>

  <div class="footer">
    <p>Relatório gerado em ${format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</p>
    <p>${settings?.company_name || "AUTOCRED PROMOTORA"} - Sistema de Gestão Financeira</p>
  </div>
  <script>window.onload = function() { window.print(); };</script>
</body>
</html>`;

    const printWindow = window.open("", "_blank");
    printWindow.document.write(htmlContent);
    printWindow.document.close();
    toast.success("✅ PDF gerado! Aguarde a janela de impressão...");
  };

  // Enviar via WhatsApp
  const sendWhatsApp = async () => {
    if (!settings?.whatsapp_number) {
      toast.error("Configure o número WhatsApp em Configurações");
      return;
    }

    setGenerating(true);
    try {
      const summary = {
        receitas: totalReceitas,
        despesas: totalDespesas,
        saldo: totalReceitas - totalDespesas,
        pendentes: totalPendentePagar + totalPendenteReceber
      };

      const { sendWhatsAppReport } = await import("../components/whatsapp/WhatsAppSender");
      await sendWhatsAppReport(settings.whatsapp_number, "Relatório Financeiro", summary);
    } catch (error) {
      console.error("Erro ao enviar:", error);
      toast.error("❌ Erro ao enviar relatório");
    }
    setGenerating(false);
  };

  // Atalhos de período
  const setPeriod = (period) => {
    const today = new Date();
    switch (period) {
      case "today":
        setStartDate(format(today, "yyyy-MM-dd"));
        setEndDate(format(today, "yyyy-MM-dd"));
        break;
      case "week":
        setStartDate(format(subDays(today, 7), "yyyy-MM-dd"));
        setEndDate(format(today, "yyyy-MM-dd"));
        break;
      case "month":
        setStartDate(format(startOfMonth(today), "yyyy-MM-dd"));
        setEndDate(format(endOfMonth(today), "yyyy-MM-dd"));
        break;
      case "year":
        setStartDate(format(startOfYear(today), "yyyy-MM-dd"));
        setEndDate(format(endOfYear(today), "yyyy-MM-dd"));
        break;
    }
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-4xl font-bold text-white">Relatórios Financeiros</h1>
          <p className="text-blue-200 mt-1">Análises completas com exportação e envio automático</p>
        </div>
      </div>

      <Tabs value={reportType} onValueChange={setReportType}>
        <TabsList className="grid w-full grid-cols-3 h-auto bg-blue-950/50">
          <TabsTrigger value="summary" className="text-blue-200 data-[state=active]:bg-blue-700">
            <FileText className="w-4 h-4 mr-2" />
            Resumo Financeiro
          </TabsTrigger>
          <TabsTrigger value="payables" className="text-blue-200 data-[state=active]:bg-blue-700">
            <TrendingDown className="w-4 h-4 mr-2" />
            Contas a Pagar
          </TabsTrigger>
          <TabsTrigger value="receivables" className="text-blue-200 data-[state=active]:bg-blue-700">
            <TrendingUp className="w-4 h-4 mr-2" />
            Contas a Receber
          </TabsTrigger>
        </TabsList>

        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 mt-6">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filtros e Configurações
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Período */}
            <div className="space-y-3">
              <Label className="text-blue-200 font-medium">Período do Relatório</Label>
              <div className="flex gap-2 mb-3">
                <Button size="sm" variant="outline" onClick={() => setPeriod("today")} className="border-blue-700 text-blue-200">Hoje</Button>
                <Button size="sm" variant="outline" onClick={() => setPeriod("week")} className="border-blue-700 text-blue-200">Última Semana</Button>
                <Button size="sm" variant="outline" onClick={() => setPeriod("month")} className="border-blue-700 text-blue-200">Este Mês</Button>
                <Button size="sm" variant="outline" onClick={() => setPeriod("year")} className="border-blue-700 text-blue-200">Este Ano</Button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200 text-sm">Data Inicial</Label>
                  <Input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
                <div>
                  <Label className="text-blue-200 text-sm">Data Final</Label>
                  <Input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
              </div>
            </div>

            {/* Filtros Avançados */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label className="text-blue-200">Status</Label>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    <SelectItem value="all">Todos os Status</SelectItem>
                    <SelectItem value="pago">Pago/Recebido</SelectItem>
                    <SelectItem value="pendente">Pendente</SelectItem>
                    <SelectItem value="vencido">Vencido</SelectItem>
                    <SelectItem value="cancelado">Cancelado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-blue-200">Cliente</Label>
                <Select value={selectedClient} onValueChange={setSelectedClient}>
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    <SelectItem value="all">Todos os Clientes</SelectItem>
                    {contacts.filter(c => c.type === "cliente" || c.type === "ambos").map(client => (
                      <SelectItem key={client.id} value={client.name}>{client.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-blue-200">Fornecedor</Label>
                <Select value={selectedSupplier} onValueChange={setSelectedSupplier}>
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    <SelectItem value="all">Todos os Fornecedores</SelectItem>
                    {contacts.filter(c => c.type === "fornecedor" || c.type === "ambos").map(supplier => (
                      <SelectItem key={supplier.id} value={supplier.name}>{supplier.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-blue-200">Categoria</Label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    <SelectItem value="all">Todas as Categorias</SelectItem>
                    {categories.map(cat => (
                      <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-blue-200">Centro de Custo</Label>
                <Select value={selectedCostCenter} onValueChange={setSelectedCostCenter}>
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    <SelectItem value="all">Todos os Centros</SelectItem>
                    {costCenters.map(cc => (
                      <SelectItem key={cc.id} value={cc.name}>{cc.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-blue-200">Conta Bancária</Label>
                <Select value={selectedBankAccount} onValueChange={setSelectedBankAccount}>
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    <SelectItem value="all">Todas as Contas</SelectItem>
                    {bankAccounts.map(ba => (
                      <SelectItem key={ba.id} value={ba.name}>{ba.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Ações */}
            <div className="flex flex-wrap gap-3 pt-4 border-t border-blue-700">
              <Button onClick={exportCSV} className="bg-gradient-to-r from-green-600 to-green-500">
                <Download className="w-4 h-4 mr-2" />
                Exportar CSV
              </Button>
              <Button onClick={exportPDF} className="bg-gradient-to-r from-red-600 to-red-500">
                <FileText className="w-4 h-4 mr-2" />
                Exportar PDF
              </Button>
              <Button onClick={sendWhatsApp} disabled={generating} className="bg-gradient-to-r from-green-600 to-green-500">
                <Send className="w-4 h-4 mr-2" />
                {generating ? "Enviando..." : "Enviar WhatsApp"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Resumo de Valores */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-green-500/50 bg-gradient-to-br from-green-800/80 to-green-700/80">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-200">Receitas</p>
                  <p className="text-2xl font-bold text-white mt-1">
                    R$ {totalReceitas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <TrendingUp className="w-10 h-10 text-green-300 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-red-500/50 bg-gradient-to-br from-red-800/80 to-red-700/80">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-red-200">Despesas</p>
                  <p className="text-2xl font-bold text-white mt-1">
                    R$ {totalDespesas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <TrendingDown className="w-10 h-10 text-red-300 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-blue-500/50 bg-gradient-to-br from-blue-800/80 to-blue-700/80">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-200">Saldo</p>
                  <p className={`text-2xl font-bold mt-1 ${totalReceitas - totalDespesas >= 0 ? "text-white" : "text-red-300"}`}>
                    R$ {(totalReceitas - totalDespesas).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <DollarSign className="w-10 h-10 text-blue-300 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-yellow-500/50 bg-gradient-to-br from-yellow-800/80 to-yellow-700/80">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-yellow-200">Pendentes</p>
                  <p className="text-2xl font-bold text-white mt-1">
                    R$ {(totalPendentePagar + totalPendenteReceber).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <Calendar className="w-10 h-10 text-yellow-300 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Gráficos */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Gráfico de Pizza */}
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <PieChart className="w-5 h-5" />
                Despesas por Categoria
              </CardTitle>
            </CardHeader>
            <CardContent>
              {pieData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPie>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `R$ ${value.toFixed(2)}`} />
                  </RechartsPie>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-blue-300">
                  Sem dados para exibir
                </div>
              )}
            </CardContent>
          </Card>

          {/* Gráfico de Barras */}
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Receitas vs Despesas por Centro de Custo
              </CardTitle>
            </CardHeader>
            <CardContent>
              {barData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={barData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="name" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" />
                    <Tooltip 
                      contentStyle={{ background: '#1e293b', border: '1px solid #334155' }}
                      formatter={(value) => `R$ ${value.toFixed(2)}`}
                    />
                    <Legend />
                    <Bar dataKey="receitas" fill="#10b981" name="Receitas" />
                    <Bar dataKey="despesas" fill="#ef4444" name="Despesas" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-blue-300">
                  Sem dados para exibir
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Tabela de Transações */}
        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
          <CardHeader>
            <CardTitle className="text-white">Detalhamento de Transações ({filteredTransactions.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-[400px] overflow-auto">
              <table className="w-full">
                <thead className="sticky top-0 bg-blue-950">
                  <tr className="border-b border-blue-700">
                    <th className="text-left text-blue-300 p-3">Data</th>
                    <th className="text-left text-blue-300 p-3">Descrição</th>
                    <th className="text-left text-blue-300 p-3">Tipo</th>
                    <th className="text-left text-blue-300 p-3">Categoria</th>
                    <th className="text-right text-blue-300 p-3">Valor</th>
                    <th className="text-left text-blue-300 p-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTransactions.map((t, idx) => (
                    <tr key={idx} className="border-b border-blue-700/50 hover:bg-blue-800/30">
                      <td className="text-white p-3">{format(new Date(t.due_date), "dd/MM/yyyy")}</td>
                      <td className="text-blue-100 p-3">{t.description}</td>
                      <td className="p-3">
                        <span className={`px-2 py-1 rounded text-xs ${t.type === "receita" ? "bg-green-500/20 text-green-300" : "bg-red-500/20 text-red-300"}`}>
                          {t.type === "receita" ? "Receita" : "Despesa"}
                        </span>
                      </td>
                      <td className="text-blue-200 p-3">{t.category || "-"}</td>
                      <td className={`text-right font-semibold p-3 ${t.type === "receita" ? "text-green-300" : "text-red-300"}`}>
                        R$ {t.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </td>
                      <td className="text-blue-200 p-3">{t.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </Tabs>
    </div>
  );
}