import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Landmark, Pencil, Search } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

export default function BankAccounts() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingAccount, setEditingAccount] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const queryClient = useQueryClient();

  const { data: accounts = [], isLoading } = useQuery({
    queryKey: ["bankAccounts"],
    queryFn: () => base44.entities.BankAccount.list("-created_date"),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.BankAccount.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bankAccounts"] });
      setShowDialog(false);
      setEditingAccount(null);
      toast.success("Conta bancária cadastrada com sucesso!");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.BankAccount.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bankAccounts"] });
      setShowDialog(false);
      setEditingAccount(null);
      toast.success("Conta bancária atualizada com sucesso!");
    },
  });

  const filteredAccounts = accounts.filter((a) =>
    a.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.bank?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.account_number?.includes(searchTerm)
  );

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    const data = {
      name: formData.get("name"),
      bank: formData.get("bank"),
      agency: formData.get("agency"),
      account_number: formData.get("account_number"),
      account_type: formData.get("account_type"),
      initial_balance: parseFloat(formData.get("initial_balance") || 0),
      status: formData.get("status"),
    };

    if (editingAccount) {
      updateMutation.mutate({ id: editingAccount.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white drop-shadow-lg">Contas Bancárias</h1>
          <p className="text-blue-200 mt-1">Gerencie suas contas e saldos</p>
        </div>
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingAccount(null)} className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600 shadow-lg">
              <Plus className="w-4 h-4 mr-2" />
              Nova Conta
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl bg-blue-900 border-blue-700 text-white">
            <DialogHeader>
              <DialogTitle className="text-white">{editingAccount ? "Editar Conta Bancária" : "Nova Conta Bancária"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label className="text-blue-200">Nome da Conta*</Label>
                <Input name="name" defaultValue={editingAccount?.name} placeholder="Ex: Conta Principal - Banco do Brasil" required className="bg-blue-950/50 border-blue-700 text-white" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Banco*</Label>
                  <Input name="bank" defaultValue={editingAccount?.bank} placeholder="Nome do banco" required className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
                <div>
                  <Label className="text-blue-200">Tipo de Conta</Label>
                  <Select name="account_type" defaultValue={editingAccount?.account_type || "corrente"}>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      <SelectItem value="corrente">Conta Corrente</SelectItem>
                      <SelectItem value="poupanca">Poupança</SelectItem>
                      <SelectItem value="investimento">Investimento</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Agência</Label>
                  <Input name="agency" defaultValue={editingAccount?.agency} placeholder="0000" className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
                <div>
                  <Label className="text-blue-200">Número da Conta</Label>
                  <Input name="account_number" defaultValue={editingAccount?.account_number} placeholder="00000-0" className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Saldo Inicial (R$)</Label>
                  <Input name="initial_balance" type="number" step="0.01" defaultValue={editingAccount?.initial_balance || 0} placeholder="0,00" className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
                <div>
                  <Label className="text-blue-200">Status</Label>
                  <Select name="status" defaultValue={editingAccount?.status || "ativo"}>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="inativo">Inativo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-blue-700">
                <Button type="button" variant="outline" onClick={() => setShowDialog(false)} className="border-blue-700 text-blue-200 hover:bg-blue-800">
                  Cancelar
                </Button>
                <Button type="submit" className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600">
                  {editingAccount ? "Atualizar" : "Cadastrar"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-400 w-5 h-5" />
            <Input
              placeholder="Buscar contas bancárias..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
            />
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="bg-blue-950/50 border-blue-700 hover:bg-blue-950/70">
                <TableHead className="text-blue-300">Nome</TableHead>
                <TableHead className="text-blue-300">Banco</TableHead>
                <TableHead className="text-blue-300">Agência</TableHead>
                <TableHead className="text-blue-300">Conta</TableHead>
                <TableHead className="text-blue-300">Tipo</TableHead>
                <TableHead className="text-blue-300">Saldo Inicial</TableHead>
                <TableHead className="text-blue-300">Status</TableHead>
                <TableHead className="text-right text-blue-300">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                [...Array(5)].map((_, i) => (
                  <TableRow key={i} className="border-blue-700">
                    <TableCell><Skeleton className="h-4 w-40 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-32 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-16 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-20 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-16 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-8 w-20 bg-blue-700/50" /></TableCell>
                  </TableRow>
                ))
              ) : filteredAccounts.length === 0 ? (
                <TableRow className="border-blue-700">
                  <TableCell colSpan={8} className="text-center py-8 text-blue-300">
                    Nenhuma conta bancária encontrada
                  </TableCell>
                </TableRow>
              ) : (
                filteredAccounts.map((account) => (
                  <TableRow key={account.id} className="border-blue-700 hover:bg-blue-800/30">
                    <TableCell className="font-medium text-white">{account.name}</TableCell>
                    <TableCell className="text-blue-200">{account.bank}</TableCell>
                    <TableCell className="text-blue-200">{account.agency || "-"}</TableCell>
                    <TableCell className="text-blue-200">{account.account_number || "-"}</TableCell>
                    <TableCell className="text-blue-200">{account.account_type || "-"}</TableCell>
                    <TableCell className="text-green-300 font-semibold">
                      R$ {(account.initial_balance || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={account.status === "ativo" ? "text-green-300 border-green-500" : "text-gray-400 border-gray-500"}>
                        {account.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setEditingAccount(account);
                          setShowDialog(true);
                        }}
                        className="text-blue-300 hover:text-white hover:bg-blue-700"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}