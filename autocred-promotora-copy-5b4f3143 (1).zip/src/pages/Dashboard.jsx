import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  FileText,
  CreditCard,
  Sparkles,
  RefreshCw,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Landmark,
  Eye,
  EyeOff,
  Lock,
  Bell,
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import AIAssistant from "../components/AIAssistant";
import AIFinancialSuggestions from "../components/dashboard/AIFinancialSuggestions";
import CashFlowPrediction from "../components/dashboard/CashFlowPrediction";
import UpcomingPayments from "../components/dashboard/UpcomingPayments";
import RevenueVsExpensesChart from "../components/dashboard/RevenueVsExpensesChart";
import SmartTransactionSuggestions from "../components/dashboard/SmartTransactionSuggestions";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts";
import { format, subDays, startOfMonth, endOfMonth, startOfWeek, endOfWeek, subMonths, addDays } from "date-fns";
import { ptBR } from "date-fns/locale";

const COLORS = ["#10B981", "#EF4444", "#3B82F6", "#F59E0B", "#8B5CF6", "#EC4899"];

export default function Dashboard() {
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [loadingAI, setLoadingAI] = useState(false);
  const [hideNumbers, setHideNumbers] = useState(() => {
    return localStorage.getItem('hideNumbers') === 'true';
  });
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [passwordInput, setPasswordInput] = useState("");
  
  useEffect(() => {
    const handleStorageChange = () => {
      setHideNumbers(localStorage.getItem('hideNumbers') === 'true');
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const { data: transactions = [], isLoading: loadingTransactions } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list("-due_date"),
    initialData: [],
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ["bankAccounts"],
    queryFn: () => base44.entities.BankAccount.list(),
    initialData: [],
  });

  const { data: clients = [] } = useQuery({
    queryKey: ["clients"],
    queryFn: () => base44.entities.Client.list(),
    initialData: [],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list(),
    initialData: [],
  });

  const { data: costCenters = [] } = useQuery({
    queryKey: ["costCenters"],
    queryFn: () => base44.entities.CostCenter.list(),
    initialData: [],
  });

  const currentMonth = new Date();
  const startMonth = startOfMonth(currentMonth);
  const endMonth = endOfMonth(currentMonth);
  const startThisWeek = startOfWeek(currentMonth, { locale: ptBR });
  const endThisWeek = endOfWeek(currentMonth, { locale: ptBR });

  // Cálculos Mensais
  const monthTransactions = transactions.filter((t) => {
    const tDate = new Date(t.due_date);
    return tDate >= startMonth && tDate <= endMonth;
  });

  const totalReceitasMes = monthTransactions
    .filter((t) => t.type === "receita" && t.status === "pago")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const totalDespesasMes = monthTransactions
    .filter((t) => t.type === "despesa" && t.status === "pago")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const saldoMes = totalReceitasMes - totalDespesasMes;

  // Cálculos Semanais
  const weekTransactions = transactions.filter((t) => {
    const tDate = new Date(t.due_date);
    return tDate >= startThisWeek && tDate <= endThisWeek;
  });

  const totalReceitasSemana = weekTransactions
    .filter((t) => t.type === "receita" && t.status === "pago")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const totalDespesasSemana = weekTransactions
    .filter((t) => t.type === "despesa" && t.status === "pago")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const saldoSemana = totalReceitasSemana - totalDespesasSemana;

  // Cálculos Gerais
  const totalReceitasGeral = transactions
    .filter((t) => t.type === "receita" && t.status === "pago")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const totalDespesasGeral = transactions
    .filter((t) => t.type === "despesa" && t.status === "pago")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const saldoGeral = totalReceitasGeral - totalDespesasGeral;

  const totalPendente = transactions
    .filter((t) => t.status === "pendente")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  // CONTAS A PAGAR/RECEBER POR PERÍODO
  const today = new Date();
  const todayStr = format(today, "yyyy-MM-dd");
  
  // DIA
  const contasDia = transactions.filter(t => t.due_date === todayStr && t.status === "pendente");
  const receitasDia = contasDia.filter(t => t.type === "receita").reduce((s, t) => s + t.amount, 0);
  const despesasDia = contasDia.filter(t => t.type === "despesa").reduce((s, t) => s + t.amount, 0);

  // SEMANA
  const contasSemana = transactions.filter(t => {
    const tDate = new Date(t.due_date);
    return tDate >= startThisWeek && tDate <= endThisWeek && t.status === "pendente";
  });
  const receitasSemana = contasSemana.filter(t => t.type === "receita").reduce((s, t) => s + t.amount, 0);
  const despesasSemana = contasSemana.filter(t => t.type === "despesa").reduce((s, t) => s + t.amount, 0);

  // MÊS
  const contasMes = transactions.filter(t => {
    const tDate = new Date(t.due_date);
    return tDate >= startMonth && tDate <= endMonth && t.status === "pendente";
  });
  const receitasMes = contasMes.filter(t => t.type === "receita").reduce((s, t) => s + t.amount, 0);
  const despesasMes = contasMes.filter(t => t.type === "despesa").reduce((s, t) => s + t.amount, 0);

  // ANO
  const startYear = new Date(currentMonth.getFullYear(), 0, 1);
  const endYear = new Date(currentMonth.getFullYear(), 11, 31);
  const contasAno = transactions.filter(t => {
    const tDate = new Date(t.due_date);
    return tDate >= startYear && tDate <= endYear && t.status === "pendente";
  });
  const receitasAno = contasAno.filter(t => t.type === "receita").reduce((s, t) => s + t.amount, 0);
  const despesasAno = contasAno.filter(t => t.type === "despesa").reduce((s, t) => s + t.amount, 0);

  // ALERTAS - Contas vencendo em 2 dias
  const twoDaysFromNow = addDays(today, 2);
  const alertasVencimento = transactions.filter(t => {
    const tDate = new Date(t.due_date);
    return tDate <= twoDaysFromNow && tDate >= today && t.status === "pendente";
  }).sort((a, b) => new Date(a.due_date) - new Date(b.due_date));

  // Saldo Total das Contas (incluindo saldo inicial)
  const saldoTotalContas = bankAccounts.reduce((sum, acc) => {
    const saldoInicial = acc.initial_balance || 0;
    const movimentacoes = transactions
      .filter(t => t.bank_account === acc.name && t.status === "pago")
      .reduce((total, t) => {
        return total + (t.type === "receita" ? t.amount : -t.amount);
      }, 0);
    return sum + saldoInicial + movimentacoes;
  }, 0);

  // Últimos 7 dias
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), 6 - i);
    const dayTransactions = transactions.filter(
      (t) => t.status === "pago" && format(new Date(t.due_date), "yyyy-MM-dd") === format(date, "yyyy-MM-dd")
    );
    const receitas = dayTransactions
      .filter((t) => t.type === "receita")
      .reduce((sum, t) => sum + (t.amount || 0), 0);
    const despesas = dayTransactions
      .filter((t) => t.type === "despesa")
      .reduce((sum, t) => sum + (t.amount || 0), 0);

    return {
      date: format(date, "dd/MM", { locale: ptBR }),
      receitas,
      despesas,
      saldo: receitas - despesas,
    };
  });

  // Últimos 6 meses
  const last6Months = Array.from({ length: 6 }, (_, i) => {
    const date = subMonths(new Date(), 5 - i);
    const monthStart = startOfMonth(date);
    const monthEnd = endOfMonth(date);
    const monthTrans = transactions.filter((t) => {
      const tDate = new Date(t.due_date);
      return t.status === "pago" && tDate >= monthStart && tDate <= monthEnd;
    });
    const receitas = monthTrans
      .filter((t) => t.type === "receita")
      .reduce((sum, t) => sum + (t.amount || 0), 0);
    const despesas = monthTrans
      .filter((t) => t.type === "despesa")
      .reduce((sum, t) => sum + (t.amount || 0), 0);

    return {
      month: format(date, "MMM/yy", { locale: ptBR }),
      receitas,
      despesas,
      saldo: receitas - despesas,
    };
  });

  // Despesas por categoria
  const categoryData = monthTransactions.reduce((acc, t) => {
    if (t.type === "despesa" && t.status === "pago") {
      const category = t.category || "Outros";
      acc[category] = (acc[category] || 0) + t.amount;
    }
    return acc;
  }, {});

  const categoryChartData = Object.entries(categoryData)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 6);

  // Receitas por categoria
  const revenueByCategory = monthTransactions.reduce((acc, t) => {
    if (t.type === "receita" && t.status === "pago") {
      const category = t.category || "Outros";
      acc[category] = (acc[category] || 0) + t.amount;
    }
    return acc;
  }, {});

  const revenueCategoryData = Object.entries(revenueByCategory)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 6);

  // Comparativo Semanal
  const weeklyComparison = Array.from({ length: 4 }, (_, i) => {
    const weekStart = subDays(startThisWeek, i * 7);
    const weekEnd = subDays(endThisWeek, i * 7);
    const weekTrans = transactions.filter((t) => {
      const tDate = new Date(t.due_date);
      return t.status === "pago" && tDate >= weekStart && tDate <= weekEnd;
    });
    const receitas = weekTrans.filter((t) => t.type === "receita").reduce((sum, t) => sum + t.amount, 0);
    const despesas = weekTrans.filter((t) => t.type === "despesa").reduce((sum, t) => sum + t.amount, 0);

    return {
      week: `Sem ${4 - i}`,
      receitas,
      despesas,
    };
  }).reverse();

  // Centro de Custos
  const costCenterData = monthTransactions.reduce((acc, t) => {
    if (t.type === "despesa" && t.status === "pago" && t.cost_center) {
      acc[t.cost_center] = (acc[t.cost_center] || 0) + t.amount;
    }
    return acc;
  }, {});

  const costCenterChart = Object.entries(costCenterData)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);

  // Saldo por Conta
  const accountBalances = bankAccounts.map(acc => {
    const saldoInicial = acc.initial_balance || 0;
    const movimentacoes = transactions
      .filter(t => t.bank_account === acc.name && t.status === "pago")
      .reduce((total, t) => {
        return total + (t.type === "receita" ? t.amount : -t.amount);
      }, 0);
    return {
      name: acc.name,
      saldo: saldoInicial + movimentacoes,
    };
  });

  useEffect(() => {
    if (!loadingTransactions && transactions.length > 0 && !aiAnalysis) {
      generateAIAnalysis();
    }
  }, [loadingTransactions, transactions]);

  const generateAIAnalysis = async () => {
    setLoadingAI(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analise DETALHADAMENTE os dados financeiros da AUTOCRED PROMOTORA:

DADOS DO MÊS:
- Receitas: R$ ${totalReceitasMes.toFixed(2)}
- Despesas: R$ ${totalDespesasMes.toFixed(2)}
- Saldo: R$ ${saldoMes.toFixed(2)}

DADOS DA SEMANA:
- Receitas: R$ ${totalReceitasSemana.toFixed(2)}
- Despesas: R$ ${totalDespesasSemana.toFixed(2)}
- Saldo: R$ ${saldoSemana.toFixed(2)}

DADOS GERAIS:
- Receitas Totais: R$ ${totalReceitasGeral.toFixed(2)}
- Despesas Totais: R$ ${totalDespesasGeral.toFixed(2)}
- Saldo Geral: R$ ${saldoGeral.toFixed(2)}
- Saldo em Contas: R$ ${saldoTotalContas.toFixed(2)}
- Valores Pendentes: R$ ${totalPendente.toFixed(2)}

ÚLTIMOS 6 MESES: ${JSON.stringify(last6Months)}
ÚLTIMOS 7 DIAS: ${JSON.stringify(last7Days)}

Forneça uma análise COMPLETA com:
1. Avaliação da saúde financeira atual
2. Comparação mês vs semana (tendências)
3. 10 insights específicos e acionáveis
4. 8 sugestões práticas de otimização
5. Alertas sobre riscos identificados
6. Oportunidades de crescimento
7. Análise de liquidez e fluxo de caixa
8. Recomendações estratégicas prioritárias
9. Projeções para próximos 30 dias
10. KPIs a serem monitorados`,
      });

      setAiAnalysis(result);
    } catch (error) {
      console.error("Erro ao gerar análise:", error);
    }
    setLoadingAI(false);
  };



  const StatCard = ({ title, value, icon: Icon, color, bgGradient, subtitle }) => (
    <Card className={`relative overflow-hidden border-${color}-700/50 bg-gradient-to-br from-${color}-900/80 to-${color}-800/80 backdrop-blur-sm hover:shadow-2xl hover:shadow-${color}-500/20 transition-all duration-300`}>
      <div className={`absolute top-0 right-0 w-32 h-32 bg-${color}-500 opacity-20 rounded-full transform translate-x-10 -translate-y-10`} />
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className={`text-sm font-medium text-${color}-200`}>{title}</CardTitle>
          <div className={`p-3 rounded-xl bg-${color}-500 bg-opacity-30 backdrop-blur-sm shadow-lg`}>
            <Icon className={`w-5 h-5 text-${color}-300`} />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold text-white">{hideNumbers ? "•••••" : value}</div>
        {subtitle && <p className={`text-sm text-${color}-300 mt-1`}>{subtitle}</p>}
      </CardContent>
    </Card>
  );

  if (loadingTransactions) {
    return (
      <div className="p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[...Array(8)].map((_, i) => (
            <Card key={i} className="bg-blue-900/50 border-blue-700/50">
              <CardHeader><Skeleton className="h-4 w-24 bg-blue-700/50" /></CardHeader>
              <CardContent><Skeleton className="h-8 w-32 bg-blue-700/50" /></CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 space-y-8">
      <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
        <DialogContent className="bg-blue-900 border-blue-700">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Digite a Senha para Mostrar Valores
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              type="password"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              placeholder="Digite a senha"
              className="bg-blue-950/50 border-blue-700 text-white"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  if (passwordInput === "1020") {
                    setHideNumbers(false);
                    localStorage.setItem('hideNumbers', 'false');
                    window.dispatchEvent(new Event('storage'));
                    setShowPasswordDialog(false);
                    setPasswordInput("");
                    toast.success("✅ Valores desbloqueados!");
                  } else {
                    toast.error("❌ Senha incorreta!");
                    setPasswordInput("");
                  }
                }
              }}
            />
            <Button
              onClick={() => {
                if (passwordInput === "1020") {
                  setHideNumbers(false);
                  localStorage.setItem('hideNumbers', 'false');
                  window.dispatchEvent(new Event('storage'));
                  setShowPasswordDialog(false);
                  setPasswordInput("");
                  toast.success("✅ Valores desbloqueados!");
                } else {
                  toast.error("❌ Senha incorreta!");
                  setPasswordInput("");
                }
              }}
              className="w-full bg-gradient-to-r from-blue-600 to-blue-500"
            >
              Confirmar
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white drop-shadow-lg">Dashboard Financeiro</h1>
          <p className="text-blue-200 mt-2">Visão completa e em tempo real do seu negócio</p>
        </div>
        <div className="flex gap-3">
          <Button 
            onClick={() => {
              if (hideNumbers) {
                setShowPasswordDialog(true);
              } else {
                setHideNumbers(true);
                localStorage.setItem('hideNumbers', 'true');
                window.dispatchEvent(new Event('storage'));
              }
            }}
            className={`${hideNumbers ? 'bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-600' : 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600'} shadow-lg`}
          >
            {hideNumbers ? <><Lock className="w-4 h-4 mr-2" /> Desbloquear Valores</> : <><EyeOff className="w-4 h-4 mr-2" /> Proteger Valores</>}
          </Button>
          <Button 
            onClick={generateAIAnalysis} 
            disabled={loadingAI} 
            className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600 text-white shadow-lg hover:shadow-blue-500/50 transition-all"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${loadingAI ? "animate-spin" : ""}`} />
            Atualizar Análise IA
          </Button>
        </div>
      </div>

      {/* ALERTAS DE VENCIMENTO */}
      {alertasVencimento.length > 0 && (
        <Card className="border-red-500/50 bg-gradient-to-br from-red-900/80 to-red-800/80 backdrop-blur-sm shadow-2xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Bell className="w-5 h-5 text-red-400 animate-pulse" />
              🚨 Alertas de Vencimento - Próximos 2 Dias
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {alertasVencimento.slice(0, 5).map(trans => (
                <Link to={createPageUrl("Transactions")} key={trans.id}>
                  <div className="bg-red-950/50 p-4 rounded-lg border border-red-600 hover:bg-red-950/70 transition-all cursor-pointer">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex-1">
                        <p className="font-semibold text-white">{trans.description}</p>
                        <p className="text-sm text-red-300">
                          {trans.type === "receita" ? "A Receber" : "A Pagar"} • {trans.supplier_name || trans.client_name || "N/A"}
                        </p>
                      </div>
                      <Badge className={trans.type === "receita" ? "bg-green-500" : "bg-red-500"}>
                        R$ {trans.amount.toLocaleString("pt-BR")}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-red-200">
                      <Calendar className="w-3 h-3" />
                      Vence em: {format(new Date(trans.due_date), "dd/MM/yyyy")}
                      {new Date(trans.due_date).toDateString() === today.toDateString() && (
                        <Badge className="bg-yellow-500 text-white ml-2">HOJE</Badge>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
              {alertasVencimento.length > 5 && (
                <Link to={createPageUrl("Transactions")}>
                  <Button className="w-full bg-red-600 hover:bg-red-700">
                    Ver todos ({alertasVencimento.length}) alertas
                  </Button>
                </Link>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* CONTAS A PAGAR/RECEBER - DIA */}
      <div>
        <h2 className="text-2xl font-bold text-white mb-4">📅 Hoje - {format(today, "dd/MM/yyyy")}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Link to={`${createPageUrl("Transactions")}?filter=receita_pendente_hoje`}>
            <Card className="border-green-500/50 bg-gradient-to-br from-green-900/80 to-green-800/80 hover:shadow-2xl hover:scale-105 transition-all cursor-pointer">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-200">A Receber Hoje</p>
                    <p className="text-3xl font-bold text-white">{hideNumbers ? "•••••" : `R$ ${receitasDia.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}</p>
                    <p className="text-xs text-green-300 mt-1">{contasDia.filter(t => t.type === "receita").length} conta(s)</p>
                  </div>
                  <TrendingUp className="w-12 h-12 text-green-300 opacity-50" />
                </div>
              </CardContent>
            </Card>
          </Link>
          <Link to={`${createPageUrl("Transactions")}?filter=despesa_pendente_hoje`}>
            <Card className="border-red-500/50 bg-gradient-to-br from-red-900/80 to-red-800/80 hover:shadow-2xl hover:scale-105 transition-all cursor-pointer">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-red-200">A Pagar Hoje</p>
                    <p className="text-3xl font-bold text-white">{hideNumbers ? "•••••" : `R$ ${despesasDia.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}</p>
                    <p className="text-xs text-red-300 mt-1">{contasDia.filter(t => t.type === "despesa").length} conta(s)</p>
                  </div>
                  <TrendingDown className="w-12 h-12 text-red-300 opacity-50" />
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>

      {/* CONTAS A PAGAR/RECEBER - SEMANA */}
      <div>
        <h2 className="text-2xl font-bold text-white mb-4">📆 Esta Semana</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Link to={`${createPageUrl("Transactions")}?filter=receita_pendente_semana`}>
            <Card className="border-green-500/50 bg-gradient-to-br from-green-900/80 to-green-800/80 hover:shadow-2xl hover:scale-105 transition-all cursor-pointer">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-200">A Receber Semana</p>
                    <p className="text-3xl font-bold text-white">{hideNumbers ? "•••••" : `R$ ${receitasSemana.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}</p>
                    <p className="text-xs text-green-300 mt-1">{contasSemana.filter(t => t.type === "receita").length} conta(s)</p>
                  </div>
                  <TrendingUp className="w-12 h-12 text-green-300 opacity-50" />
                </div>
              </CardContent>
            </Card>
          </Link>
          <Link to={`${createPageUrl("Transactions")}?filter=despesa_pendente_semana`}>
            <Card className="border-red-500/50 bg-gradient-to-br from-red-900/80 to-red-800/80 hover:shadow-2xl hover:scale-105 transition-all cursor-pointer">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-red-200">A Pagar Semana</p>
                    <p className="text-3xl font-bold text-white">{hideNumbers ? "•••••" : `R$ ${despesasSemana.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}</p>
                    <p className="text-xs text-red-300 mt-1">{contasSemana.filter(t => t.type === "despesa").length} conta(s)</p>
                  </div>
                  <TrendingDown className="w-12 h-12 text-red-300 opacity-50" />
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>

      {/* CONTAS A PAGAR/RECEBER - MÊS */}
      <div>
        <h2 className="text-2xl font-bold text-white mb-4">📊 Este Mês</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Link to={`${createPageUrl("Transactions")}?filter=receita_pendente_mes`}>
            <Card className="border-green-500/50 bg-gradient-to-br from-green-900/80 to-green-800/80 hover:shadow-2xl hover:scale-105 transition-all cursor-pointer">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-200">A Receber Mês</p>
                    <p className="text-3xl font-bold text-white">{hideNumbers ? "•••••" : `R$ ${receitasMes.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}</p>
                    <p className="text-xs text-green-300 mt-1">{contasMes.filter(t => t.type === "receita").length} conta(s)</p>
                  </div>
                  <TrendingUp className="w-12 h-12 text-green-300 opacity-50" />
                </div>
              </CardContent>
            </Card>
          </Link>
          <Link to={`${createPageUrl("Transactions")}?filter=despesa_pendente_mes`}>
            <Card className="border-red-500/50 bg-gradient-to-br from-red-900/80 to-red-800/80 hover:shadow-2xl hover:scale-105 transition-all cursor-pointer">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-red-200">A Pagar Mês</p>
                    <p className="text-3xl font-bold text-white">{hideNumbers ? "•••••" : `R$ ${despesasMes.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}</p>
                    <p className="text-xs text-red-300 mt-1">{contasMes.filter(t => t.type === "despesa").length} conta(s)</p>
                  </div>
                  <TrendingDown className="w-12 h-12 text-red-300 opacity-50" />
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>

      {/* CONTAS A PAGAR/RECEBER - ANO */}
      <div>
        <h2 className="text-2xl font-bold text-white mb-4">📈 Este Ano</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Link to={`${createPageUrl("Transactions")}?filter=receita_pendente_ano`}>
            <Card className="border-green-500/50 bg-gradient-to-br from-green-900/80 to-green-800/80 hover:shadow-2xl hover:scale-105 transition-all cursor-pointer">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-200">A Receber Ano</p>
                    <p className="text-3xl font-bold text-white">{hideNumbers ? "•••••" : `R$ ${receitasAno.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}</p>
                    <p className="text-xs text-green-300 mt-1">{contasAno.filter(t => t.type === "receita").length} conta(s)</p>
                  </div>
                  <TrendingUp className="w-12 h-12 text-green-300 opacity-50" />
                </div>
              </CardContent>
            </Card>
          </Link>
          <Link to={`${createPageUrl("Transactions")}?filter=despesa_pendente_ano`}>
            <Card className="border-red-500/50 bg-gradient-to-br from-red-900/80 to-red-800/80 hover:shadow-2xl hover:scale-105 transition-all cursor-pointer">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-red-200">A Pagar Ano</p>
                    <p className="text-3xl font-bold text-white">{hideNumbers ? "•••••" : `R$ ${despesasAno.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}</p>
                    <p className="text-xs text-red-300 mt-1">{contasAno.filter(t => t.type === "despesa").length} conta(s)</p>
                  </div>
                  <TrendingDown className="w-12 h-12 text-red-300 opacity-50" />
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>

      {/* Cards Principais */}
      <div>
        <h2 className="text-2xl font-bold text-white mb-4">💰 Resumo Financeiro</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Receitas do Mês"
            value={`R$ ${totalReceitasMes.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
            icon={TrendingUp}
            color="green"
            bgGradient="bg-green-500"
          />
          <StatCard
            title="Despesas do Mês"
            value={`R$ ${totalDespesasMes.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
            icon={TrendingDown}
            color="red"
            bgGradient="bg-red-500"
          />
          <StatCard
            title="Saldo do Mês"
            value={`R$ ${saldoMes.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
            icon={DollarSign}
            color="blue"
            bgGradient="bg-blue-500"
          />
          <StatCard
            title="Saldo em Contas"
            value={`R$ ${saldoTotalContas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
            icon={Landmark}
            color="purple"
            bgGradient="bg-purple-500"
            subtitle="(incluindo saldo inicial)"
          />
        </div>
      </div>

      {/* Cards Semanais */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard
          title="Receitas da Semana"
          value={`R$ ${totalReceitasSemana.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
          icon={TrendingUp}
          color="green"
          bgGradient="bg-green-500"
        />
        <StatCard
          title="Despesas da Semana"
          value={`R$ ${totalDespesasSemana.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
          icon={TrendingDown}
          color="red"
          bgGradient="bg-red-500"
        />
        <StatCard
          title="Saldo da Semana"
          value={`R$ ${saldoSemana.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
          icon={DollarSign}
          color="blue"
          bgGradient="bg-blue-500"
        />
      </div>

      {/* Cards Gerais */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard
          title="Receitas Totais"
          value={`R$ ${totalReceitasGeral.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
          icon={TrendingUp}
          color="green"
          bgGradient="bg-green-500"
        />
        <StatCard
          title="Despesas Totais"
          value={`R$ ${totalDespesasGeral.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
          icon={TrendingDown}
          color="red"
          bgGradient="bg-red-500"
        />
        <StatCard
          title="Saldo Geral"
          value={`R$ ${saldoGeral.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
          icon={DollarSign}
          color="blue"
          bgGradient="bg-blue-500"
        />
        <StatCard
          title="Valores Pendentes"
          value={`R$ ${totalPendente.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
          icon={Calendar}
          color="yellow"
          bgGradient="bg-yellow-500"
        />
      </div>

      {/* Sugestões Inteligentes da IA */}
      <AIFinancialSuggestions transactions={transactions} bankAccounts={bankAccounts} />

      {/* Sugestões de Categorização Automática */}
      <SmartTransactionSuggestions 
        transactions={transactions} 
        categories={categories} 
        costCenters={costCenters} 
      />

      {/* Previsão de Fluxo de Caixa */}
      <CashFlowPrediction transactions={transactions} />

      {/* Próximos Vencimentos */}
      <UpcomingPayments transactions={transactions} />

      {/* Gráfico de Evolução Receitas vs Despesas */}
      <RevenueVsExpensesChart transactions={transactions} />

      {/* Análise de IA */}
      {aiAnalysis && (
        <Card className="border-2 border-blue-400/50 bg-gradient-to-br from-blue-900/90 to-blue-800/90 backdrop-blur-sm shadow-2xl shadow-blue-500/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-blue-100 text-xl">
              <Sparkles className="w-6 h-6 text-blue-400" />
              Análise Inteligente com IA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose prose-invert prose-blue max-w-none text-sm whitespace-pre-wrap text-blue-100 leading-relaxed">
              {aiAnalysis}
            </div>
          </CardContent>
        </Card>
      )}

      {loadingAI && (
        <Card className="border-blue-400/50 bg-blue-900/50 backdrop-blur-sm">
          <CardContent className="py-8">
            <div className="flex items-center justify-center gap-3">
              <RefreshCw className="w-5 h-5 animate-spin text-blue-400" />
              <span className="text-blue-200">Gerando análise inteligente...</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Gráficos Principais */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-white">Evolução - Últimos 7 Dias</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={last7Days}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
                <XAxis dataKey="date" stroke="#93c5fd" fontSize={12} />
                <YAxis stroke="#93c5fd" fontSize={12} />
                <Tooltip contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px", color: "#fff" }} />
                <Legend />
                <Area type="monotone" dataKey="receitas" stackId="1" stroke="#10B981" fill="#10B981" fillOpacity={0.6} name="Receitas" />
                <Area type="monotone" dataKey="despesas" stackId="2" stroke="#EF4444" fill="#EF4444" fillOpacity={0.6} name="Despesas" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-white">Últimos 6 Meses - Comparativo</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={last6Months}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
                <XAxis dataKey="month" stroke="#93c5fd" fontSize={12} />
                <YAxis stroke="#93c5fd" fontSize={12} />
                <Tooltip contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px", color: "#fff" }} />
                <Legend />
                <Bar dataKey="receitas" fill="#10B981" name="Receitas" radius={[8, 8, 0, 0]} />
                <Bar dataKey="despesas" fill="#EF4444" name="Despesas" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Mais Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-white">Despesas por Categoria</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={categoryChartData} cx="50%" cy="50%" labelLine={false} label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`} outerRadius={100} fill="#8884d8" dataKey="value">
                  {categoryChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px", color: "#fff" }} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-white">Receitas por Categoria</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={revenueCategoryData} cx="50%" cy="50%" labelLine={false} label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`} outerRadius={100} fill="#8884d8" dataKey="value">
                  {revenueCategoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px", color: "#fff" }} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Comparativo Semanal e Centro de Custos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-white">Receita x Despesa - Últimas 4 Semanas</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={weeklyComparison}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
                <XAxis dataKey="week" stroke="#93c5fd" fontSize={12} />
                <YAxis stroke="#93c5fd" fontSize={12} />
                <Tooltip contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px", color: "#fff" }} />
                <Legend />
                <Line type="monotone" dataKey="receitas" stroke="#10B981" strokeWidth={3} name="Receitas" />
                <Line type="monotone" dataKey="despesas" stroke="#EF4444" strokeWidth={3} name="Despesas" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-white">Despesas por Centro de Custo</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={costCenterChart}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
                <XAxis dataKey="name" stroke="#93c5fd" fontSize={10} angle={-45} textAnchor="end" height={80} />
                <YAxis stroke="#93c5fd" fontSize={12} />
                <Tooltip contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px", color: "#fff" }} />
                <Bar dataKey="value" fill="#F59E0B" radius={[8, 8, 0, 0]} name="Despesas" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Saldo por Conta */}
      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <CardTitle className="text-white">Saldo em Tempo Real por Conta</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {accountBalances.map((acc, i) => (
              <Card key={i} className="border-blue-600/50 bg-blue-950/50">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <Landmark className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                    <p className="text-sm text-blue-300 font-medium">{acc.name}</p>
                    <p className="text-2xl font-bold text-white mt-2">
                      {hideNumbers ? "••••••" : `R$ ${acc.saldo.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Links Rápidos */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to={createPageUrl("Transactions")}>
          <Card className="hover:shadow-2xl hover:shadow-blue-500/30 transition-all cursor-pointer border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm h-full">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-300 font-medium">Lançamentos</p>
                  <p className="text-3xl font-bold text-white mt-2">{transactions.length}</p>
                </div>
                <CreditCard className="w-12 h-12 text-blue-400" />
              </div>
            </CardContent>
          </Card>
        </Link>

        <Link to={createPageUrl("Contacts")}>
          <Card className="hover:shadow-2xl hover:shadow-green-500/30 transition-all cursor-pointer border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm h-full">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-300 font-medium">Clientes/Fornecedores</p>
                  <p className="text-3xl font-bold text-white mt-2">{clients.length}</p>
                </div>
                <Users className="w-12 h-12 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </Link>

        <Link to={createPageUrl("Reports")}>
          <Card className="hover:shadow-2xl hover:shadow-purple-500/30 transition-all cursor-pointer border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm h-full">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-300 font-medium">Relatórios</p>
                  <p className="text-3xl font-bold text-white mt-2">Gerar</p>
                </div>
                <FileText className="w-12 h-12 text-purple-400" />
              </div>
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Assistente IA */}
      <AIAssistant 
        context={`Receitas Mês: ${totalReceitasMes}, Despesas Mês: ${totalDespesasMes}, Saldo: ${saldoMes}`}
        pageInfo="Dashboard - Visão geral financeira com métricas, gráficos e análises"
      />
    </div>
  );
}