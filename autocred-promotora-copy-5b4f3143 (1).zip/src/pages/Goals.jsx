import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import CurrencyInput from "../components/CurrencyInput";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import {
  Plus,
  Target,
  TrendingUp,
  AlertTriangle,
  Sparkles,
  Edit,
  Trash2,
  Calendar,
  RefreshCw,
  CheckCircle,
  XCircle,
  Send
} from "lucide-react";
import { format, differenceInDays, differenceInBusinessDays, subMonths, addMonths, startOfMonth, endOfMonth } from "date-fns";
import { ptBR } from "date-fns/locale";
import AIAssistant from "../components/AIAssistant";
import { toast } from "sonner";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
  Area
} from "recharts";

export default function Goals() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingGoal, setEditingGoal] = useState(null);
  const [aiAnalysis, setAiAnalysis] = useState({});
  const [loadingAI, setLoadingAI] = useState({});
  const [suggestingGoals, setSuggestingGoals] = useState(false);
  const [suggestedGoals, setSuggestedGoals] = useState([]);
  const [showSuggestionsDialog, setShowSuggestionsDialog] = useState(false);
  const [goalAdjustments, setGoalAdjustments] = useState({});
  const [loadingAdjustments, setLoadingAdjustments] = useState({});
  
  const queryClient = useQueryClient();

  const { data: goals = [], isLoading } = useQuery({
    queryKey: ["goals"],
    queryFn: () => base44.entities.Goal.list("-created_date"),
    initialData: [],
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list(),
    initialData: [],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list(),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Goal.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["goals"] });
      setShowDialog(false);
      setEditingGoal(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Goal.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["goals"] });
      setShowDialog(false);
      setEditingGoal(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Goal.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["goals"] });
    },
  });

  // Calcular progresso em tempo real
  const calculateProgress = (goal) => {
    const now = new Date();
    const start = new Date(goal.start_date);
    const end = new Date(goal.end_date);

    let currentValue = 0;
    
    // Filtrar transações relevantes para a meta
    const relevantTransactions = transactions.filter((t) => {
      const tDate = new Date(t.due_date);
      const isInPeriod = tDate >= start && tDate <= end;
      const isPaid = t.status === "pago" || t.status === "recebido";
      
      if (goal.type === "receita") {
        return isInPeriod && isPaid && t.type === "receita" && 
               (!goal.category || t.category === goal.category);
      } else if (goal.type === "despesa") {
        return isInPeriod && isPaid && t.type === "despesa" && 
               (!goal.category || t.category === goal.category);
      } else if (goal.type === "economia") {
        return isInPeriod && isPaid;
      }
      return false;
    });

    if (goal.type === "receita") {
      currentValue = relevantTransactions.reduce((sum, t) => sum + t.amount, 0);
    } else if (goal.type === "despesa") {
      currentValue = goal.target_value - relevantTransactions.reduce((sum, t) => sum + t.amount, 0);
    } else if (goal.type === "economia") {
      const receitas = relevantTransactions.filter(t => t.type === "receita").reduce((sum, t) => sum + t.amount, 0);
      const despesas = relevantTransactions.filter(t => t.type === "despesa").reduce((sum, t) => sum + t.amount, 0);
      currentValue = receitas - despesas;
    }

    const progress = (currentValue / goal.target_value) * 100;
    const daysRemaining = differenceInDays(end, now);
    const businessDaysRemaining = differenceInBusinessDays(end, now);
    const totalDays = differenceInDays(end, start);
    const totalBusinessDays = differenceInBusinessDays(end, start);
    const businessDaysElapsed = totalBusinessDays - businessDaysRemaining;
    const timeElapsed = totalDays > 0 ? ((totalDays - daysRemaining) / totalDays) * 100 : 0;

    const valueNeeded = goal.target_value - currentValue;
    const dailyTarget = businessDaysRemaining > 0 ? valueNeeded / businessDaysRemaining : 0;
    const originalDailyTarget = totalBusinessDays > 0 ? goal.target_value / totalBusinessDays : 0;
    const dailyAverage = businessDaysElapsed > 0 ? currentValue / businessDaysElapsed : 0;
    const projectedTotal = totalBusinessDays > 0 ? (dailyAverage * totalBusinessDays) : 0;
    const variance = currentValue - (originalDailyTarget * businessDaysElapsed);
    const accomplishmentRate = businessDaysElapsed > 0 ? (currentValue / (originalDailyTarget * businessDaysElapsed)) * 100 : 0;

    const isDelayed = timeElapsed > progress && daysRemaining > 0;

    return {
      currentValue,
      progress: Math.min(progress, 100),
      daysRemaining,
      businessDaysRemaining,
      totalBusinessDays,
      businessDaysElapsed,
      dailyTarget,
      originalDailyTarget,
      dailyAverage,
      projectedTotal,
      variance,
      accomplishmentRate,
      valueNeeded,
      isDelayed,
      timeElapsed
    };
  };

  const generateAIAnalysis = async (goal) => {
    const goalId = goal.id;
    setLoadingAI(prev => ({ ...prev, [goalId]: true }));
    
    const metrics = calculateProgress(goal);
    
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analise esta meta financeira em DETALHES:

META: ${goal.name}
Tipo: ${goal.type}
Descrição: ${goal.description || "N/A"}
Valor Alvo: R$ ${goal.target_value.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
Progresso Atual: R$ ${metrics.currentValue.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (${metrics.progress.toFixed(1)}%)
Período: ${format(new Date(goal.start_date), "dd/MM/yyyy")} até ${format(new Date(goal.end_date), "dd/MM/yyyy")}
Dias Restantes: ${metrics.daysRemaining}
Meta Diária Necessária: R$ ${metrics.dailyTarget.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
Status: ${metrics.isDelayed ? "ATRASADA" : "NO PRAZO"}

Forneça análise COMPLETA:
1. ✅ Status atual
2. 📊 Análise de tendência
3. 🎯 Projeção de alcance
4. 💡 5 recomendações ESPECÍFICAS
5. ⚠️ Alertas sobre riscos
6. 🔮 Previsão de conclusão`,
      });

      setAiAnalysis(prev => ({ ...prev, [goalId]: result }));
      
      // Salvar análise no banco
      await base44.entities.Goal.update(goal.id, {
        ai_analysis: result,
        last_ai_update: new Date().toISOString()
      });
      
    } catch (error) {
      console.error("Erro ao gerar análise:", error);
      toast.error("Erro ao gerar análise da meta.");
    }
    
    setLoadingAI(prev => ({ ...prev, [goalId]: false }));
  };

  // GERAR AJUSTES INTELIGENTES COM IA
  const generateGoalAdjustments = async (goal) => {
    const goalId = goal.id;
    setLoadingAdjustments(prev => ({ ...prev, [goalId]: true }));
    
    const metrics = calculateProgress(goal);
    
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Você é um consultor financeiro especialista. Analise esta meta e SUGIRA AJUSTES INTELIGENTES se necessário:

META: ${goal.name}
Tipo: ${goal.type}
Valor Alvo: R$ ${goal.target_value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
Progresso Atual: R$ ${metrics.currentValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })} (${metrics.progress.toFixed(1)}%)
Dias Úteis Restantes: ${metrics.businessDaysRemaining}
Taxa de Cumprimento: ${metrics.accomplishmentRate.toFixed(1)}%
Meta Diária Necessária: R$ ${metrics.dailyTarget.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
Meta Diária Original: R$ ${metrics.originalDailyTarget.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
Projeção Total: R$ ${metrics.projectedTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}

Baseado nestes dados, forneça:

1. **should_adjust** (boolean): true se a meta precisa de ajustes, false se está no caminho certo
2. **adjustment_reason** (string): Razão clara e objetiva para o ajuste
3. **suggested_target_value** (number): Novo valor alvo sugerido (realista e alcançável)
4. **suggested_end_date** (string): Nova data de término sugerida no formato YYYY-MM-DD
5. **adjustment_rationale** (string): Justificativa detalhada do ajuste
6. **action_items** (array de strings): 3-5 ações concretas para atingir a meta ajustada
7. **risk_level** (string): "baixo", "medio" ou "alto"
8. **confidence_score** (number de 1-10): Confiança na viabilidade da meta ajustada`,
        response_json_schema: {
          type: "object",
          properties: {
            should_adjust: { type: "boolean" },
            adjustment_reason: { type: "string" },
            suggested_target_value: { type: "number" },
            suggested_end_date: { type: "string" },
            adjustment_rationale: { type: "string" },
            action_items: { type: "array", items: { type: "string" } },
            risk_level: { type: "string", enum: ["baixo", "medio", "alto"] },
            confidence_score: { type: "number" }
          }
        }
      });

      setGoalAdjustments(prev => ({ ...prev, [goalId]: result }));
      
      if (result.should_adjust) {
        toast.info("💡 IA sugere ajustes para esta meta!");
      } else {
        toast.success("✅ Meta está no caminho certo!");
      }
      
    } catch (error) {
      console.error("Erro ao gerar ajustes:", error);
      toast.error("Erro ao gerar ajustes da meta.");
    }
    
    setLoadingAdjustments(prev => ({ ...prev, [goalId]: false }));
  };

  // CALCULAR BREAKDOWN MENSAL
  const calculateMonthlyBreakdown = (goal) => {
    const start = new Date(goal.start_date);
    const end = new Date(goal.end_date);
    const months = [];
    
    let currentMonth = startOfMonth(start);
    const endMonth = endOfMonth(end);
    
    while (currentMonth <= endMonth) {
      const monthStart = currentMonth > start ? currentMonth : start;
      const monthEnd = endOfMonth(currentMonth) < end ? endOfMonth(currentMonth) : end;
      
      const monthTransactions = transactions.filter(t => {
        const tDate = new Date(t.due_date);
        const isPaid = t.status === "pago" || t.status === "recebido";
        const isInMonth = tDate >= monthStart && tDate <= monthEnd;
        
        if (goal.type === "receita") {
          return isInMonth && isPaid && t.type === "receita" && (!goal.category || t.category === goal.category);
        } else if (goal.type === "despesa") {
          return isInMonth && isPaid && t.type === "despesa" && (!goal.category || t.category === goal.category);
        } else if (goal.type === "economia") {
          return isInMonth && isPaid;
        }
        return false;
      });
      
      let actualValue = 0;
      if (goal.type === "receita") {
        actualValue = monthTransactions.reduce((sum, t) => sum + t.amount, 0);
      } else if (goal.type === "despesa") {
        const spent = monthTransactions.reduce((sum, t) => sum + t.amount, 0);
        actualValue = spent; // Mostrar o que foi gasto
      } else if (goal.type === "economia") {
        const receitas = monthTransactions.filter(t => t.type === "receita").reduce((sum, t) => sum + t.amount, 0);
        const despesas = monthTransactions.filter(t => t.type === "despesa").reduce((sum, t) => sum + t.amount, 0);
        actualValue = receitas - despesas;
      }
      
      // Calcular projeção baseada no período
      const totalDays = differenceInDays(end, start);
      const daysInMonth = differenceInDays(monthEnd, monthStart) + 1;
      const projectedForMonth = (goal.target_value / totalDays) * daysInMonth;
      
      months.push({
        month: format(currentMonth, "MMM/yy", { locale: ptBR }),
        projetado: projectedForMonth,
        real: actualValue,
        isPast: monthEnd < new Date()
      });
      
      currentMonth = addMonths(currentMonth, 1);
      currentMonth = startOfMonth(currentMonth);
    }
    
    return months;
  };

  // CALCULAR HEATMAP DE PROGRESSO DIÁRIO
  const calculateDailyHeatmap = (goal) => {
    const start = new Date(goal.start_date);
    const end = new Date(goal.end_date);
    const days = [];
    
    let currentDay = new Date(start);
    const now = new Date();
    
    while (currentDay <= end && currentDay <= now) {
      const dayStr = format(currentDay, "yyyy-MM-dd");
      
      const dayTransactions = transactions.filter(t => {
        const isPaid = t.status === "pago" || t.status === "recebido";
        const isThisDay = t.due_date === dayStr;
        
        if (goal.type === "receita") {
          return isThisDay && isPaid && t.type === "receita" && (!goal.category || t.category === goal.category);
        } else if (goal.type === "despesa") {
          return isThisDay && isPaid && t.type === "despesa" && (!goal.category || t.category === goal.category);
        } else if (goal.type === "economia") {
          return isThisDay && isPaid;
        }
        return false;
      });
      
      let dailyValue = 0;
      if (goal.type === "receita") {
        dailyValue = dayTransactions.reduce((sum, t) => sum + t.amount, 0);
      } else if (goal.type === "despesa") {
        dailyValue = dayTransactions.reduce((sum, t) => sum + t.amount, 0);
      } else if (goal.type === "economia") {
        const receitas = dayTransactions.filter(t => t.type === "receita").reduce((sum, t) => sum + t.amount, 0);
        const despesas = dayTransactions.filter(t => t.type === "despesa").reduce((sum, t) => sum + t.amount, 0);
        dailyValue = receitas - despesas;
      }
      
      const metrics = calculateProgress(goal);
      const targetDaily = metrics.originalDailyTarget;
      const performanceRate = targetDaily > 0 ? (dailyValue / targetDaily) * 100 : 0;
      
      days.push({
        date: format(currentDay, "dd/MM", { locale: ptBR }),
        value: dailyValue,
        performanceRate: performanceRate,
        level: performanceRate >= 100 ? 'excelente' : performanceRate >= 80 ? 'bom' : performanceRate >= 50 ? 'medio' : performanceRate > 0 ? 'baixo' : 'zero'
      });
      
      currentDay = addMonths(currentDay, 0);
      currentDay.setDate(currentDay.getDate() + 1);
    }
    
    return days.slice(-30); // Últimos 30 dias
  };

  // SUGERIR METAS COM IA
  const suggestGoalsWithAI = async () => {
    setSuggestingGoals(true);
    try {
      const sixMonthsAgo = subMonths(new Date(), 6);
      const last6Months = transactions.filter(t => {
        const tDate = new Date(t.due_date);
        return tDate >= sixMonthsAgo && (t.status === "pago" || t.status === "recebido");
      });

      const avgMonthlyRevenue = last6Months
        .filter(t => t.type === "receita")
        .reduce((sum, t) => sum + t.amount, 0) / 6;

      const avgMonthlyExpenses = last6Months
        .filter(t => t.type === "despesa")
        .reduce((sum, t) => sum + t.amount, 0) / 6;

      const expensesByCategory = last6Months
        .filter(t => t.type === "despesa")
        .reduce((acc, t) => {
          const cat = t.category || "Outros";
          acc[cat] = (acc[cat] || 0) + t.amount;
          return acc;
        }, {});

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Com base no histórico de 6 meses, sugira 5 METAS FINANCEIRAS REALISTAS e INTELIGENTES:

DADOS RECENTES (Últimos 6 meses):
- Receita Média Mensal: R$ ${avgMonthlyRevenue.toFixed(2)}
- Despesa Média Mensal: R$ ${avgMonthlyExpenses.toFixed(2)}
- Saldo Médio Mensal: R$ ${(avgMonthlyRevenue - avgMonthlyExpenses).toFixed(2)}

PRINCIPAIS DESPESAS POR CATEGORIA:
${Object.entries(expensesByCategory)
  .sort((a, b) => b[1] - a[1])
  .slice(0, 10) // Top 10 categories
  .map(([cat, val]) => `- ${cat}: R$ ${val.toFixed(2)}`)
  .join('\n')}

Forneça as sugestões de metas em formato JSON. Cada meta deve ter:
- "name": Nome claro e conciso da meta (string)
- "description": Descrição detalhada do objetivo da meta e por que ela é importante (string)
- "type": Tipo da meta ("receita", "despesa", ou "economia") (string)
- "target_value": Valor numérico do objetivo da meta (number)
- "frequency": Frequência sugerida para a meta ("mensal", "trimestral", ou "anual") (string)
- "category": Categoria principal à qual a meta se aplica (string, pode ser vazia se não se aplica a uma categoria específica)
- "rationale": Justificativa clara e baseada nos dados fornecidos para a sugestão dessa meta específica (string)

Formato JSON esperado:
{
  "goals": [
    {
      "name": "string",
      "description": "string",
      "type": "receita|despesa|economia",
      "target_value": number,
      "frequency": "mensal|trimestral|anual",
      "category": "string",
      "rationale": "string"
    }
  ]
}`,
        response_json_schema: {
          type: "object",
          properties: {
            goals: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  description: { type: "string" },
                  type: { type: "string", enum: ["receita", "despesa", "economia"] },
                  target_value: { type: "number" },
                  frequency: { type: "string", enum: ["mensal", "trimestral", "anual"] },
                  category: { type: "string" },
                  rationale: { type: "string" }
                },
                required: ["name", "description", "type", "target_value", "frequency", "rationale"]
              }
            }
          }
        }
      });

      setSuggestedGoals(result.goals || []);
      setShowSuggestionsDialog(true);
      toast.success("✅ Metas sugeridas pela IA!");
    } catch (error) {
      console.error("Erro ao gerar sugestões:", error);
      toast.error("Erro ao gerar sugestões de metas.");
    }
    setSuggestingGoals(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    const data = {
      name: formData.get("name"),
      description: formData.get("description"),
      type: formData.get("type"),
      target_value: parseFloat(formData.get("target_value")),
      start_date: formData.get("start_date"),
      end_date: formData.get("end_date"),
      category: formData.get("category"),
      cost_center: formData.get("cost_center"),
      frequency: formData.get("frequency"),
      status: formData.get("status"),
      alert_threshold: parseFloat(formData.get("alert_threshold") || 80),
    };

    try {
      if (editingGoal) {
        await updateMutation.mutateAsync({ id: editingGoal.id, data });
        toast.success("Meta atualizada com sucesso!");
      } else {
        await createMutation.mutateAsync(data);
        toast.success("Meta criada com sucesso!");
      }
    } catch (error) {
      console.error("Erro ao salvar meta:", error);
      toast.error("Erro ao salvar meta.");
    }
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white drop-shadow-lg">Metas Financeiras</h1>
          <p className="text-blue-200 mt-1">Defina e acompanhe com IA</p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={suggestGoalsWithAI} 
            disabled={suggestingGoals}
            className="bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600 shadow-lg"
          >
            <Sparkles className={`w-4 h-4 mr-2 ${suggestingGoals ? 'animate-spin' : ''}`} />
            {suggestingGoals ? "Gerando..." : "IA Sugerir Metas"}
          </Button>
          <Dialog open={showDialog} onOpenChange={setShowDialog}>
            <DialogTrigger asChild>
              <Button 
                onClick={() => setEditingGoal(null)}
                className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600 shadow-lg"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Meta
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-blue-900 border-blue-700 text-white">
              <DialogHeader>
                <DialogTitle className="text-xl text-white">
                  {editingGoal ? "Editar Meta" : "Nova Meta"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label className="text-blue-200">Nome da Meta*</Label>
                  <Input
                    name="name"
                    defaultValue={editingGoal?.name}
                    required
                    className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                  />
                </div>

                <div>
                  <Label className="text-blue-200">Descrição</Label>
                  <Textarea
                    name="description"
                    defaultValue={editingGoal?.description}
                    className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-blue-200">Tipo de Meta*</Label>
                    <Select name="type" defaultValue={editingGoal?.type || "receita"} required>
                      <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-blue-900 border-blue-700">
                        <SelectItem value="receita">Receita</SelectItem>
                        <SelectItem value="despesa">Despesa</SelectItem>
                        <SelectItem value="economia">Economia</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-blue-200">Valor Alvo*</Label>
                    <CurrencyInput
                      name="target_value"
                      defaultValue={editingGoal?.target_value}
                      required
                      className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-blue-200">Data de Início*</Label>
                    <Input
                      name="start_date"
                      type="date"
                      defaultValue={editingGoal?.start_date}
                      required
                      className="bg-blue-950/50 border-blue-700 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-blue-200">Data de Término*</Label>
                    <Input
                      name="end_date"
                      type="date"
                      defaultValue={editingGoal?.end_date}
                      required
                      className="bg-blue-950/50 border-blue-700 text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-blue-200">Categoria (opcional)</Label>
                    <Input
                      name="category"
                      defaultValue={editingGoal?.category}
                      className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                    />
                  </div>
                  <div>
                    <Label className="text-blue-200">Centro de Custo (opcional)</Label>
                    <Input
                      name="cost_center"
                      defaultValue={editingGoal?.cost_center}
                      className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label className="text-blue-200">Frequência</Label>
                    <Select name="frequency" defaultValue={editingGoal?.frequency || "mensal"}>
                      <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-blue-900 border-blue-700">
                        <SelectItem value="mensal">Mensal</SelectItem>
                        <SelectItem value="trimestral">Trimestral</SelectItem>
                        <SelectItem value="anual">Anual</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-blue-200">Status</Label>
                    <Select name="status" defaultValue={editingGoal?.status || "ativa"}>
                      <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-blue-900 border-blue-700">
                        <SelectItem value="ativa">Ativa</SelectItem>
                        <SelectItem value="pausada">Pausada</SelectItem>
                        <SelectItem value="concluida">Concluída</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-blue-200">Alerta em (%)</Label>
                    <Input
                      name="alert_threshold"
                      type="number"
                      step="1"
                      defaultValue={editingGoal?.alert_threshold || 80}
                      className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-4 border-t border-blue-700">
                  <Button type="button" variant="outline" onClick={() => setShowDialog(false)} className="border-blue-700 text-blue-200 hover:bg-blue-800">
                    Cancelar
                  </Button>
                  <Button type="submit" className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600">
                    {editingGoal ? "Atualizar Meta" : "Criar Meta"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* DIALOG SUGESTÕES */}
      <Dialog open={showSuggestionsDialog} onOpenChange={setShowSuggestionsDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-blue-900 border-blue-700">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-400" />
              Metas Sugeridas pela IA
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {suggestedGoals.length > 0 ? (
              suggestedGoals.map((goal, index) => (
                <Card key={index} className="border-purple-500/50 bg-blue-950/50">
                  <CardHeader>
                    <CardTitle className="text-white text-lg">{goal.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-blue-200 text-sm">{goal.description}</p>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <span className="text-blue-300">Tipo:</span>
                        <Badge className="ml-2 bg-purple-500/20 text-purple-300">{goal.type}</Badge>
                      </div>
                      <div>
                        <span className="text-blue-300">Valor:</span>
                        <span className="ml-2 text-white font-semibold">
                          R$ {goal.target_value.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                    </div>
                    {goal.category && (
                      <div className="text-sm">
                        <span className="text-blue-300">Categoria:</span>
                        <span className="ml-2 text-white">{goal.category}</span>
                      </div>
                    )}
                    <div className="bg-purple-950/30 p-3 rounded-lg border border-purple-700">
                      <p className="text-xs text-purple-300 font-semibold mb-1">Justificativa:</p>
                      <p className="text-sm text-purple-200 whitespace-pre-wrap">{goal.rationale}</p>
                    </div>
                    <Button
                      onClick={async () => {
                        const startDate = new Date();
                        let endDate;
                        if (goal.frequency === "mensal") {
                          endDate = addMonths(startDate, 1);
                        } else if (goal.frequency === "trimestral") {
                          endDate = addMonths(startDate, 3);
                        } else { // anual or default
                          endDate = addMonths(startDate, 12);
                        }
                        
                        await createMutation.mutateAsync({
                          name: goal.name,
                          description: goal.description,
                          type: goal.type,
                          target_value: goal.target_value,
                          start_date: format(startDate, "yyyy-MM-dd"),
                          end_date: format(endDate, "yyyy-MM-dd"),
                          category: goal.category,
                          frequency: goal.frequency,
                          status: "ativa"
                        });
                        
                        toast.success(`✅ Meta "${goal.name}" criada com sucesso!`);
                      }}
                      className="w-full bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Criar Esta Meta
                    </Button>
                  </CardContent>
                </Card>
              ))
            ) : (
              <p className="text-blue-200 text-center">Nenhuma meta sugerida no momento.</p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* GRÁFICO DE RECEITAS DIÁRIAS */}
      <Card className="border-green-700/50 bg-gradient-to-br from-green-900/80 to-green-800/80">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-400" />
            Receitas Diárias - Últimos 30 Dias
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart
              data={(() => {
                const last30Days = [];
                const now = new Date();
                
                for (let i = 29; i >= 0; i--) {
                  const date = new Date(now);
                  date.setDate(date.getDate() - i);
                  const dateStr = format(date, "yyyy-MM-dd");
                  
                  const dayTransactions = transactions.filter(t => {
                    return t.due_date === dateStr && t.type === "receita" && (t.status === "pago" || t.status === "recebido");
                  });
                  
                  const total = dayTransactions.reduce((sum, t) => sum + t.amount, 0);
                  
                  last30Days.push({
                    date: format(date, "dd/MM", { locale: ptBR }),
                    receita: total
                  });
                }
                
                return last30Days;
              })()}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
              <XAxis 
                dataKey="date" 
                stroke="#93c5fd" 
                fontSize={10}
                angle={-45}
                textAnchor="end"
                height={60}
              />
              <YAxis 
                stroke="#93c5fd" 
                fontSize={12}
                tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
              />
              <Tooltip
                contentStyle={{ 
                  backgroundColor: "#1e3a8a", 
                  border: "1px solid #3b82f6", 
                  borderRadius: "8px",
                  color: "#fff"
                }}
                formatter={(value) => [`R$ ${value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, "Receita"]}
              />
              <Bar 
                dataKey="receita" 
                fill="#10B981" 
                radius={[8, 8, 0, 0]}
                name="Receita Diária"
              />
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-4 text-center">
            <p className="text-sm text-green-200">
              Total do período: <span className="font-bold text-white">
                R$ {transactions
                  .filter(t => {
                    const tDate = new Date(t.due_date);
                    const thirtyDaysAgo = new Date();
                    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
                    return tDate >= thirtyDaysAgo && t.type === "receita" && (t.status === "pago" || t.status === "recebido");
                  })
                  .reduce((sum, t) => sum + t.amount, 0)
                  .toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
              </span>
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Resumo das Metas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-blue-500/50 bg-gradient-to-br from-blue-800/80 to-blue-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <Target className="w-8 h-8 text-blue-300 mx-auto mb-2" />
              <p className="text-sm text-blue-200">Total de Metas</p>
              <p className="text-3xl font-bold text-white mt-1">{goals.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-green-500/50 bg-gradient-to-br from-green-800/80 to-green-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <CheckCircle className="w-8 h-8 text-green-300 mx-auto mb-2" />
              <p className="text-sm text-green-200">Metas Ativas</p>
              <p className="text-3xl font-bold text-white mt-1">
                {goals.filter(g => g.status === "ativa").length}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-yellow-500/50 bg-gradient-to-br from-yellow-800/80 to-yellow-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <AlertTriangle className="w-8 h-8 text-yellow-300 mx-auto mb-2" />
              <p className="text-sm text-yellow-200">Metas Atrasadas</p>
              <p className="text-3xl font-bold text-white mt-1">
                {goals.filter(g => {
                  const metrics = calculateProgress(g);
                  return metrics.isDelayed && g.status === "ativa";
                }).length}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-800/80 to-purple-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <TrendingUp className="w-8 h-8 text-purple-300 mx-auto mb-2" />
              <p className="text-sm text-purple-200">Taxa Média</p>
              <p className="text-3xl font-bold text-white mt-1">
                {goals.length > 0 
                  ? (goals.reduce((sum, g) => sum + calculateProgress(g).progress, 0) / goals.length).toFixed(1)
                  : 0}%
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Lista de Metas */}
      <div className="space-y-4">
        {goals.map((goal) => {
          const metrics = calculateProgress(goal);
          const goalAI = aiAnalysis[goal.id];
          const isLoadingAI = loadingAI[goal.id];

          return (
            <Card 
              key={goal.id} 
              className={`border-2 ${
                metrics.isDelayed 
                  ? "border-red-500/50 bg-gradient-to-br from-red-900/30 to-blue-900/80" 
                  : "border-blue-500/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80"
              } backdrop-blur-sm shadow-xl`}
            >
              <CardHeader>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div className="flex items-center gap-3">
                    <Target className="w-6 h-6 text-blue-400" />
                    <div>
                      <CardTitle className="text-white text-xl">{goal.name}</CardTitle>
                      {goal.description && (
                        <p className="text-sm text-blue-300 mt-1">{goal.description}</p>
                      )}
                      <div className="flex items-center gap-2 mt-2">
                        {metrics.isDelayed && (
                          <Badge className="bg-red-500 text-white">Atrasado</Badge>
                        )}
                        <Badge variant="outline" className="text-blue-200 border-blue-500">
                          {format(new Date(goal.start_date), "dd/MM/yyyy")} até {format(new Date(goal.end_date), "dd/MM/yyyy")}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setEditingGoal(goal);
                        setShowDialog(true);
                      }}
                      className="text-blue-300 hover:bg-blue-800"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        if (confirm("Tem certeza que deseja excluir esta meta?")) {
                          deleteMutation.mutate(goal.id);
                          toast.success("Meta excluída com sucesso!");
                        }
                      }}
                      className="text-red-400 hover:bg-red-800"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Primeira linha - Principais Métricas */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-blue-950/50 p-4 rounded-lg border border-blue-700">
                    <p className="text-xs text-blue-300 flex items-center gap-1">
                      <Target className="w-3 h-3" /> Valor Alvo
                    </p>
                    <p className="text-xl font-bold text-white">
                      R$ {goal.target_value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div className="bg-green-950/50 p-4 rounded-lg border border-green-700">
                    <p className="text-xs text-green-300 flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" /> Atingido
                    </p>
                    <p className="text-xl font-bold text-white">
                      R$ {metrics.currentValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-green-400">{metrics.progress.toFixed(1)}% da meta</p>
                  </div>
                  <div className="bg-red-950/50 p-4 rounded-lg border border-red-700">
                    <p className="text-xs text-red-300 flex items-center gap-1">
                      <XCircle className="w-3 h-3" /> Faltam
                    </p>
                    <p className="text-xl font-bold text-white">
                      R$ {metrics.valueNeeded.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-red-400">{metrics.businessDaysRemaining} dias úteis</p>
                  </div>
                  <div className="bg-purple-950/50 p-4 rounded-lg border border-purple-700">
                    <p className="text-xs text-purple-300 flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> Meta Diária Atual
                    </p>
                    <p className="text-xl font-bold text-white">
                      R$ {metrics.dailyTarget.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-purple-400">Original: R$ {metrics.originalDailyTarget.toFixed(2)}</p>
                  </div>
                </div>

                {/* Segunda linha - Informações Detalhadas de Dias Úteis e Andamento */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-blue-950/30 p-3 rounded-lg border border-blue-600">
                    <p className="text-xs text-blue-300">📅 Total Dias Úteis</p>
                    <p className="text-lg font-bold text-white">{metrics.totalBusinessDays} dias</p>
                    <p className="text-xs text-blue-400">Do período completo</p>
                  </div>
                  <div className="bg-orange-950/30 p-3 rounded-lg border border-orange-600">
                    <p className="text-xs text-orange-300">⏱️ Dias Úteis Decorridos</p>
                    <p className="text-lg font-bold text-white">{metrics.businessDaysElapsed} dias</p>
                    <p className="text-xs text-orange-400">Já trabalhados</p>
                  </div>
                  <div className="bg-cyan-950/30 p-3 rounded-lg border border-cyan-600">
                    <p className="text-xs text-cyan-300">📊 Média Diária Real</p>
                    <p className="text-lg font-bold text-white">
                      R$ {metrics.dailyAverage.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-cyan-400">Ritmo atual</p>
                  </div>
                  <div className="bg-indigo-950/30 p-3 rounded-lg border border-indigo-600">
                    <p className="text-xs text-indigo-300">🎯 Projeção Total</p>
                    <p className="text-lg font-bold text-white">
                      R$ {metrics.projectedTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-indigo-400">No ritmo atual</p>
                  </div>
                </div>

                {/* Terceira linha - Variação e Taxa de Cumprimento */}
                <div className="grid grid-cols-2 gap-4">
                  <div className={`p-3 rounded-lg border ${metrics.variance >= 0 ? 'bg-green-950/30 border-green-600' : 'bg-red-950/30 border-red-600'}`}>
                    <p className={`text-xs ${metrics.variance >= 0 ? 'text-green-300' : 'text-red-300'}`}>
                      {metrics.variance >= 0 ? '✅' : '⚠️'} Variação do Esperado
                    </p>
                    <p className={`text-lg font-bold ${metrics.variance >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {metrics.variance >= 0 ? '+' : ''}R$ {metrics.variance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-gray-400">
                      {metrics.variance >= 0 ? 'Acima do esperado' : 'Abaixo do esperado'}
                    </p>
                  </div>
                  <div className={`p-3 rounded-lg border ${metrics.accomplishmentRate >= 100 ? 'bg-green-950/30 border-green-600' : metrics.accomplishmentRate >= 80 ? 'bg-yellow-950/30 border-yellow-600' : 'bg-red-950/30 border-red-600'}`}>
                    <p className={`text-xs ${metrics.accomplishmentRate >= 100 ? 'text-green-300' : metrics.accomplishmentRate >= 80 ? 'text-yellow-300' : 'text-red-300'}`}>
                      📈 Taxa de Cumprimento
                    </p>
                    <p className={`text-lg font-bold ${metrics.accomplishmentRate >= 100 ? 'text-green-400' : metrics.accomplishmentRate >= 80 ? 'text-yellow-400' : 'text-red-400'}`}>
                      {metrics.accomplishmentRate.toFixed(1)}%
                    </p>
                    <p className="text-xs text-gray-400">
                      Do esperado até hoje
                    </p>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-blue-200">Progresso da Meta</span>
                    <span className="text-sm font-bold text-white">{metrics.progress.toFixed(1)}%</span>
                  </div>
                  <Progress value={metrics.progress} className="h-3 bg-blue-950" />
                </div>

                {metrics.isDelayed && (
                  <Card className="bg-red-900/30 border-red-500">
                    <CardContent className="pt-4">
                      <div className="flex items-start gap-3">
                        <AlertTriangle className="w-5 h-5 text-red-400 mt-1" />
                        <div>
                          <p className="font-bold text-red-200">⚠️ Meta Atrasada</p>
                          <p className="text-sm text-red-300 mt-1">
                            Esperado até hoje: R$ {(goal.target_value * (metrics.timeElapsed / 100)).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}. 
                            Você está R$ {((goal.target_value * (metrics.timeElapsed / 100)) - metrics.currentValue).toLocaleString("pt-BR", { minimumFractionDigits: 2 })} abaixo.
                          </p>
                          <p className="text-sm text-red-200 mt-1">
                            Para recuperar, você precisa de R$ {metrics.dailyTarget.toLocaleString("pt-BR", { minimumFractionDigits: 2 })} por dia útil.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                <div className="flex gap-2">
                  <Button
                    onClick={() => generateAIAnalysis(goal)}
                    disabled={isLoadingAI}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600 shadow-lg"
                  >
                    <Sparkles className={`w-4 h-4 mr-2 ${isLoadingAI ? "animate-spin" : ""}`} />
                    {isLoadingAI ? "Analisando..." : "Análise Inteligente com IA"}
                  </Button>
                  <Button
                    onClick={async () => {
                      try {
                        const settings = await base44.entities.CompanySettings.list();
                        const companySettings = settings && settings.length > 0 ? settings[0] : null;
                        
                        if (!companySettings?.whatsapp_number) {
                          toast.error("Configure o número WhatsApp em Configurações");
                          return;
                        }

                        const resumo = `📊 *RESUMO DA META - ${goal.name}*
                        
🎯 *Valor Alvo:* R$ ${goal.target_value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
✅ *Atingido:* R$ ${metrics.currentValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })} (${metrics.progress.toFixed(1)}%)
⏰ *Dias Úteis Restantes:* ${metrics.businessDaysRemaining}
💰 *Meta Diária Necessária:* R$ ${metrics.dailyTarget.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}

📅 *Dias Úteis:*
- Total: ${metrics.totalBusinessDays}
- Decorridos: ${metrics.businessDaysElapsed}
- Restantes: ${metrics.businessDaysRemaining}

📊 *Andamento:*
- Média Diária Real: R$ ${metrics.dailyAverage.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
- Projeção Total: R$ ${metrics.projectedTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
- Variação: ${metrics.variance >= 0 ? '+' : ''}R$ ${metrics.variance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
- Taxa de Cumprimento: ${metrics.accomplishmentRate.toFixed(1)}%

${metrics.isDelayed ? '⚠️ *ATENÇÃO:* Meta está atrasada! Acelere o ritmo.' : '✅ Meta no prazo!'}

📅 Período: ${format(new Date(goal.start_date), "dd/MM/yyyy")} até ${format(new Date(goal.end_date), "dd/MM/yyyy")}`;

                        const { sendWhatsAppMessage } = await import("../components/whatsapp/WhatsAppSender");
                        await sendWhatsAppMessage(companySettings.whatsapp_number, resumo);
                      } catch (error) {
                        console.error("Erro ao enviar resumo:", error);
                        toast.error("❌ Erro ao enviar resumo");
                      }
                    }}
                    className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600 shadow-lg"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Enviar WhatsApp
                  </Button>
                </div>

                {goalAI && (
                  <Card className="bg-purple-900/30 border-purple-500">
                    <CardContent className="pt-4">
                      <div className="prose prose-invert prose-sm max-w-none text-blue-100 whitespace-pre-wrap leading-relaxed">
                        {goalAI}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* BREAKDOWN MENSAL */}
                <Card className="bg-blue-950/30 border-blue-500">
                  <CardHeader>
                    <CardTitle className="text-white text-lg flex items-center gap-2">
                      <BarChart className="w-5 h-5 text-blue-400" />
                      Breakdown Mensal - Projetado vs Real
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <ComposedChart data={calculateMonthlyBreakdown(goal)}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
                        <XAxis dataKey="month" stroke="#93c5fd" fontSize={12} />
                        <YAxis stroke="#93c5fd" fontSize={12} />
                        <Tooltip
                          contentStyle={{ 
                            backgroundColor: "#1e3a8a", 
                            border: "1px solid #3b82f6", 
                            borderRadius: "8px",
                            color: "#fff"
                          }}
                          formatter={(value) => `R$ ${value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
                        />
                        <Legend />
                        <Bar dataKey="projetado" fill="#3B82F6" name="Projetado" radius={[8, 8, 0, 0]} />
                        <Bar dataKey="real" fill="#10B981" name="Real" radius={[8, 8, 0, 0]} />
                        <Line type="monotone" dataKey="real" stroke="#EF4444" strokeWidth={2} name="Tendência" />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                {/* HEATMAP DE PROGRESSO DIÁRIO */}
                <Card className="bg-indigo-950/30 border-indigo-500">
                  <CardHeader>
                    <CardTitle className="text-white text-lg flex items-center gap-2">
                      <Calendar className="w-5 h-5 text-indigo-400" />
                      Heatmap de Desempenho Diário (Últimos 30 Dias)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-10 gap-1 mb-4">
                      {calculateDailyHeatmap(goal).map((day, idx) => (
                        <div
                          key={idx}
                          className={`h-12 rounded flex flex-col items-center justify-center cursor-pointer transition-all hover:scale-110 ${
                            day.level === 'excelente' ? 'bg-green-500' :
                            day.level === 'bom' ? 'bg-green-400' :
                            day.level === 'medio' ? 'bg-yellow-400' :
                            day.level === 'baixo' ? 'bg-red-400' :
                            'bg-gray-600'
                          }`}
                          title={`${day.date}: R$ ${day.value.toFixed(2)} (${day.performanceRate.toFixed(0)}%)`}
                        >
                          <span className="text-[8px] text-white font-bold">{day.date}</span>
                          <span className="text-[10px] text-white font-bold">{day.performanceRate.toFixed(0)}%</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex items-center justify-center gap-4 text-xs">
                      <div className="flex items-center gap-1">
                        <div className="w-4 h-4 bg-gray-600 rounded"></div>
                        <span className="text-gray-400">0%</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-4 h-4 bg-red-400 rounded"></div>
                        <span className="text-red-300">1-50%</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-4 h-4 bg-yellow-400 rounded"></div>
                        <span className="text-yellow-300">51-80%</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-4 h-4 bg-green-400 rounded"></div>
                        <span className="text-green-300">81-99%</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-4 h-4 bg-green-500 rounded"></div>
                        <span className="text-green-300">100%+</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* SUGESTÕES DE AJUSTE DA IA */}
                {goalAdjustments[goal.id] && goalAdjustments[goal.id].should_adjust && (
                  <Card className="bg-yellow-900/30 border-yellow-500">
                    <CardHeader>
                      <CardTitle className="text-white text-lg flex items-center gap-2">
                        <AlertTriangle className="w-5 h-5 text-yellow-400" />
                        Sugestões Inteligentes de Ajuste
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="bg-yellow-950/30 p-4 rounded-lg border border-yellow-700">
                        <p className="text-yellow-200 font-semibold mb-2">📊 Razão do Ajuste:</p>
                        <p className="text-yellow-100 text-sm">{goalAdjustments[goal.id].adjustment_reason}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-blue-950/30 p-4 rounded-lg border border-blue-700">
                          <p className="text-blue-300 text-sm mb-1">Valor Atual:</p>
                          <p className="text-white text-xl font-bold">
                            R$ {goal.target_value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </p>
                        </div>
                        <div className="bg-green-950/30 p-4 rounded-lg border border-green-700">
                          <p className="text-green-300 text-sm mb-1">Valor Sugerido:</p>
                          <p className="text-white text-xl font-bold">
                            R$ {goalAdjustments[goal.id].suggested_target_value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-blue-950/30 p-4 rounded-lg border border-blue-700">
                          <p className="text-blue-300 text-sm mb-1">Data Término Atual:</p>
                          <p className="text-white font-bold">{format(new Date(goal.end_date), "dd/MM/yyyy")}</p>
                        </div>
                        <div className="bg-green-950/30 p-4 rounded-lg border border-green-700">
                          <p className="text-green-300 text-sm mb-1">Nova Data Sugerida:</p>
                          <p className="text-white font-bold">{format(new Date(goalAdjustments[goal.id].suggested_end_date), "dd/MM/yyyy")}</p>
                        </div>
                      </div>

                      <div className="bg-purple-950/30 p-4 rounded-lg border border-purple-700">
                        <p className="text-purple-300 font-semibold mb-2">💡 Justificativa:</p>
                        <p className="text-purple-100 text-sm whitespace-pre-wrap">{goalAdjustments[goal.id].adjustment_rationale}</p>
                      </div>

                      <div className="bg-indigo-950/30 p-4 rounded-lg border border-indigo-700">
                        <p className="text-indigo-300 font-semibold mb-3">✅ Ações Recomendadas:</p>
                        <ul className="space-y-2">
                          {goalAdjustments[goal.id].action_items.map((action, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-indigo-100 text-sm">
                              <CheckCircle className="w-4 h-4 text-indigo-400 mt-0.5 flex-shrink-0" />
                              <span>{action}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Badge className={`${
                            goalAdjustments[goal.id].risk_level === 'baixo' ? 'bg-green-500' :
                            goalAdjustments[goal.id].risk_level === 'medio' ? 'bg-yellow-500' :
                            'bg-red-500'
                          } text-white`}>
                            Risco: {goalAdjustments[goal.id].risk_level}
                          </Badge>
                          <Badge className="bg-purple-500 text-white">
                            Confiança: {goalAdjustments[goal.id].confidence_score}/10
                          </Badge>
                        </div>
                        <Button
                          onClick={async () => {
                            if (confirm("Deseja aplicar os ajustes sugeridos pela IA?")) {
                              await updateMutation.mutateAsync({
                                id: goal.id,
                                data: {
                                  target_value: goalAdjustments[goal.id].suggested_target_value,
                                  end_date: goalAdjustments[goal.id].suggested_end_date
                                }
                              });
                              toast.success("✅ Meta ajustada com sucesso!");
                            }
                          }}
                          className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600"
                        >
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Aplicar Ajustes
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}

                <Button
                  onClick={() => generateGoalAdjustments(goal)}
                  disabled={loadingAdjustments[goal.id]}
                  className="w-full bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600"
                >
                  <Target className={`w-4 h-4 mr-2 ${loadingAdjustments[goal.id] ? "animate-spin" : ""}`} />
                  {loadingAdjustments[goal.id] ? "Analisando..." : "Gerar Sugestões de Ajuste com IA"}
                </Button>
              </CardContent>
            </Card>
          );
        })}

        {goals.length === 0 && !isLoading && (
          <Card className="border-blue-700/50 bg-blue-900/50">
            <CardContent className="py-12 text-center">
              <Target className="w-16 h-16 text-blue-400 mx-auto mb-4 opacity-50" />
              <p className="text-blue-200 text-lg">Nenhuma meta cadastrada ainda</p>
              <p className="text-blue-300 text-sm mt-2">Crie sua primeira meta para começar a acompanhar!</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Assistente IA */}
      <AIAssistant 
        context={`Total Metas: ${goals.length}, Ativas: ${goals.filter(g => g.status === "ativa").length}`}
        pageInfo="Metas Financeiras - Acompanhamento e análise de metas"
      />
    </div>
  );
}