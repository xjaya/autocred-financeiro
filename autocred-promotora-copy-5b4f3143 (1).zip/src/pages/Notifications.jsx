import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Bell, Send, Calendar } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { format } from "date-fns";

export default function Notifications() {
  const [showDialog, setShowDialog] = useState(false);

  const queryClient = useQueryClient();

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ["notifications"],
    queryFn: () => base44.entities.Notification.list("-created_date"),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Notification.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
      setShowDialog(false);
      toast.success("Notificação criada com sucesso!");
    },
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    const sendVia = [];
    if (formData.get("send_via_email")) sendVia.push("email");
    if (formData.get("send_via_whatsapp")) sendVia.push("whatsapp");

    const data = {
      title: formData.get("title"),
      message: formData.get("message"),
      type: formData.get("type"),
      recipient_email: formData.get("recipient_email"),
      recipient_phone: formData.get("recipient_phone"),
      send_via: sendVia,
      scheduled_date: formData.get("scheduled_date") || new Date().toISOString(),
      status: "pendente",
    };

    createMutation.mutate(data);
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white drop-shadow-lg">Notificações</h1>
          <p className="text-blue-200 mt-1">Envie notificações por Email e WhatsApp</p>
        </div>
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600 shadow-lg">
              <Plus className="w-4 h-4 mr-2" />
              Nova Notificação
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl bg-blue-900 border-blue-700 text-white">
            <DialogHeader>
              <DialogTitle className="text-white">Nova Notificação</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label className="text-blue-200">Título*</Label>
                <Input name="title" required placeholder="Título da notificação" className="bg-blue-950/50 border-blue-700 text-white" />
              </div>

              <div>
                <Label className="text-blue-200">Mensagem*</Label>
                <Textarea name="message" required rows={4} placeholder="Digite a mensagem..." className="bg-blue-950/50 border-blue-700 text-white" />
              </div>

              <div>
                <Label className="text-blue-200">Tipo</Label>
                <Select name="type" defaultValue="info">
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    <SelectItem value="vencimento">Vencimento</SelectItem>
                    <SelectItem value="pagamento">Pagamento</SelectItem>
                    <SelectItem value="alerta">Alerta</SelectItem>
                    <SelectItem value="info">Informação</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Email do Destinatário</Label>
                  <Input name="recipient_email" type="email" placeholder="email@exemplo.com" className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
                <div>
                  <Label className="text-blue-200">WhatsApp do Destinatário</Label>
                  <Input name="recipient_phone" placeholder="(00) 00000-0000" className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
              </div>

              <div>
                <Label className="text-blue-200 mb-3 block">Enviar por:</Label>
                <div className="flex gap-6">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="send_via_email" name="send_via_email" defaultChecked />
                    <label htmlFor="send_via_email" className="text-blue-200 cursor-pointer">
                      Email
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="send_via_whatsapp" name="send_via_whatsapp" />
                    <label htmlFor="send_via_whatsapp" className="text-blue-200 cursor-pointer">
                      WhatsApp
                    </label>
                  </div>
                </div>
              </div>

              <div>
                <Label className="text-blue-200">Agendar para (opcional)</Label>
                <Input name="scheduled_date" type="datetime-local" className="bg-blue-950/50 border-blue-700 text-white" />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-blue-700">
                <Button type="button" variant="outline" onClick={() => setShowDialog(false)} className="border-blue-700 text-blue-200 hover:bg-blue-800">
                  Cancelar
                </Button>
                <Button type="submit" className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600">
                  <Send className="w-4 h-4 mr-2" />
                  Enviar
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-blue-500/50 bg-gradient-to-br from-blue-800/80 to-blue-700/80 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-blue-200 font-medium">Total de Notificações</p>
              <p className="text-3xl font-bold text-white mt-2">{notifications.length}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-500/50 bg-gradient-to-br from-green-800/80 to-green-700/80 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-green-200 font-medium">Enviadas</p>
              <p className="text-3xl font-bold text-white mt-2">
                {notifications.filter(n => n.status === "enviada").length}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-yellow-500/50 bg-gradient-to-br from-yellow-800/80 to-yellow-700/80 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-sm text-yellow-200 font-medium">Pendentes</p>
              <p className="text-3xl font-bold text-white mt-2">
                {notifications.filter(n => n.status === "pendente").length}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <CardTitle className="text-white">Histórico de Notificações</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="bg-blue-950/50 border-blue-700 hover:bg-blue-950/70">
                <TableHead className="text-blue-300">Título</TableHead>
                <TableHead className="text-blue-300">Tipo</TableHead>
                <TableHead className="text-blue-300">Destinatário</TableHead>
                <TableHead className="text-blue-300">Canais</TableHead>
                <TableHead className="text-blue-300">Data</TableHead>
                <TableHead className="text-blue-300">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                [...Array(5)].map((_, i) => (
                  <TableRow key={i} className="border-blue-700">
                    <TableCell><Skeleton className="h-4 w-32 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-20 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-32 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-20 bg-blue-700/50" /></TableCell>
                  </TableRow>
                ))
              ) : notifications.length === 0 ? (
                <TableRow className="border-blue-700">
                  <TableCell colSpan={6} className="text-center py-8 text-blue-300">
                    Nenhuma notificação encontrada
                  </TableCell>
                </TableRow>
              ) : (
                notifications.map((notification) => (
                  <TableRow key={notification.id} className="border-blue-700 hover:bg-blue-800/30">
                    <TableCell className="font-medium text-white">{notification.title}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-blue-300 border-blue-500">
                        {notification.type}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-blue-200 text-sm">
                      {notification.recipient_email || notification.recipient_phone || "-"}
                    </TableCell>
                    <TableCell className="text-blue-200 text-sm">
                      {notification.send_via?.join(", ") || "-"}
                    </TableCell>
                    <TableCell className="text-blue-200 text-sm">
                      {notification.scheduled_date ? format(new Date(notification.scheduled_date), "dd/MM/yyyy HH:mm") : "-"}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={
                        notification.status === "enviada" ? "text-green-300 border-green-500 bg-green-900/30" :
                        notification.status === "erro" ? "text-red-300 border-red-500 bg-red-900/30" :
                        "text-yellow-300 border-yellow-500 bg-yellow-900/30"
                      }>
                        {notification.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}