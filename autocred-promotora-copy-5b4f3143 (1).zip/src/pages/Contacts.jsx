import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Users, Pencil, Search } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

export default function Contacts() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingContact, setEditingContact] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");

  const queryClient = useQueryClient();

  const { data: contacts = [], isLoading } = useQuery({
    queryKey: ["contacts"],
    queryFn: () => base44.entities.Client.list("-created_date"),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Client.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
      setShowDialog(false);
      setEditingContact(null);
      toast.success("Cadastro realizado com sucesso!");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Client.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
      setShowDialog(false);
      setEditingContact(null);
      toast.success("Cadastro atualizado com sucesso!");
    },
  });

  const filteredContacts = contacts.filter((c) => {
    const matchesSearch =
      c.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.cpf_cnpj?.includes(searchTerm) ||
      c.email?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = 
      filterType === "all" || 
      c.type === filterType ||
      (filterType === "cliente" && (c.type === "cliente" || c.type === "ambos")) ||
      (filterType === "fornecedor" && (c.type === "fornecedor" || c.type === "ambos"));
    
    return matchesSearch && matchesType;
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    const data = {
      name: formData.get("name"),
      type: formData.get("type"),
      cpf_cnpj: formData.get("cpf_cnpj"),
      email: formData.get("email"),
      phone: formData.get("phone"),
      whatsapp: formData.get("whatsapp"),
      address: formData.get("address"),
      city: formData.get("city"),
      state: formData.get("state"),
      zip_code: formData.get("zip_code"),
      bank: formData.get("bank"),
      agency: formData.get("agency"),
      account: formData.get("account"),
      pix_key: formData.get("pix_key"),
      category: formData.get("category"),
      status: formData.get("status"),
      notes: formData.get("notes"),
    };

    if (editingContact) {
      updateMutation.mutate({ id: editingContact.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white drop-shadow-lg">Clientes e Fornecedores</h1>
          <p className="text-blue-200 mt-1">Cadastro unificado de contatos</p>
        </div>
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingContact(null)} className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600 shadow-lg">
              <Plus className="w-4 h-4 mr-2" />
              Novo Cadastro
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto bg-blue-900 border-blue-700 text-white">
            <DialogHeader>
              <DialogTitle className="text-white">{editingContact ? "Editar Cadastro" : "Novo Cadastro"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Nome/Razão Social*</Label>
                  <Input name="name" defaultValue={editingContact?.name} required className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
                <div>
                  <Label className="text-blue-200">Tipo*</Label>
                  <Select name="type" defaultValue={editingContact?.type || "cliente"} required>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      <SelectItem value="cliente">Cliente</SelectItem>
                      <SelectItem value="fornecedor">Fornecedor</SelectItem>
                      <SelectItem value="ambos">Cliente e Fornecedor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-blue-200">CPF/CNPJ</Label>
                  <Input name="cpf_cnpj" defaultValue={editingContact?.cpf_cnpj} placeholder="000.000.000-00" className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
                <div>
                  <Label className="text-blue-200">Categoria</Label>
                  <Input name="category" defaultValue={editingContact?.category} placeholder="Ex: Serviços" className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
                <div>
                  <Label className="text-blue-200">Status</Label>
                  <Select name="status" defaultValue={editingContact?.status || "ativo"}>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="inativo">Inativo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Email</Label>
                  <Input name="email" type="email" defaultValue={editingContact?.email} className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
                <div>
                  <Label className="text-blue-200">Telefone</Label>
                  <Input name="phone" defaultValue={editingContact?.phone} placeholder="(00) 00000-0000" className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
              </div>

              <div>
                <Label className="text-blue-200">WhatsApp</Label>
                <Input name="whatsapp" defaultValue={editingContact?.whatsapp} placeholder="(00) 00000-0000" className="bg-blue-950/50 border-blue-700 text-white" />
              </div>

              <div>
                <Label className="text-blue-200">Endereço</Label>
                <Input name="address" defaultValue={editingContact?.address} className="bg-blue-950/50 border-blue-700 text-white" />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-blue-200">Cidade</Label>
                  <Input name="city" defaultValue={editingContact?.city} className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
                <div>
                  <Label className="text-blue-200">Estado</Label>
                  <Input name="state" defaultValue={editingContact?.state} placeholder="UF" className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
                <div>
                  <Label className="text-blue-200">CEP</Label>
                  <Input name="zip_code" defaultValue={editingContact?.zip_code} placeholder="00000-000" className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-blue-200">Banco</Label>
                  <Input name="bank" defaultValue={editingContact?.bank} className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
                <div>
                  <Label className="text-blue-200">Agência</Label>
                  <Input name="agency" defaultValue={editingContact?.agency} className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
                <div>
                  <Label className="text-blue-200">Conta</Label>
                  <Input name="account" defaultValue={editingContact?.account} className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
              </div>

              <div>
                <Label className="text-blue-200">Chave PIX</Label>
                <Input name="pix_key" defaultValue={editingContact?.pix_key} placeholder="CPF, CNPJ, Email ou Telefone" className="bg-blue-950/50 border-blue-700 text-white" />
              </div>

              <div>
                <Label className="text-blue-200">Observações</Label>
                <Textarea name="notes" defaultValue={editingContact?.notes} rows={3} className="bg-blue-950/50 border-blue-700 text-white" />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-blue-700">
                <Button type="button" variant="outline" onClick={() => setShowDialog(false)} className="border-blue-700 text-blue-200 hover:bg-blue-800">
                  Cancelar
                </Button>
                <Button type="submit" className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600">
                  {editingContact ? "Atualizar" : "Cadastrar"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <div className="flex flex-col md:flex-row gap-4">
            <Tabs value={filterType} onValueChange={setFilterType} className="w-full">
              <TabsList className="grid w-full md:w-auto md:inline-grid grid-cols-4 h-auto bg-blue-950/50">
                <TabsTrigger value="all" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white">Todos</TabsTrigger>
                <TabsTrigger value="cliente" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white">Clientes</TabsTrigger>
                <TabsTrigger value="fornecedor" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white">Fornecedores</TabsTrigger>
                <TabsTrigger value="ambos" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white">Ambos</TabsTrigger>
              </TabsList>
            </Tabs>
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-400 w-5 h-5" />
              <Input
                placeholder="Buscar por nome, CPF/CNPJ ou email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="bg-blue-950/50 border-blue-700 hover:bg-blue-950/70">
                <TableHead className="text-blue-300">Nome</TableHead>
                <TableHead className="text-blue-300">Tipo</TableHead>
                <TableHead className="text-blue-300">CPF/CNPJ</TableHead>
                <TableHead className="text-blue-300">Telefone</TableHead>
                <TableHead className="text-blue-300">Email</TableHead>
                <TableHead className="text-blue-300">Status</TableHead>
                <TableHead className="text-right text-blue-300">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                [...Array(5)].map((_, i) => (
                  <TableRow key={i} className="border-blue-700">
                    <TableCell><Skeleton className="h-4 w-32 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-28 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-32 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-16 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-8 w-20 bg-blue-700/50" /></TableCell>
                  </TableRow>
                ))
              ) : filteredContacts.length === 0 ? (
                <TableRow className="border-blue-700">
                  <TableCell colSpan={7} className="text-center py-8 text-blue-300">
                    Nenhum cadastro encontrado
                  </TableCell>
                </TableRow>
              ) : (
                filteredContacts.map((contact) => (
                  <TableRow key={contact.id} className="border-blue-700 hover:bg-blue-800/30">
                    <TableCell className="font-medium text-white">{contact.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={
                        contact.type === "cliente" ? "text-green-300 border-green-500 bg-green-900/30" :
                        contact.type === "fornecedor" ? "text-orange-300 border-orange-500 bg-orange-900/30" :
                        "text-purple-300 border-purple-500 bg-purple-900/30"
                      }>
                        {contact.type === "ambos" ? "Ambos" : contact.type.charAt(0).toUpperCase() + contact.type.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-blue-200">{contact.cpf_cnpj || "-"}</TableCell>
                    <TableCell className="text-blue-200">{contact.phone || "-"}</TableCell>
                    <TableCell className="text-blue-200">{contact.email || "-"}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={contact.status === "ativo" ? "text-green-300 border-green-500" : "text-gray-400 border-gray-500"}>
                        {contact.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setEditingContact(contact);
                          setShowDialog(true);
                        }}
                        className="text-blue-300 hover:text-white hover:bg-blue-700"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}