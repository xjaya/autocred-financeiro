import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Tag, Pencil, Search } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

export default function Categories() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const queryClient = useQueryClient();

  const { data: categories = [], isLoading } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list("-created_date"),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Category.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["categories"] });
      setShowDialog(false);
      setEditingCategory(null);
      toast.success("Categoria cadastrada com sucesso!");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Category.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["categories"] });
      setShowDialog(false);
      setEditingCategory(null);
      toast.success("Categoria atualizada com sucesso!");
    },
  });

  const filteredCategories = categories.filter((c) =>
    c.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.type?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    const data = {
      name: formData.get("name"),
      type: formData.get("type"),
      parent_category: formData.get("parent_category"),
      description: formData.get("description"),
      status: formData.get("status"),
    };

    if (editingCategory) {
      updateMutation.mutate({ id: editingCategory.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white drop-shadow-lg">Categorias</h1>
          <p className="text-blue-200 mt-1">Organize receitas e despesas por categorias</p>
        </div>
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingCategory(null)} className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600 shadow-lg">
              <Plus className="w-4 h-4 mr-2" />
              Nova Categoria
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl bg-blue-900 border-blue-700 text-white">
            <DialogHeader>
              <DialogTitle className="text-white">{editingCategory ? "Editar Categoria" : "Nova Categoria"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Nome*</Label>
                  <Input name="name" defaultValue={editingCategory?.name} required className="bg-blue-950/50 border-blue-700 text-white" />
                </div>
                <div>
                  <Label className="text-blue-200">Tipo*</Label>
                  <Select name="type" defaultValue={editingCategory?.type || "despesa"} required>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      <SelectItem value="receita">Receita</SelectItem>
                      <SelectItem value="despesa">Despesa</SelectItem>
                      <SelectItem value="ambos">Ambos</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Categoria Pai (Subcategoria)</Label>
                  <Select name="parent_category" defaultValue={editingCategory?.parent_category}>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue placeholder="Selecione (opcional)" />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      {categories.filter(c => !c.parent_category).map((cat) => (
                        <SelectItem key={cat.id} value={cat.name}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-blue-200">Status</Label>
                  <Select name="status" defaultValue={editingCategory?.status || "ativo"}>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="inativo">Inativo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label className="text-blue-200">Descrição</Label>
                <Textarea name="description" defaultValue={editingCategory?.description} rows={3} className="bg-blue-950/50 border-blue-700 text-white" />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-blue-700">
                <Button type="button" variant="outline" onClick={() => setShowDialog(false)} className="border-blue-700 text-blue-200 hover:bg-blue-800">
                  Cancelar
                </Button>
                <Button type="submit" className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600">
                  {editingCategory ? "Atualizar" : "Cadastrar"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-400 w-5 h-5" />
            <Input
              placeholder="Buscar categorias..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
            />
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="bg-blue-950/50 border-blue-700 hover:bg-blue-950/70">
                <TableHead className="text-blue-300">Nome</TableHead>
                <TableHead className="text-blue-300">Tipo</TableHead>
                <TableHead className="text-blue-300">Categoria Pai</TableHead>
                <TableHead className="text-blue-300">Descrição</TableHead>
                <TableHead className="text-blue-300">Status</TableHead>
                <TableHead className="text-right text-blue-300">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                [...Array(5)].map((_, i) => (
                  <TableRow key={i} className="border-blue-700">
                    <TableCell><Skeleton className="h-4 w-32 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-32 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-20 bg-blue-700/50" /></TableCell>
                    <TableCell><Skeleton className="h-8 w-20 bg-blue-700/50" /></TableCell>
                  </TableRow>
                ))
              ) : filteredCategories.length === 0 ? (
                <TableRow className="border-blue-700">
                  <TableCell colSpan={6} className="text-center py-8 text-blue-300">
                    Nenhuma categoria encontrada
                  </TableCell>
                </TableRow>
              ) : (
                filteredCategories.map((category) => (
                  <TableRow key={category.id} className="border-blue-700 hover:bg-blue-800/30">
                    <TableCell className="font-medium text-white">{category.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={
                        category.type === "receita" ? "text-green-300 border-green-500 bg-green-900/30" :
                        category.type === "despesa" ? "text-red-300 border-red-500 bg-red-900/30" :
                        "text-purple-300 border-purple-500 bg-purple-900/30"
                      }>
                        {category.type === "ambos" ? "Ambos" : category.type.charAt(0).toUpperCase() + category.type.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-blue-200">{category.parent_category || "-"}</TableCell>
                    <TableCell className="text-blue-200 max-w-xs truncate">{category.description || "-"}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={category.status === "ativo" ? "text-green-300 border-green-500" : "text-gray-400 border-gray-500"}>
                        {category.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setEditingCategory(category);
                          setShowDialog(true);
                        }}
                        className="text-blue-300 hover:text-white hover:bg-blue-700"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}