
import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import {
  LayoutDashboard,
  TrendingUp,
  FileText,
  Users,
  Building2,
  CreditCard,
  Bell,
  Settings,
  BarChart3,
  Wallet,
  PieChart,
  BookOpen,
  LogOut,
  ChevronDown,
  Upload,
  FolderOpen,
  Tag,
  Landmark,
  Boxes,
  Target,
  Sparkles,
  RefreshCw,
  Brain,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
  },
  {
    title: "Lançamentos",
    url: createPageUrl("Transactions"),
    icon: CreditCard,
  },
  {
    title: "Alertas Financeiros",
    url: createPageUrl("FinancialAlerts"),
    icon: Bell,
  },
  {
    title: "Importar Extrato",
    url: createPageUrl("ImportExtractPage"),
    icon: Upload,
  },
  {
    title: "Treinar IA",
    url: createPageUrl("AITraining"),
    icon: Sparkles,
  },
  {
    title: "Gerenciar IA",
    url: createPageUrl("AIManagement"),
    icon: Building2,
  },
  {
    title: "Transferências",
    url: createPageUrl("Transfers"),
    icon: FolderOpen,
  },
  {
    title: "Metas Financeiras",
    url: createPageUrl("Goals"),
    icon: Target,
  },
  {
    title: "Previsões com IA",
    url: createPageUrl("FinancialPredictions"),
    icon: Brain,
  },
  ];

const cadastrosItems = [
  {
    title: "Clientes/Fornecedores",
    url: createPageUrl("Contacts"),
    icon: Users,
  },
  {
    title: "Categorias",
    url: createPageUrl("Categories"),
    icon: Tag,
  },
  {
    title: "Centro de Custos",
    url: createPageUrl("CostCenters"),
    icon: Boxes,
  },
  {
    title: "Contas Bancárias",
    url: createPageUrl("BankAccounts"),
    icon: Landmark,
  },
];

const financialReports = [
  {
    title: "Relatórios Financeiros",
    url: createPageUrl("FinancialReports"),
    icon: FileText,
  },
  {
    title: "Assessor Financeiro IA",
    url: createPageUrl("AIFinancialAdvisor"),
    icon: Sparkles,
  },
  {
    title: "Relatórios Avançados",
    url: createPageUrl("FinancialReportsAdvanced"),
    icon: Sparkles,
  },
  {
    title: "Relatórios",
    url: createPageUrl("Reports"),
    icon: FileText,
  },
  {
    title: "Relatórios Personalizados",
    url: createPageUrl("CustomReports"),
    icon: BarChart3,
  },
  {
    title: "DRE",
    url: createPageUrl("DRE"),
    icon: TrendingUp,
  },
  {
    title: "Balanço Patrimonial",
    url: createPageUrl("BalanceSheet"),
    icon: PieChart,
  },
  {
    title: "Fluxo de Caixa",
    url: createPageUrl("CashFlow"),
    icon: Wallet,
  },
  {
    title: "Análise Financeira",
    url: createPageUrl("FinancialAnalysis"),
    icon: BookOpen,
  },
];

const integrationItems = [
  {
    title: "Integração Bancária",
    url: createPageUrl("BankIntegrationPage"),
    icon: Landmark,
  },
  {
    title: "Backup e Restauração",
    url: createPageUrl("BackupRestore"),
    icon: Settings,
  },
  ];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [companySettings, setCompanySettings] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const settings = await base44.entities.CompanySettings.list();
        const settingsData = settings && settings.length > 0 ? settings[0] : null;
        
        setCompanySettings(settingsData);

        // Verificar se autenticação é obrigatória
        if (settingsData?.require_auth && currentPageName !== "Login") {
          const isAuthenticated = localStorage.getItem("app_authenticated") === "true";
          const authTime = localStorage.getItem("app_auth_time");
          const sessionTimeout = (settingsData.session_timeout || 480) * 60 * 1000; // Converter para ms

          if (!isAuthenticated || (authTime && (new Date().getTime() - parseInt(authTime)) > sessionTimeout)) {
            localStorage.removeItem("app_authenticated");
            localStorage.removeItem("app_auth_time");
            window.location.href = "/login?next=" + window.location.pathname;
            return;
          }
        }

        // Aplicar cores personalizadas
        if (settingsData?.primary_color) {
          document.documentElement.style.setProperty('--primary', settingsData.primary_color);
        }
        if (settingsData?.secondary_color) {
          document.documentElement.style.setProperty('--secondary', settingsData.secondary_color);
        }
        if (settingsData?.background_color) {
          document.body.style.background = settingsData.background_color;
        }

        setAuthChecked(true);
      } catch (error) {
        console.error("Error checking auth:", error);
        setAuthChecked(true);
      }
    };

    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };

    checkAuth();
    loadUser();
  }, [currentPageName, navigate]);

  const handleLogout = async () => {
    localStorage.removeItem("app_authenticated");
    localStorage.removeItem("app_auth_time");
    
    if (companySettings?.require_auth) {
      window.location.href = "/login";
    } else {
      await base44.auth.logout();
    }
  };

  const logoUrl = companySettings?.logo_url || null;
  const companyName = companySettings?.company_name || "AUTOCRED PROMOTORA";

  // Mostrar loading enquanto verifica autenticação
  if (!authChecked) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#001F3F' }}>
        <div className="text-center">
          <RefreshCw className="w-12 h-12 text-blue-400 animate-spin mx-auto mb-4" />
          <p className="text-blue-200">Carregando...</p>
        </div>
      </div>
    );
  }

  // Se estiver na página de login, não mostrar layout
  if (currentPageName === "Login") {
    return children;
  }

  return (
    <SidebarProvider>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700;900&display=swap');

        :root {
          --primary: #0047AB;
          --primary-light: #1E5BC6;
          --accent: #00FF87;
        }

        * {
          box-sizing: border-box;
        }

        html, body, #root {
          background: #001F3F !important;
          min-height: 100vh;
        }

        body {
          background: #001F3F !important;
          min-height: 100vh;
        }

        [data-sidebar] {
          background: #001F3F !important;
        }

        [data-sidebar-content] {
          background: #001F3F !important;
        }

        aside {
          background: #001F3F !important;
        }

        /* FONTE ELEGANTE 3D */
        [data-sidebar] * {
          font-family: 'Orbitron', sans-serif !important;
          font-weight: 600;
          letter-spacing: 0.5px;
        }

        [data-sidebar] h2 {
          font-weight: 900;
          text-shadow: 2px 2px 4px rgba(0,0,0,0.5), 0 0 10px rgba(59, 130, 246, 0.3);
        }

        [data-sidebar] a, [data-sidebar] button {
          font-weight: 600;
          text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
        }
      `}</style>
      <div className="min-h-screen flex w-full" style={{ background: '#001F3F' }}>
        <Sidebar className="border-r border-blue-700/50 shadow-2xl" style={{ background: '#001F3F' }}>
          <SidebarHeader className="border-b border-blue-700/50 p-6" style={{ background: '#001F3F' }}>
            <div className="flex items-center gap-3">
              {logoUrl ? (
                <img src={logoUrl} alt={companyName} className="h-12 w-auto object-contain" />
              ) : (
                <div className="h-12 w-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                  <CreditCard className="w-7 h-7 text-white" />
                </div>
              )}
              <div>
                <h2 className="font-bold text-white text-base leading-tight">{companyName}</h2>
                <p className="text-xs text-blue-200">Gestão Financeira</p>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent className="p-3">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-blue-300 uppercase tracking-wider px-3 py-2">
                Menu Principal
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        className={`hover:bg-blue-800/50 hover:text-white transition-all duration-200 rounded-xl mb-1.5 ${
                          location.pathname === item.url
                            ? "bg-gradient-to-r from-blue-600 to-blue-500 text-white font-semibold shadow-lg"
                            : "text-blue-200"
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                          <item.icon className="w-5 h-5" />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-blue-300 uppercase tracking-wider px-3 py-2">
                Cadastros
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {cadastrosItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        className={`hover:bg-blue-800/50 hover:text-white transition-all duration-200 rounded-xl mb-1.5 ${
                          location.pathname === item.url
                            ? "bg-gradient-to-r from-blue-600 to-blue-500 text-white font-semibold shadow-lg"
                            : "text-blue-200"
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                          <item.icon className="w-5 h-5" />
                          <span className="text-sm">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-blue-300 uppercase tracking-wider px-3 py-2">
                Relatórios
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {financialReports.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        className={`hover:bg-blue-800/50 hover:text-white transition-all duration-200 rounded-xl mb-1.5 ${
                          location.pathname === item.url
                            ? "bg-gradient-to-r from-blue-600 to-blue-500 text-white font-semibold shadow-lg"
                            : "text-blue-200"
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                          <item.icon className="w-5 h-5" />
                          <span className="text-sm">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-blue-300 uppercase tracking-wider px-3 py-2">
                Integrações
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {integrationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        className={`hover:bg-blue-800/50 hover:text-white transition-all duration-200 rounded-xl mb-1.5 ${
                          location.pathname === item.url
                            ? "bg-gradient-to-r from-blue-600 to-blue-500 text-white font-semibold shadow-lg"
                            : "text-blue-200"
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                          <item.icon className="w-5 h-5" />
                          <span className="text-sm">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                      asChild
                      className={`hover:bg-blue-800/50 hover:text-white transition-all duration-200 rounded-xl mb-1.5 ${
                        location.pathname === createPageUrl("Notifications")
                          ? "bg-gradient-to-r from-blue-600 to-blue-500 text-white font-semibold shadow-lg"
                          : "text-blue-200"
                      }`}
                    >
                      <Link
                        to={createPageUrl("Notifications")}
                        className="flex items-center gap-3 px-4 py-3"
                      >
                        <Bell className="w-5 h-5" />
                        <span>Notificações</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                      asChild
                      className={`hover:bg-blue-800/50 hover:text-white transition-all duration-200 rounded-xl ${
                        location.pathname === createPageUrl("Settings")
                          ? "bg-gradient-to-r from-blue-600 to-blue-500 text-white font-semibold shadow-lg"
                          : "text-blue-200"
                      }`}
                    >
                      <Link
                        to={createPageUrl("Settings")}
                        className="flex items-center gap-3 px-4 py-3"
                      >
                        <Settings className="w-5 h-5" />
                        <span>Configurações</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-blue-700/50 p-4">
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center gap-3 w-full hover:bg-blue-800/50 p-3 rounded-xl transition-all">
                <Avatar className="h-10 w-10 ring-2 ring-blue-400">
                  <AvatarFallback className="bg-gradient-to-br from-blue-500 to-blue-700 text-white font-bold">
                    {user?.full_name?.charAt(0) || "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 text-left min-w-0">
                  <p className="font-semibold text-white text-sm truncate">
                    {user?.full_name || "Usuário"}
                  </p>
                  <p className="text-xs text-blue-300 truncate">{user?.email}</p>
                </div>
                <ChevronDown className="w-4 h-4 text-blue-300" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-blue-900 border-blue-700">
                <DropdownMenuItem onClick={handleLogout} className="text-red-400 cursor-pointer hover:bg-blue-800 hover:text-red-300">
                  <LogOut className="w-4 h-4 mr-2" />
                  Sair
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col overflow-hidden">
          <header className="border-b border-blue-700/50 px-6 py-4 lg:hidden sticky top-0 z-40 shadow-xl" style={{ background: '#001F3F' }}>
            <div className="flex items-center justify-between">
              <SidebarTrigger className="hover:bg-blue-800/50 p-2 rounded-lg transition-colors text-white" />
              <div className="flex items-center gap-2">
                {logoUrl ? (
                  <img src={logoUrl} alt={companyName} className="h-8 w-auto object-contain" />
                ) : (
                  <div className="h-8 w-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-white" />
                  </div>
                )}
                <h1 className="text-lg font-bold text-white">{companyName}</h1>
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-auto" style={{ background: '#001F3F' }}>
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
