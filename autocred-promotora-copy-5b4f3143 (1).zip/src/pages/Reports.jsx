import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  TrendingUp,
  PieChart,
  Wallet,
  BookOpen,
  FileText,
  Calendar,
  DollarSign,
  BarChart3,
} from "lucide-react";

const reports = [
  {
    title: "DRE - Demonstração do Resultado",
    description: "Análise completa de receitas, despesas e lucro operacional",
    icon: TrendingUp,
    url: createPageUrl("DRE"),
    color: "from-green-500 to-emerald-600",
    iconColor: "text-green-400",
  },
  {
    title: "Balanço Patrimonial",
    description: "Visão do patrimônio da empresa: ativos, passivos e patrimônio líquido",
    icon: PieChart,
    url: createPageUrl("BalanceSheet"),
    color: "from-blue-500 to-blue-600",
    iconColor: "text-blue-400",
  },
  {
    title: "Fluxo de Caixa",
    description: "Entradas e saídas de dinheiro do negócio",
    icon: Wallet,
    url: createPageUrl("CashFlow"),
    color: "from-purple-500 to-purple-600",
    iconColor: "text-purple-400",
  },
  {
    title: "Análise Financeira Completa",
    description: "Indicadores financeiros e análise detalhada com IA",
    icon: BookOpen,
    url: createPageUrl("FinancialAnalysis"),
    color: "from-orange-500 to-orange-600",
    iconColor: "text-orange-400",
  },
];

export default function Reports() {
  return (
    <div className="p-4 md:p-8 space-y-8">
      <div>
        <h1 className="text-4xl font-bold text-white drop-shadow-lg">Relatórios Financeiros</h1>
        <p className="text-blue-200 mt-2">
          Acesse relatórios completos e análises detalhadas do seu negócio
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {reports.map((report) => (
          <Link to={report.url} key={report.title}>
            <Card className="h-full border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm hover:shadow-2xl hover:shadow-blue-500/30 transition-all duration-300 group cursor-pointer">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className={`p-4 rounded-xl bg-gradient-to-br ${report.color} shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    <report.icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-xl text-white group-hover:text-blue-300 transition-colors">
                      {report.title}
                    </CardTitle>
                    <p className="text-sm text-blue-300 mt-2">{report.description}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Button 
                  variant="outline" 
                  className="w-full border-blue-600 text-blue-300 hover:bg-blue-700 hover:text-white group-hover:border-blue-400 transition-all"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Acessar Relatório
                </Button>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-blue-400" />
            Sobre os Relatórios
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-blue-200">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-blue-700/50 rounded-lg mt-0.5">
              <DollarSign className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h3 className="font-semibold text-white">Análise com IA</h3>
              <p className="text-sm">
                Todos os relatórios incluem análise inteligente com IA, fornecendo insights e
                sugestões estratégicas personalizadas.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2 bg-blue-700/50 rounded-lg mt-0.5">
              <Calendar className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h3 className="font-semibold text-white">Período Personalizável</h3>
              <p className="text-sm">
                Escolha o período de análise que desejar para ter uma visão completa da sua
                operação financeira.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2 bg-blue-700/50 rounded-lg mt-0.5">
              <FileText className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h3 className="font-semibold text-white">Exportação de Dados</h3>
              <p className="text-sm">
                Exporte seus relatórios em PDF para compartilhar com contadores, sócios ou investidores.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}