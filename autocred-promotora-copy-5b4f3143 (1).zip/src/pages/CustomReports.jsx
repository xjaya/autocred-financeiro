import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FileText, Download, Sparkles, Calendar, Filter, TrendingUp, TrendingDown, MessageCircle } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format, startOfMonth, endOfMonth, subMonths } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";
import AIAssistant from "../components/AIAssistant";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area,
} from "recharts";

export default function CustomReports() {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [generating, setGenerating] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState(null);
  
  const [filterType, setFilterType] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterCostCenter, setFilterCostCenter] = useState("all");
  const [filterBankAccount, setFilterBankAccount] = useState("all");
  const [filterContact, setFilterContact] = useState("all");
  
  const [selectedFields, setSelectedFields] = useState({
    due_date: true,
    payment_date: true,
    description: true,
    type: true,
    category: true,
    subcategory: true,
    cost_center: true,
    amount: true,
    status: true,
    supplier_name: true,
    client_name: true,
    payment_method: true,
    bank_account: true,
    document_number: true,
    invoice_number: true,
    installment: true,
    notes: true,
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list("-due_date"),
    initialData: [],
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts"],
    queryFn: () => base44.entities.Client.list(),
    initialData: [],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list(),
    initialData: [],
  });

  const { data: costCenters = [] } = useQuery({
    queryKey: ["costCenters"],
    queryFn: () => base44.entities.CostCenter.list(),
    initialData: [],
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ["bankAccounts"],
    queryFn: () => base44.entities.BankAccount.list(),
    initialData: [],
  });

  const filteredTransactions = transactions.filter((t) => {
    if (startDate && new Date(t.due_date) < new Date(startDate)) return false;
    if (endDate && new Date(t.due_date) > new Date(endDate)) return false;
    if (filterType !== "all" && t.type !== filterType) return false;
    if (filterStatus !== "all" && t.status !== filterStatus) return false;
    if (filterCategory !== "all" && t.category !== filterCategory) return false;
    if (filterCostCenter !== "all" && t.cost_center !== filterCostCenter) return false;
    if (filterBankAccount !== "all" && t.bank_account !== filterBankAccount) return false;
    if (filterContact !== "all") {
      const contactMatch = t.supplier_name === filterContact || t.client_name === filterContact;
      if (!contactMatch) return false;
    }
    return true;
  });

  const toggleField = (field) => {
    setSelectedFields((prev) => ({ ...prev, [field]: !prev[field] }));
  };

  const generateAIAnalysis = async () => {
    setGenerating(true);
    try {
      const totalReceitas = filteredTransactions
        .filter(t => t.type === "receita" && t.status === "pago")
        .reduce((sum, t) => sum + t.amount, 0);
      
      const totalDespesas = filteredTransactions
        .filter(t => t.type === "despesa" && t.status === "pago")
        .reduce((sum, t) => sum + t.amount, 0);

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analise este relatório financeiro personalizado:

PERÍODO: ${startDate || "início"} até ${endDate || "hoje"}
TOTAL DE TRANSAÇÕES: ${filteredTransactions.length}
RECEITAS: R$ ${totalReceitas.toFixed(2)}
DESPESAS: R$ ${totalDespesas.toFixed(2)}
SALDO: R$ ${(totalReceitas - totalDespesas).toFixed(2)}

Forneça uma análise DETALHADA:
1. Resumo executivo do período
2. Principais insights financeiros
3. Tendências observadas
4. Recomendações estratégicas
5. Alertas importantes
6. Análise comparativa (se aplicável)`,
      });

      setAiAnalysis(result);
    } catch (error) {
      console.error("Erro ao gerar análise:", error);
    }
    setGenerating(false);
  };

  const exportToExcelModern = () => {
    const exportData = filteredTransactions.map(t => ({
      'Data': format(new Date(t.due_date), "dd/MM/yyyy"),
      'Descrição': t.description,
      'Tipo': t.type === 'receita' ? 'Receita' : 'Despesa',
      'Categoria': t.category || '-',
      'Centro de Custo': t.cost_center || '-',
      'Valor': t.amount,
      'Status': t.status,
      'Banco': t.bank_account || '-'
    }));
    
    import("../components/reports/ReportExporter").then(({ exportToExcel }) => {
      exportToExcel(exportData, `relatorio-financeiro-${format(new Date(), "dd-MM-yyyy")}`);
    });
  };

  const exportToPDFModern = () => {
    const exportData = filteredTransactions.map(t => ({
      'Data': format(new Date(t.due_date), "dd/MM/yyyy"),
      'Descrição': t.description,
      'Tipo': t.type === 'receita' ? 'Receita' : 'Despesa',
      'Categoria': t.category || '-',
      'Centro Custo': t.cost_center || '-',
      'Valor': t.amount,
      'Status': t.status
    }));
    
    const summary = {
      receitas: totalReceitas,
      despesas: totalDespesas,
      saldo: totalReceitas - totalDespesas
    };
    
    import("../components/reports/ReportExporter").then(({ exportToPDF }) => {
      exportToPDF('Relatório Financeiro Personalizado', exportData, summary);
    });
  };

  const sendWhatsAppReport = async () => {
    try {
      const settingsList = await base44.entities.CompanySettings.list();
      const settings = settingsList[0];
      
      if (!settings?.whatsapp_number) {
        toast.error("Configure o número WhatsApp em Configurações primeiro");
        return;
      }

      const summary = {
        receitas: totalReceitas,
        despesas: totalDespesas,
        saldo: totalReceitas - totalDespesas
      };

      const { sendWhatsAppReport } = await import("../components/whatsapp/WhatsAppSender");
      await sendWhatsAppReport(settings.whatsapp_number, "Relatório Personalizado", summary);
    } catch (error) {
      console.error("Erro ao enviar WhatsApp:", error);
      toast.error("Erro ao enviar WhatsApp");
    }
  };

  const exportToCSV = () => {
    const csvRows = [];
    
    // Header
    const headers = Object.entries(selectedFields)
      .filter(([_, selected]) => selected)
      .map(([field]) => {
        const labels = {
          due_date: "Data Vencimento",
          payment_date: "Data Pagamento",
          description: "Descrição",
          type: "Tipo",
          category: "Categoria",
          subcategory: "Subcategoria",
          cost_center: "Centro de Custo",
          amount: "Valor",
          status: "Status",
          supplier_name: "Fornecedor",
          client_name: "Cliente",
          payment_method: "Forma Pagamento",
          bank_account: "Conta Bancária",
          document_number: "Nº Documento",
          invoice_number: "Nº NF",
          installment: "Parcela",
          notes: "Observações"
        };
        return labels[field] || field;
      });
    csvRows.push(headers.join(","));

    // Data
    filteredTransactions.forEach(t => {
      const row = [];
      if (selectedFields.due_date) row.push(format(new Date(t.due_date), "dd/MM/yyyy"));
      if (selectedFields.payment_date) row.push(t.payment_date ? format(new Date(t.payment_date), "dd/MM/yyyy") : "-");
      if (selectedFields.description) row.push(`"${t.description}"`);
      if (selectedFields.type) row.push(t.type === "receita" ? "Receita" : "Despesa");
      if (selectedFields.category) row.push(t.category || "-");
      if (selectedFields.subcategory) row.push(t.subcategory || "-");
      if (selectedFields.cost_center) row.push(t.cost_center || "-");
      if (selectedFields.amount) row.push(t.amount.toFixed(2));
      if (selectedFields.status) row.push(t.status);
      if (selectedFields.supplier_name) row.push(t.supplier_name || "-");
      if (selectedFields.client_name) row.push(t.client_name || "-");
      if (selectedFields.payment_method) row.push(t.payment_method || "-");
      if (selectedFields.bank_account) row.push(t.bank_account || "-");
      if (selectedFields.document_number) row.push(t.document_number || "-");
      if (selectedFields.invoice_number) row.push(t.invoice_number || "-");
      if (selectedFields.installment) row.push(t.installment || "-");
      if (selectedFields.notes) row.push(`"${t.notes || "-"}"`);
      csvRows.push(row.join(","));
    });

    const csvContent = csvRows.join("\n");
    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `relatorio-${startDate || "inicio"}-${endDate || "hoje"}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportToPDF = () => {
    const doc = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Relatório Financeiro</title>
  <style>
    @page { size: A4; margin: 20mm; }
    body {
      font-family: 'Arial', sans-serif;
      color: #1a1a1a;
      line-height: 1.6;
    }
    .header {
      background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
      color: white;
      padding: 30px;
      border-radius: 10px;
      margin-bottom: 30px;
    }
    .header h1 {
      margin: 0;
      font-size: 28px;
      font-weight: bold;
    }
    .header p {
      margin: 5px 0 0 0;
      opacity: 0.9;
    }
    .summary {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 20px;
      margin-bottom: 30px;
    }
    .summary-card {
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
      padding: 20px;
      border-radius: 8px;
      border-left: 4px solid #3b82f6;
    }
    .summary-card h3 {
      margin: 0 0 10px 0;
      font-size: 14px;
      color: #64748b;
      text-transform: uppercase;
    }
    .summary-card p {
      margin: 0;
      font-size: 24px;
      font-weight: bold;
      color: #1e3a8a;
    }
    .receita { border-left-color: #10b981; background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%); }
    .receita p { color: #047857; }
    .despesa { border-left-color: #ef4444; background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); }
    .despesa p { color: #dc2626; }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      background: white;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      border-radius: 8px;
      overflow: hidden;
    }
    th {
      background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
      color: white;
      padding: 12px;
      text-align: left;
      font-weight: 600;
      font-size: 12px;
      text-transform: uppercase;
    }
    td {
      padding: 10px 12px;
      border-bottom: 1px solid #e5e7eb;
      font-size: 13px;
    }
    tr:hover {
      background-color: #f9fafb;
    }
    .receita-row { color: #047857; font-weight: 600; }
    .despesa-row { color: #dc2626; font-weight: 600; }
    .ai-section {
      background: linear-gradient(135deg, #faf5ff 0%, #f3e8ff 100%);
      padding: 25px;
      border-radius: 10px;
      margin-top: 30px;
      border-left: 4px solid #9333ea;
    }
    .ai-section h2 {
      color: #7e22ce;
      margin-top: 0;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .footer {
      margin-top: 40px;
      text-align: center;
      color: #64748b;
      font-size: 12px;
      padding-top: 20px;
      border-top: 2px solid #e5e7eb;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>📊 Relatório Financeiro Personalizado</h1>
    <p>Período: ${startDate ? format(new Date(startDate), "dd/MM/yyyy") : "Início"} até ${endDate ? format(new Date(endDate), "dd/MM/yyyy") : format(new Date(), "dd/MM/yyyy")}</p>
    <p>Gerado em: ${format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</p>
  </div>

  <div class="summary">
    <div class="summary-card receita">
      <h3>Receitas</h3>
      <p>R$ ${filteredTransactions.filter(t => t.type === "receita" && t.status === "pago").reduce((sum, t) => sum + t.amount, 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
    </div>
    <div class="summary-card despesa">
      <h3>Despesas</h3>
      <p>R$ ${filteredTransactions.filter(t => t.type === "despesa" && t.status === "pago").reduce((sum, t) => sum + t.amount, 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
    </div>
    <div class="summary-card">
      <h3>Saldo</h3>
      <p>R$ ${(filteredTransactions.filter(t => t.type === "receita" && t.status === "pago").reduce((sum, t) => sum + t.amount, 0) - filteredTransactions.filter(t => t.type === "despesa" && t.status === "pago").reduce((sum, t) => sum + t.amount, 0)).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        ${selectedFields.due_date ? '<th>Vencimento</th>' : ''}
        ${selectedFields.payment_date ? '<th>Pagamento</th>' : ''}
        ${selectedFields.description ? '<th>Descrição</th>' : ''}
        ${selectedFields.type ? '<th>Tipo</th>' : ''}
        ${selectedFields.category ? '<th>Categoria</th>' : ''}
        ${selectedFields.subcategory ? '<th>Subcategoria</th>' : ''}
        ${selectedFields.cost_center ? '<th>Centro Custo</th>' : ''}
        ${selectedFields.supplier_name ? '<th>Fornecedor</th>' : ''}
        ${selectedFields.client_name ? '<th>Cliente</th>' : ''}
        ${selectedFields.amount ? '<th>Valor</th>' : ''}
        ${selectedFields.status ? '<th>Status</th>' : ''}
        ${selectedFields.payment_method ? '<th>Pagamento</th>' : ''}
        ${selectedFields.bank_account ? '<th>Conta</th>' : ''}
        ${selectedFields.document_number ? '<th>Doc</th>' : ''}
        ${selectedFields.invoice_number ? '<th>NF</th>' : ''}
        ${selectedFields.installment ? '<th>Parcela</th>' : ''}
      </tr>
    </thead>
    <tbody>
      ${filteredTransactions.map(t => `
        <tr>
          ${selectedFields.due_date ? `<td>${format(new Date(t.due_date), "dd/MM/yyyy")}</td>` : ''}
          ${selectedFields.payment_date ? `<td>${t.payment_date ? format(new Date(t.payment_date), "dd/MM/yyyy") : "-"}</td>` : ''}
          ${selectedFields.description ? `<td>${t.description}</td>` : ''}
          ${selectedFields.type ? `<td>${t.type === "receita" ? "Receita" : "Despesa"}</td>` : ''}
          ${selectedFields.category ? `<td>${t.category || "-"}</td>` : ''}
          ${selectedFields.subcategory ? `<td>${t.subcategory || "-"}</td>` : ''}
          ${selectedFields.cost_center ? `<td>${t.cost_center || "-"}</td>` : ''}
          ${selectedFields.supplier_name ? `<td>${t.supplier_name || "-"}</td>` : ''}
          ${selectedFields.client_name ? `<td>${t.client_name || "-"}</td>` : ''}
          ${selectedFields.amount ? `<td class="${t.type}-row">R$ ${t.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</td>` : ''}
          ${selectedFields.status ? `<td>${t.status}</td>` : ''}
          ${selectedFields.payment_method ? `<td>${t.payment_method || "-"}</td>` : ''}
          ${selectedFields.bank_account ? `<td>${t.bank_account || "-"}</td>` : ''}
          ${selectedFields.document_number ? `<td>${t.document_number || "-"}</td>` : ''}
          ${selectedFields.invoice_number ? `<td>${t.invoice_number || "-"}</td>` : ''}
          ${selectedFields.installment ? `<td>${t.installment || "-"}</td>` : ''}
        </tr>
      `).join('')}
    </tbody>
  </table>

  ${aiAnalysis ? `
  <div class="ai-section">
    <h2>🤖 Análise Inteligente</h2>
    <p style="white-space: pre-wrap; color: #4c1d95; line-height: 1.8;">${aiAnalysis}</p>
  </div>
  ` : ''}

  <div class="footer">
    <p><strong>AUTOCRED PROMOTORA</strong> | Sistema de Gestão Financeira</p>
    <p>Relatório gerado automaticamente - Documento confidencial</p>
  </div>
</body>
</html>
    `;

    const blob = new Blob([doc], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `relatorio-${startDate || "inicio"}-${endDate || "hoje"}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const totalReceitas = filteredTransactions
    .filter(t => t.type === "receita" && t.status === "pago")
    .reduce((sum, t) => sum + t.amount, 0);

  const totalDespesas = filteredTransactions
    .filter(t => t.type === "despesa" && t.status === "pago")
    .reduce((sum, t) => sum + t.amount, 0);

  // DADOS PARA GRÁFICOS
  const COLORS = ["#10B981", "#EF4444", "#3B82F6", "#F59E0B", "#8B5CF6", "#EC4899"];

  // Despesas por categoria (Pie Chart)
  const expensesByCategory = filteredTransactions
    .filter(t => t.type === "despesa" && t.status === "pago")
    .reduce((acc, t) => {
      const cat = t.category || "Outros";
      acc[cat] = (acc[cat] || 0) + t.amount;
      return acc;
    }, {});

  const categoryChartData = Object.entries(expensesByCategory)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 6);

  // Evolução P&L (6 meses)
  const last6Months = Array.from({ length: 6 }, (_, i) => {
    const date = subMonths(new Date(), 5 - i);
    const monthStart = startOfMonth(date);
    const monthEnd = endOfMonth(date);
    
    const monthTransactions = filteredTransactions.filter(t => {
      const tDate = new Date(t.due_date);
      return t.status === "pago" && tDate >= monthStart && tDate <= monthEnd;
    });

    const receitas = monthTransactions
      .filter(t => t.type === "receita")
      .reduce((sum, t) => sum + t.amount, 0);
    
    const despesas = monthTransactions
      .filter(t => t.type === "despesa")
      .reduce((sum, t) => sum + t.amount, 0);

    return {
      month: format(date, "MMM/yy", { locale: ptBR }),
      receitas,
      despesas,
      lucro: receitas - despesas,
    };
  });

  // Despesas por Centro de Custo (Bar Chart)
  const expensesByCostCenter = filteredTransactions
    .filter(t => t.type === "despesa" && t.status === "pago" && t.cost_center)
    .reduce((acc, t) => {
      acc[t.cost_center] = (acc[t.cost_center] || 0) + t.amount;
      return acc;
    }, {});

  const costCenterChartData = Object.entries(expensesByCostCenter)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 8);

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div>
        <h1 className="text-4xl font-bold text-white drop-shadow-lg">Relatórios Personalizados</h1>
        <p className="text-blue-200 mt-1">Crie relatórios customizados com análise de IA</p>
      </div>

      {/* Configuração do Relatório */}
      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Filter className="w-5 h-5 text-blue-400" />
            Configurar Relatório
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Período */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-blue-200">Data Início</Label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="bg-blue-950/50 border-blue-700 text-white"
              />
            </div>
            <div>
              <Label className="text-blue-200">Data Fim</Label>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="bg-blue-950/50 border-blue-700 text-white"
              />
            </div>
          </div>

          {/* Filtros Avançados */}
          <div>
            <Label className="text-blue-200 mb-3 block">Filtros Avançados</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <Label className="text-blue-300 text-xs">Tipo</Label>
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="receita">Receitas</SelectItem>
                    <SelectItem value="despesa">Despesas</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-blue-300 text-xs">Status</Label>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="pago">Pago</SelectItem>
                    <SelectItem value="pendente">Pendente</SelectItem>
                    <SelectItem value="vencido">Vencido</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-blue-300 text-xs">Categoria</Label>
                <Select value={filterCategory} onValueChange={setFilterCategory}>
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    <SelectItem value="all">Todas</SelectItem>
                    {categories.map(cat => (
                      <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-blue-300 text-xs">Centro de Custo</Label>
                <Select value={filterCostCenter} onValueChange={setFilterCostCenter}>
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    <SelectItem value="all">Todos</SelectItem>
                    {costCenters.map(cc => (
                      <SelectItem key={cc.id} value={cc.name}>{cc.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-blue-300 text-xs">Conta Bancária</Label>
                <Select value={filterBankAccount} onValueChange={setFilterBankAccount}>
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    <SelectItem value="all">Todas</SelectItem>
                    {bankAccounts.map(ba => (
                      <SelectItem key={ba.id} value={ba.name}>{ba.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-blue-300 text-xs">Cliente/Fornecedor</Label>
                <Select value={filterContact} onValueChange={setFilterContact}>
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    <SelectItem value="all">Todos</SelectItem>
                    {contacts.map(c => (
                      <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Campos */}
          <div>
            <Label className="text-blue-200 mb-3 block">Campos do Relatório</Label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {Object.entries({
                due_date: "Data Vencimento",
                payment_date: "Data Pagamento",
                description: "Descrição",
                type: "Tipo",
                category: "Categoria",
                subcategory: "Subcategoria",
                cost_center: "Centro de Custo",
                amount: "Valor",
                status: "Status",
                supplier_name: "Fornecedor",
                client_name: "Cliente",
                payment_method: "Forma Pagamento",
                bank_account: "Conta Bancária",
                document_number: "Nº Documento",
                invoice_number: "Nº NF",
                installment: "Parcela",
                notes: "Observações",
              }).map(([field, label]) => (
                <div key={field} className="flex items-center space-x-2">
                  <Checkbox
                    id={field}
                    checked={selectedFields[field]}
                    onCheckedChange={() => toggleField(field)}
                  />
                  <label htmlFor={field} className="text-sm text-blue-200 cursor-pointer">
                    {label}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Resumo */}
          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-blue-700">
            <div className="bg-green-950/30 p-4 rounded-lg border border-green-700">
              <p className="text-xs text-green-300">Receitas</p>
              <p className="text-xl font-bold text-white">
                R$ {totalReceitas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div className="bg-red-950/30 p-4 rounded-lg border border-red-700">
              <p className="text-xs text-red-300">Despesas</p>
              <p className="text-xl font-bold text-white">
                R$ {totalDespesas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div className="bg-blue-950/30 p-4 rounded-lg border border-blue-700">
              <p className="text-xs text-blue-300">Saldo</p>
              <p className="text-xl font-bold text-white">
                R$ {(totalReceitas - totalDespesas).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={generateAIAnalysis}
              disabled={generating}
              className="flex-1 bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600"
            >
              {generating ? (
                <>
                  <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                  Analisando...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Análise com IA
                </>
              )}
            </Button>
            <Button
              onClick={exportToExcelModern}
              className="flex-1 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600"
            >
              <Download className="w-4 h-4 mr-2" />
              Exportar Excel
            </Button>
            <Button
              onClick={exportToPDFModern}
              className="flex-1 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-600"
            >
              <FileText className="w-4 h-4 mr-2" />
              Exportar PDF
            </Button>
            <Button
              onClick={sendWhatsAppReport}
              className="flex-1 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Enviar WhatsApp
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Análise IA */}
      {aiAnalysis && (
        <Card className="border-purple-700/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-400" />
              Análise Inteligente do Relatório
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-sm text-purple-100 whitespace-pre-wrap leading-relaxed">
              {aiAnalysis}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Gráficos Interativos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
          <CardHeader>
            <CardTitle className="text-white">📊 Despesas por Categoria</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryChartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px" }}
                  formatter={(value) => `R$ ${value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
          <CardHeader>
            <CardTitle className="text-white">📈 Evolução P&L (Últimos 6 Meses)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={last6Months}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
                <XAxis dataKey="month" stroke="#93c5fd" fontSize={12} />
                <YAxis stroke="#93c5fd" fontSize={12} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px" }}
                  formatter={(value) => `R$ ${value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
                />
                <Legend />
                <Line type="monotone" dataKey="receitas" stroke="#10B981" strokeWidth={3} name="Receitas" />
                <Line type="monotone" dataKey="despesas" stroke="#EF4444" strokeWidth={3} name="Despesas" />
                <Line type="monotone" dataKey="lucro" stroke="#3B82F6" strokeWidth={3} name="Lucro" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
          <CardHeader>
            <CardTitle className="text-white">📊 Despesas por Centro de Custo</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={costCenterChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
                <XAxis dataKey="name" stroke="#93c5fd" fontSize={12} angle={-45} textAnchor="end" height={100} />
                <YAxis stroke="#93c5fd" fontSize={12} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px" }}
                  formatter={(value) => `R$ ${value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
                />
                <Bar dataKey="value" fill="#3B82F6" radius={[8, 8, 0, 0]} name="Despesas" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
          <CardHeader>
            <CardTitle className="text-white">📉 Evolução de Receitas vs Despesas (Área)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={last6Months}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
                <XAxis dataKey="month" stroke="#93c5fd" fontSize={12} />
                <YAxis stroke="#93c5fd" fontSize={12} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px" }}
                  formatter={(value) => `R$ ${value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
                />
                <Legend />
                <Area type="monotone" dataKey="receitas" stackId="1" stroke="#10B981" fill="#10B981" fillOpacity={0.6} name="Receitas" />
                <Area type="monotone" dataKey="despesas" stackId="2" stroke="#EF4444" fill="#EF4444" fillOpacity={0.6} name="Despesas" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Preview da Tabela */}
      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-400" />
            Preview do Relatório ({filteredTransactions.length} transações)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-blue-950/50 border-blue-700">
                  {selectedFields.due_date && <TableHead className="text-blue-300">Vencimento</TableHead>}
                  {selectedFields.payment_date && <TableHead className="text-blue-300">Pagamento</TableHead>}
                  {selectedFields.description && <TableHead className="text-blue-300">Descrição</TableHead>}
                  {selectedFields.type && <TableHead className="text-blue-300">Tipo</TableHead>}
                  {selectedFields.category && <TableHead className="text-blue-300">Categoria</TableHead>}
                  {selectedFields.subcategory && <TableHead className="text-blue-300">Subcategoria</TableHead>}
                  {selectedFields.cost_center && <TableHead className="text-blue-300">Centro Custo</TableHead>}
                  {selectedFields.amount && <TableHead className="text-blue-300">Valor</TableHead>}
                  {selectedFields.status && <TableHead className="text-blue-300">Status</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTransactions.slice(0, 10).map((t) => (
                  <TableRow key={t.id} className="border-blue-700">
                    {selectedFields.due_date && (
                      <TableCell className="text-white">{format(new Date(t.due_date), "dd/MM/yyyy")}</TableCell>
                    )}
                    {selectedFields.payment_date && (
                      <TableCell className="text-blue-200">
                        {t.payment_date ? format(new Date(t.payment_date), "dd/MM/yyyy") : "-"}
                      </TableCell>
                    )}
                    {selectedFields.description && <TableCell className="text-blue-100">{t.description}</TableCell>}
                    {selectedFields.type && (
                      <TableCell className="text-blue-200">{t.type === "receita" ? "Receita" : "Despesa"}</TableCell>
                    )}
                    {selectedFields.category && <TableCell className="text-blue-200">{t.category || "-"}</TableCell>}
                    {selectedFields.subcategory && <TableCell className="text-blue-200">{t.subcategory || "-"}</TableCell>}
                    {selectedFields.cost_center && <TableCell className="text-blue-200">{t.cost_center || "-"}</TableCell>}
                    {selectedFields.amount && (
                      <TableCell className={t.type === "receita" ? "text-green-300 font-semibold" : "text-red-300 font-semibold"}>
                        R$ {t.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </TableCell>
                    )}
                    {selectedFields.status && <TableCell className="text-blue-200">{t.status}</TableCell>}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {filteredTransactions.length > 10 && (
              <p className="text-center text-sm text-blue-300 mt-4">
                Mostrando 10 de {filteredTransactions.length} transações. O relatório completo será exportado.
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      <AIAssistant
        context={`Relatório: ${filteredTransactions.length} transações, Receitas: ${totalReceitas}, Despesas: ${totalDespesas}`}
        pageInfo="Relatórios Personalizados - Criação de relatórios customizados"
      />
    </div>
  );
}