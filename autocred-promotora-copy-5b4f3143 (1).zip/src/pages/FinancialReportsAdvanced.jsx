import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  FileText,
  Download,
  Sparkles,
  TrendingUp,
  TrendingDown,
  Calendar,
  Filter,
  RefreshCw,
  AlertCircle,
} from "lucide-react";
import { format, startOfMonth, endOfMonth, subMonths } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const COLORS = ["#10B981", "#EF4444", "#3B82F6", "#F59E0B", "#8B5CF6", "#EC4899"];

export default function FinancialReportsAdvanced() {
  const today = new Date();
  const [startDate, setStartDate] = useState(format(startOfMonth(today), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(endOfMonth(today), "yyyy-MM-dd"));
  const [filterAccount, setFilterAccount] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterCostCenter, setFilterCostCenter] = useState("all");
  const [aiAnalysis, setAiAnalysis] = useState("");
  const [loadingAI, setLoadingAI] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [predictiveAnalysis, setPredictiveAnalysis] = useState(null);
  const [anomalies, setAnomalies] = useState([]);
  const [optimizations, setOptimizations] = useState([]);
  const [recurringPatterns, setRecurringPatterns] = useState([]);
  const [ambiguousSuggestions, setAmbiguousSuggestions] = useState([]);
  const [seasonalImpacts, setSeasonalImpacts] = useState(null);
  const [weeklyMonthlyInsights, setWeeklyMonthlyInsights] = useState(null);

  const { data: transactions = [] } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list("-due_date"),
    initialData: [],
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ["bankAccounts"],
    queryFn: () => base44.entities.BankAccount.list(),
    initialData: [],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list(),
    initialData: [],
  });

  const { data: costCenters = [] } = useQuery({
    queryKey: ["costCenters"],
    queryFn: () => base44.entities.CostCenter.list(),
    initialData: [],
  });

  // FILTRAR TRANSAÇÕES
  const filteredTransactions = transactions.filter(t => {
    const tDate = new Date(t.due_date);
    const inDateRange = tDate >= new Date(startDate) && tDate <= new Date(endDate);
    const matchAccount = filterAccount === "all" || t.bank_account === filterAccount;
    const matchCategory = filterCategory === "all" || t.category === filterCategory;
    const matchCostCenter = filterCostCenter === "all" || t.cost_center === filterCostCenter;
    return inDateRange && matchAccount && matchCategory && matchCostCenter && t.status === "pago";
  });

  // MÉTRICAS
  const totalReceitas = filteredTransactions.filter(t => t.type === "receita").reduce((sum, t) => sum + t.amount, 0);
  const totalDespesas = filteredTransactions.filter(t => t.type === "despesa").reduce((sum, t) => sum + t.amount, 0);
  const saldo = totalReceitas - totalDespesas;
  const margemLucro = totalReceitas > 0 ? ((saldo / totalReceitas) * 100).toFixed(2) : 0;

  // DESPESAS POR CATEGORIA
  const despesasPorCategoria = filteredTransactions
    .filter(t => t.type === "despesa")
    .reduce((acc, t) => {
      const cat = t.category || "Outros";
      acc[cat] = (acc[cat] || 0) + t.amount;
      return acc;
    }, {});

  const categoriasChart = Object.entries(despesasPorCategoria)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);

  // DESPESAS POR CENTRO DE CUSTO
  const despesasPorCentroCusto = filteredTransactions
    .filter(t => t.type === "despesa" && t.cost_center)
    .reduce((acc, t) => {
      acc[t.cost_center] = (acc[t.cost_center] || 0) + t.amount;
      return acc;
    }, {});

  const centroCustoChart = Object.entries(despesasPorCentroCusto)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);

  // EVOLUÇÃO MENSAL (ÚLTIMOS 6 MESES)
  const evolucaoMensal = Array.from({ length: 6 }, (_, i) => {
    const date = subMonths(today, 5 - i);
    const monthStart = startOfMonth(date);
    const monthEnd = endOfMonth(date);
    
    const monthTrans = transactions.filter(t => {
      const tDate = new Date(t.due_date);
      return t.status === "pago" && tDate >= monthStart && tDate <= monthEnd;
    });

    const receitas = monthTrans.filter(t => t.type === "receita").reduce((sum, t) => sum + t.amount, 0);
    const despesas = monthTrans.filter(t => t.type === "despesa").reduce((sum, t) => sum + t.amount, 0);

    return {
      month: format(date, "MMM/yy", { locale: ptBR }),
      receitas,
      despesas,
      saldo: receitas - despesas,
    };
  });

  // ANÁLISE PREDITIVA COMPLETA
  const generatePredictiveAnalysis = async () => {
    setLoadingAI(true);
    try {
      // 1. FLUXO DE CAIXA FUTURO
      const cashflowResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Analise e PROJETE o fluxo de caixa para os próximos 90 dias:

HISTÓRICO (${format(new Date(startDate), "dd/MM/yyyy")} - ${format(new Date(endDate), "dd/MM/yyyy")}):
- Receitas: R$ ${totalReceitas.toFixed(2)}
- Despesas: R$ ${totalDespesas.toFixed(2)}
- Saldo: R$ ${saldo.toFixed(2)}

EVOLUÇÃO 6 MESES:
${evolucaoMensal.map(m => `${m.month}: Rec R$ ${m.receitas.toFixed(2)}, Desp R$ ${m.despesas.toFixed(2)}`).join('\n')}

DESPESAS POR CATEGORIA:
${Object.entries(despesasPorCategoria).slice(0, 10).map(([cat, val]) => `- ${cat}: R$ ${val.toFixed(2)}`).join('\n')}

Forneça em JSON:
{
  "next_30_days": {
    "expected_revenue": 0,
    "expected_expenses": 0,
    "expected_balance": 0,
    "confidence": "alta|média|baixa"
  },
  "next_60_days": { ... },
  "next_90_days": { ... },
  "trends": ["tendência 1", "tendência 2"],
  "risks": ["risco 1", "risco 2"],
  "recommendations": ["rec 1", "rec 2"]
}`,
        response_json_schema: {
          type: "object",
          properties: {
            next_30_days: {
              type: "object",
              properties: {
                expected_revenue: { type: "number" },
                expected_expenses: { type: "number" },
                expected_balance: { type: "number" },
                confidence: { type: "string" }
              }
            },
            next_60_days: {
              type: "object",
              properties: {
                expected_revenue: { type: "number" },
                expected_expenses: { type: "number" },
                expected_balance: { type: "number" },
                confidence: { type: "string" }
              }
            },
            next_90_days: {
              type: "object",
              properties: {
                expected_revenue: { type: "number" },
                expected_expenses: { type: "number" },
                expected_balance: { type: "number" },
                confidence: { type: "string" }
              }
            },
            trends: { type: "array", items: { type: "string" } },
            risks: { type: "array", items: { type: "string" } },
            recommendations: { type: "array", items: { type: "string" } }
          }
        }
      });

      // 2. DETECÇÃO DE ANOMALIAS
      const anomaliesResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Identifique ANOMALIAS nas despesas:

DESPESAS POR CATEGORIA:
${Object.entries(despesasPorCategoria).map(([cat, val]) => `- ${cat}: R$ ${val.toFixed(2)}`).join('\n')}

HISTÓRICO 6 MESES:
${evolucaoMensal.map(m => `${m.month}: R$ ${m.despesas.toFixed(2)}`).join('\n')}

JSON:
{
  "anomalies": [
    {
      "category": "string",
      "current_value": 0,
      "expected_value": 0,
      "deviation_percentage": 0,
      "severity": "alta|média|baixa",
      "description": "string"
    }
  ]
}`,
        response_json_schema: {
          type: "object",
          properties: {
            anomalies: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  category: { type: "string" },
                  current_value: { type: "number" },
                  expected_value: { type: "number" },
                  deviation_percentage: { type: "number" },
                  severity: { type: "string" },
                  description: { type: "string" }
                }
              }
            }
          }
        }
      });

      // 3. OTIMIZAÇÕES DE ORÇAMENTO
      const optimizationsResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Sugira OTIMIZAÇÕES específicas de orçamento:

SITUAÇÃO ATUAL:
- Receitas: R$ ${totalReceitas.toFixed(2)}
- Despesas: R$ ${totalDespesas.toFixed(2)}
- Margem: ${margemLucro}%

MAIORES DESPESAS:
${Object.entries(despesasPorCategoria)
  .sort((a, b) => b[1] - a[1])
  .slice(0, 5)
  .map(([cat, val]) => `- ${cat}: R$ ${val.toFixed(2)}`)
  .join('\n')}

JSON:
{
  "optimizations": [
    {
      "category": "string",
      "current_spending": 0,
      "suggested_budget": 0,
      "potential_savings": 0,
      "priority": "alta|média|baixa",
      "action_plan": "string",
      "implementation_difficulty": "fácil|média|difícil"
    }
  ],
  "total_potential_savings": 0
}`,
        response_json_schema: {
          type: "object",
          properties: {
            optimizations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  category: { type: "string" },
                  current_spending: { type: "number" },
                  suggested_budget: { type: "number" },
                  potential_savings: { type: "number" },
                  priority: { type: "string" },
                  action_plan: { type: "string" },
                  implementation_difficulty: { type: "string" }
                }
              }
            },
            total_potential_savings: { type: "number" }
          }
        }
      });

      // 4. PADRÕES RECORRENTES NÃO ÓBVIOS
      const patternsResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Identifique PADRÕES RECORRENTES NÃO ÓBVIOS nas transações:

TRANSAÇÕES:
${filteredTransactions.slice(0, 200).map(t => 
  `${format(new Date(t.due_date), "dd/MM/yyyy")} - ${t.description} - ${t.type} - R$ ${t.amount.toFixed(2)}`
).join('\n')}

Encontre padrões sutis, não apenas mensalidades óbvias. JSON:
{
  "patterns": [
    {
      "pattern_description": "string",
      "frequency": "semanal|quinzenal|mensal|trimestral",
      "average_amount": 0,
      "category": "string",
      "occurrences": 0,
      "hidden_impact": "string"
    }
  ]
}`,
        response_json_schema: {
          type: "object",
          properties: {
            patterns: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  pattern_description: { type: "string" },
                  frequency: { type: "string" },
                  average_amount: { type: "number" },
                  category: { type: "string" },
                  occurrences: { type: "number" },
                  hidden_impact: { type: "string" }
                }
              }
            }
          }
        }
      });

      // 5. SUGESTÕES PARA DESCRIÇÕES AMBÍGUAS
      const ambiguousTransactions = filteredTransactions.filter(t => 
        !t.category || t.category === "Outros" || t.description.length < 20
      ).slice(0, 30);

      const ambiguousResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Sugira categorias/centros de custo para transações AMBÍGUAS baseado no histórico:

TRANSAÇÕES AMBÍGUAS:
${ambiguousTransactions.map(t => 
  `ID: ${t.id} - ${t.description} - ${t.type} - R$ ${t.amount.toFixed(2)}`
).join('\n')}

HISTÓRICO DE CATEGORIAS:
${Object.entries(despesasPorCategoria).map(([cat, val]) => `- ${cat}: R$ ${val.toFixed(2)}`).join('\n')}

JSON:
{
  "suggestions": [
    {
      "transaction_id": "string",
      "suggested_category": "string",
      "suggested_cost_center": "string",
      "confidence": 0.0,
      "reasoning": "string"
    }
  ]
}`,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  transaction_id: { type: "string" },
                  suggested_category: { type: "string" },
                  suggested_cost_center: { type: "string" },
                  confidence: { type: "number" },
                  reasoning: { type: "string" }
                }
              }
            }
          }
        }
      });

      // 6. IMPACTO DE EVENTOS EXTERNOS E SAZONALIDADE
      const seasonalResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Preveja IMPACTO de EVENTOS EXTERNOS e SAZONALIDADE:

DADOS ATUAIS:
- Receitas Médias: R$ ${(totalReceitas / 6).toFixed(2)}
- Despesas Médias: R$ ${(totalDespesas / 6).toFixed(2)}
- Período do Ano: ${format(new Date(), "MMMM", { locale: ptBR })}

HISTÓRICO:
${evolucaoMensal.map(m => `${m.month}: Rec R$ ${m.receitas.toFixed(2)}, Desp R$ ${m.despesas.toFixed(2)}`).join('\n')}

JSON:
{
  "seasonal_events": [
    {
      "event_name": "string",
      "month": "string",
      "estimated_impact": 0,
      "impact_type": "receita|despesa",
      "preparation_needed": "string"
    }
  ],
  "current_season_impact": "string",
  "next_quarter_predictions": "string"
}`,
        response_json_schema: {
          type: "object",
          properties: {
            seasonal_events: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  event_name: { type: "string" },
                  month: { type: "string" },
                  estimated_impact: { type: "number" },
                  impact_type: { type: "string" },
                  preparation_needed: { type: "string" }
                }
              }
            },
            current_season_impact: { type: "string" },
            next_quarter_predictions: { type: "string" }
          }
        }
      });

      // 7. RESUMO SEMANAL/MENSAL
      const insightsResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Gere RESUMO EXECUTIVO com principais INSIGHTS e ALERTAS:

PERÍODO: ${format(new Date(startDate), "dd/MM/yyyy")} - ${format(new Date(endDate), "dd/MM/yyyy")}
RECEITAS: R$ ${totalReceitas.toFixed(2)}
DESPESAS: R$ ${totalDespesas.toFixed(2)}
SALDO: R$ ${saldo.toFixed(2)}

TOP CATEGORIAS:
${Object.entries(despesasPorCategoria).slice(0, 5).map(([cat, val]) => `- ${cat}: R$ ${val.toFixed(2)}`).join('\n')}

JSON:
{
  "summary": "string resumo executivo",
  "top_insights": ["insight 1", "insight 2", "insight 3"],
  "critical_alerts": ["alerta 1", "alerta 2"],
  "opportunities": ["oportunidade 1", "oportunidade 2"],
  "action_items": ["ação 1", "ação 2", "ação 3"]
}`,
        response_json_schema: {
          type: "object",
          properties: {
            summary: { type: "string" },
            top_insights: { type: "array", items: { type: "string" } },
            critical_alerts: { type: "array", items: { type: "string" } },
            opportunities: { type: "array", items: { type: "string" } },
            action_items: { type: "array", items: { type: "string" } }
          }
        }
      });

      setPredictiveAnalysis(cashflowResult);
      setAnomalies(anomaliesResult.anomalies || []);
      setOptimizations(optimizationsResult.optimizations || []);
      setRecurringPatterns(patternsResult.patterns || []);
      setAmbiguousSuggestions(ambiguousResult.suggestions || []);
      setSeasonalImpacts(seasonalResult);
      setWeeklyMonthlyInsights(insightsResult);
      
      toast.success("✅ Análise completa gerada!");
    } catch (error) {
      toast.error("Erro ao gerar análises");
    }
    setLoadingAI(false);
  };

  // ANÁLISE EXECUTIVA TEXTUAL
  const generateAIAnalysis = async () => {
    setLoadingAI(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analise este relatório financeiro completo:

PERÍODO: ${format(new Date(startDate), "dd/MM/yyyy")} até ${format(new Date(endDate), "dd/MM/yyyy")}

RESUMO FINANCEIRO:
- Total Receitas: R$ ${totalReceitas.toFixed(2)}
- Total Despesas: R$ ${totalDespesas.toFixed(2)}
- Saldo: R$ ${saldo.toFixed(2)}
- Margem de Lucro: ${margemLucro}%
- Total de Transações: ${filteredTransactions.length}

DESPESAS POR CATEGORIA:
${Object.entries(despesasPorCategoria).map(([cat, val]) => `- ${cat}: R$ ${val.toFixed(2)}`).join('\n')}

DESPESAS POR CENTRO DE CUSTO:
${Object.entries(despesasPorCentroCusto).map(([cc, val]) => `- ${cc}: R$ ${val.toFixed(2)}`).join('\n')}

EVOLUÇÃO DOS ÚLTIMOS 6 MESES:
${evolucaoMensal.map(m => `${m.month}: Receitas R$ ${m.receitas.toFixed(2)}, Despesas R$ ${m.despesas.toFixed(2)}, Saldo R$ ${m.saldo.toFixed(2)}`).join('\n')}

Forneça uma análise executiva detalhada com:
1. Avaliação geral da saúde financeira
2. Principais insights sobre categorias e centros de custo
3. Análise de tendências dos últimos 6 meses
4. Alertas sobre gastos elevados ou incomuns
5. 10 recomendações estratégicas específicas
6. Projeções para os próximos 30 dias
7. KPIs críticos a monitorar`,
      });

      setAiAnalysis(result);
      toast.success("✅ Análise gerada!");
    } catch (error) {
      toast.error("Erro ao gerar análise");
    }
    setLoadingAI(false);
  };

  // EXPORTAR CSV
  const exportCSV = () => {
    const headers = ["Data", "Descrição", "Tipo", "Categoria", "Centro Custo", "Conta", "Valor"];
    const rows = filteredTransactions.map(t => [
      format(new Date(t.due_date), "dd/MM/yyyy"),
      t.description,
      t.type === "receita" ? "Receita" : "Despesa",
      t.category || "-",
      t.cost_center || "-",
      t.bank_account || "-",
      t.amount.toFixed(2),
    ]);

    const csv = [headers, ...rows].map(row => row.join(";")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `relatorio_${format(new Date(), "yyyy-MM-dd")}.csv`;
    link.click();
    toast.success("✅ CSV exportado!");
  };

  // EXPORTAR PDF MODERNO A4
  const exportPDF = () => {
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>
          @page { size: A4; margin: 15mm; }
          @media print { body { margin: 0; } }
          
          * { box-sizing: border-box; }
          body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #1a202c;
          }
          
          .container {
            max-width: 210mm;
            margin: 0 auto;
            background: white;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border-radius: 12px;
          }
          
          .header {
            text-align: center;
            padding-bottom: 20px;
            border-bottom: 3px solid #667eea;
            margin-bottom: 30px;
          }
          
          .header h1 {
            color: #667eea;
            margin: 0;
            font-size: 32px;
            font-weight: 700;
            letter-spacing: -0.5px;
          }
          
          .header p {
            color: #718096;
            margin: 10px 0 0 0;
            font-size: 14px;
          }
          
          .metrics {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin: 30px 0;
          }
          
          .metric-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            border-radius: 12px;
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
          }
          
          .metric-card h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            opacity: 0.9;
            font-weight: 500;
          }
          
          .metric-card .value {
            font-size: 28px;
            font-weight: 700;
            margin: 0;
          }
          
          table {
            width: 100%;
            border-collapse: collapse;
            margin: 30px 0;
            font-size: 12px;
          }
          
          th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
          }
          
          td {
            padding: 12px;
            border-bottom: 1px solid #e2e8f0;
          }
          
          tr:hover {
            background: #f7fafc;
          }
          
          .receita { color: #10b981; font-weight: 600; }
          .despesa { color: #ef4444; font-weight: 600; }
          
          .analysis-section {
            background: linear-gradient(135deg, #f0f4ff 0%, #e9e4f0 100%);
            padding: 25px;
            border-radius: 12px;
            margin: 30px 0;
            border-left: 4px solid #667eea;
          }
          
          .analysis-section h2 {
            color: #667eea;
            margin-top: 0;
            font-size: 20px;
          }
          
          .predictions {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin: 20px 0;
          }
          
          .prediction-card {
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
          }
          
          .prediction-card h4 {
            margin: 0 0 10px 0;
            color: #667eea;
            font-size: 14px;
          }
          
          .anomaly {
            background: #fef2f2;
            border-left: 4px solid #ef4444;
            padding: 15px;
            margin: 10px 0;
            border-radius: 8px;
          }
          
          .optimization {
            background: #f0fdf4;
            border-left: 4px solid #10b981;
            padding: 15px;
            margin: 10px 0;
            border-radius: 8px;
          }
          
          .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #e2e8f0;
            color: #718096;
            font-size: 12px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>📊 Relatório Financeiro Avançado</h1>
            <p><strong>AUTOCRED PROMOTORA</strong></p>
            <p>Período: ${format(new Date(startDate), "dd/MM/yyyy")} até ${format(new Date(endDate), "dd/MM/yyyy")}</p>
            <p>Gerado em: ${format(new Date(), "dd/MM/yyyy 'às' HH:mm")}</p>
          </div>
          
          <div class="metrics">
            <div class="metric-card">
              <h3>💰 Total Receitas</h3>
              <p class="value">R$ ${totalReceitas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
            </div>
            <div class="metric-card">
              <h3>💸 Total Despesas</h3>
              <p class="value">R$ ${totalDespesas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
            </div>
            <div class="metric-card">
              <h3>📈 Saldo do Período</h3>
              <p class="value">R$ ${saldo.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
            </div>
            <div class="metric-card">
              <h3>📊 Margem de Lucro</h3>
              <p class="value">${margemLucro}%</p>
            </div>
          </div>

          ${predictiveAnalysis ? `
          <div class="analysis-section">
            <h2>🔮 Análise Preditiva - Próximos 90 Dias</h2>
            <div class="predictions">
              <div class="prediction-card">
                <h4>📅 30 Dias</h4>
                <p><strong>Receitas:</strong> R$ ${predictiveAnalysis.next_30_days.expected_revenue.toLocaleString("pt-BR")}</p>
                <p><strong>Despesas:</strong> R$ ${predictiveAnalysis.next_30_days.expected_expenses.toLocaleString("pt-BR")}</p>
                <p><strong>Saldo:</strong> R$ ${predictiveAnalysis.next_30_days.expected_balance.toLocaleString("pt-BR")}</p>
                <p><em>Confiança: ${predictiveAnalysis.next_30_days.confidence}</em></p>
              </div>
              <div class="prediction-card">
                <h4>📅 60 Dias</h4>
                <p><strong>Receitas:</strong> R$ ${predictiveAnalysis.next_60_days.expected_revenue.toLocaleString("pt-BR")}</p>
                <p><strong>Despesas:</strong> R$ ${predictiveAnalysis.next_60_days.expected_expenses.toLocaleString("pt-BR")}</p>
                <p><strong>Saldo:</strong> R$ ${predictiveAnalysis.next_60_days.expected_balance.toLocaleString("pt-BR")}</p>
                <p><em>Confiança: ${predictiveAnalysis.next_60_days.confidence}</em></p>
              </div>
              <div class="prediction-card">
                <h4>📅 90 Dias</h4>
                <p><strong>Receitas:</strong> R$ ${predictiveAnalysis.next_90_days.expected_revenue.toLocaleString("pt-BR")}</p>
                <p><strong>Despesas:</strong> R$ ${predictiveAnalysis.next_90_days.expected_expenses.toLocaleString("pt-BR")}</p>
                <p><strong>Saldo:</strong> R$ ${predictiveAnalysis.next_90_days.expected_balance.toLocaleString("pt-BR")}</p>
                <p><em>Confiança: ${predictiveAnalysis.next_90_days.confidence}</em></p>
              </div>
            </div>
          </div>
          ` : ''}

          ${anomalies.length > 0 ? `
          <div class="analysis-section">
            <h2>⚠️ Anomalias Detectadas</h2>
            ${anomalies.map(a => `
              <div class="anomaly">
                <h4><strong>${a.category}</strong> - Severidade: ${a.severity}</h4>
                <p>${a.description}</p>
                <p><strong>Valor Atual:</strong> R$ ${a.current_value.toLocaleString("pt-BR")} | 
                   <strong>Esperado:</strong> R$ ${a.expected_value.toLocaleString("pt-BR")} | 
                   <strong>Desvio:</strong> ${a.deviation_percentage.toFixed(1)}%</p>
              </div>
            `).join('')}
          </div>
          ` : ''}

          ${optimizations.length > 0 ? `
          <div class="analysis-section">
            <h2>💡 Otimizações Sugeridas</h2>
            ${optimizations.map(o => `
              <div class="optimization">
                <h4><strong>${o.category}</strong> - Prioridade: ${o.priority}</h4>
                <p>${o.action_plan}</p>
                <p><strong>Gasto Atual:</strong> R$ ${o.current_spending.toLocaleString("pt-BR")} → 
                   <strong>Orçamento Sugerido:</strong> R$ ${o.suggested_budget.toLocaleString("pt-BR")}</p>
                <p><strong>Economia Potencial:</strong> R$ ${o.potential_savings.toLocaleString("pt-BR")} | 
                   <strong>Dificuldade:</strong> ${o.implementation_difficulty}</p>
              </div>
            `).join('')}
          </div>
          ` : ''}
          
          <table>
            <thead>
              <tr>
                <th>Data</th>
                <th>Descrição</th>
                <th>Tipo</th>
                <th>Categoria</th>
                <th>Valor</th>
              </tr>
            </thead>
            <tbody>
              ${filteredTransactions.slice(0, 50).map(t => `
                <tr>
                  <td>${format(new Date(t.due_date), "dd/MM/yyyy")}</td>
                  <td>${t.description}</td>
                  <td><span class="${t.type}">${t.type === "receita" ? "Receita" : "Despesa"}</span></td>
                  <td>${t.category || "-"}</td>
                  <td class="${t.type}">R$ ${t.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</td>
                </tr>
              `).join('')}
              ${filteredTransactions.length > 50 ? `
                <tr>
                  <td colspan="5" style="text-align: center; font-style: italic; color: #718096;">
                    ... e mais ${filteredTransactions.length - 50} transações
                  </td>
                </tr>
              ` : ''}
            </tbody>
          </table>

          ${aiAnalysis ? `
          <div class="analysis-section">
            <h2>🤖 Análise Executiva com IA</h2>
            <div style="white-space: pre-wrap; line-height: 1.6;">${aiAnalysis}</div>
          </div>
          ` : ''}
          
          <div class="footer">
            <p>Relatório gerado automaticamente pelo Sistema Financeiro AUTOCRED PROMOTORA</p>
            <p>Para imprimir como PDF: Use Ctrl+P (Cmd+P no Mac) → Salvar como PDF</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const blob = new Blob([html], { type: "text/html" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `relatorio_avancado_${format(new Date(), "yyyy-MM-dd_HHmm")}.html`;
    link.click();
    toast.success("✅ PDF A4 gerado! Use Ctrl+P para imprimir");
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white">Relatórios Financeiros Avançados</h1>
          <p className="text-blue-200 mt-1">Análise completa com IA, filtros e exportação</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={exportCSV} className="bg-gradient-to-r from-green-600 to-green-500">
            <Download className="w-4 h-4 mr-2" />
            CSV
          </Button>
          <Button onClick={exportPDF} className="bg-gradient-to-r from-red-600 to-red-500">
            <Download className="w-4 h-4 mr-2" />
            PDF
          </Button>
        </div>
      </div>

      {/* FILTROS */}
      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filtros
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div>
              <Label className="text-blue-200">Data Inicial</Label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="bg-blue-950/50 border-blue-700 text-white"
              />
            </div>
            <div>
              <Label className="text-blue-200">Data Final</Label>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="bg-blue-950/50 border-blue-700 text-white"
              />
            </div>
            <div>
              <Label className="text-blue-200">Conta Bancária</Label>
              <Select value={filterAccount} onValueChange={setFilterAccount}>
                <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-blue-900 border-blue-700">
                  <SelectItem value="all">Todas</SelectItem>
                  {bankAccounts.map(acc => (
                    <SelectItem key={acc.id} value={acc.name}>{acc.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-blue-200">Categoria</Label>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-blue-900 border-blue-700">
                  <SelectItem value="all">Todas</SelectItem>
                  {categories.map(cat => (
                    <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-blue-200">Centro de Custo</Label>
              <Select value={filterCostCenter} onValueChange={setFilterCostCenter}>
                <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-blue-900 border-blue-700">
                  <SelectItem value="all">Todos</SelectItem>
                  {costCenters.map(cc => (
                    <SelectItem key={cc.id} value={cc.name}>{cc.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* RESUMO */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-green-500/50 bg-gradient-to-br from-green-900/80 to-green-800/80">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-200">Receitas</p>
                <p className="text-3xl font-bold text-white">R$ {totalReceitas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
              </div>
              <TrendingUp className="w-12 h-12 text-green-300" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-red-500/50 bg-gradient-to-br from-red-900/80 to-red-800/80">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-200">Despesas</p>
                <p className="text-3xl font-bold text-white">R$ {totalDespesas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
              </div>
              <TrendingDown className="w-12 h-12 text-red-300" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-blue-500/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-200">Saldo</p>
                <p className={`text-3xl font-bold ${saldo >= 0 ? 'text-green-300' : 'text-red-300'}`}>
                  R$ {saldo.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </p>
              </div>
              <FileText className="w-12 h-12 text-blue-300" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-200">Margem Lucro</p>
                <p className="text-3xl font-bold text-white">{margemLucro}%</p>
              </div>
              <Calendar className="w-12 h-12 text-purple-300" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* RESUMO EXECUTIVO */}
      {weeklyMonthlyInsights && (
        <Card className="border-blue-500/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-blue-400" />
              📋 Resumo Executivo - Principais Insights
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-950/50 p-4 rounded-lg">
              <p className="text-blue-100 leading-relaxed">{weeklyMonthlyInsights.summary}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-green-950/30 p-4 rounded-lg border border-green-600">
                <p className="text-sm font-semibold text-green-300 mb-2">💡 Top Insights:</p>
                <ul className="text-sm text-green-200 space-y-1">
                  {weeklyMonthlyInsights.top_insights.map((insight, i) => <li key={i}>• {insight}</li>)}
                </ul>
              </div>
              <div className="bg-red-950/30 p-4 rounded-lg border border-red-600">
                <p className="text-sm font-semibold text-red-300 mb-2">🚨 Alertas Críticos:</p>
                <ul className="text-sm text-red-200 space-y-1">
                  {weeklyMonthlyInsights.critical_alerts.map((alert, i) => <li key={i}>• {alert}</li>)}
                </ul>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-purple-950/30 p-4 rounded-lg border border-purple-600">
                <p className="text-sm font-semibold text-purple-300 mb-2">🎯 Oportunidades:</p>
                <ul className="text-sm text-purple-200 space-y-1">
                  {weeklyMonthlyInsights.opportunities.map((opp, i) => <li key={i}>• {opp}</li>)}
                </ul>
              </div>
              <div className="bg-yellow-950/30 p-4 rounded-lg border border-yellow-600">
                <p className="text-sm font-semibold text-yellow-300 mb-2">✅ Ações Prioritárias:</p>
                <ul className="text-sm text-yellow-200 space-y-1">
                  {weeklyMonthlyInsights.action_items.map((action, i) => <li key={i}>• {action}</li>)}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* PADRÕES RECORRENTES */}
      {recurringPatterns.length > 0 && (
        <Card className="border-indigo-500/50 bg-gradient-to-br from-indigo-900/80 to-indigo-800/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <RefreshCw className="w-5 h-5 text-indigo-400" />
              🔄 Padrões Recorrentes Identificados
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {recurringPatterns.map((pattern, i) => (
              <div key={i} className="bg-indigo-950/50 p-4 rounded-lg border border-indigo-600">
                <div className="flex justify-between items-start mb-2">
                  <p className="font-semibold text-white">{pattern.pattern_description}</p>
                  <Badge className="bg-indigo-500">{pattern.frequency}</Badge>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs mb-2">
                  <div>
                    <span className="text-indigo-300">Média:</span>
                    <span className="text-white ml-1 font-semibold">R$ {pattern.average_amount.toLocaleString("pt-BR")}</span>
                  </div>
                  <div>
                    <span className="text-indigo-300">Categoria:</span>
                    <span className="text-white ml-1">{pattern.category}</span>
                  </div>
                  <div>
                    <span className="text-indigo-300">Ocorrências:</span>
                    <span className="text-white ml-1">{pattern.occurrences}x</span>
                  </div>
                </div>
                <p className="text-sm text-indigo-200 italic">{pattern.hidden_impact}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* SUGESTÕES PARA AMBÍGUAS */}
      {ambiguousSuggestions.length > 0 && (
        <Card className="border-cyan-500/50 bg-gradient-to-br from-cyan-900/80 to-cyan-800/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-cyan-400" />
              🤔 Sugestões para Transações Ambíguas
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {ambiguousSuggestions.slice(0, 10).map((sug, i) => (
              <div key={i} className="bg-cyan-950/50 p-4 rounded-lg border border-cyan-600">
                <div className="flex justify-between items-start mb-2">
                  <p className="text-sm text-cyan-100">ID: {sug.transaction_id}</p>
                  <Badge className={`${sug.confidence > 0.7 ? 'bg-green-500' : sug.confidence > 0.5 ? 'bg-yellow-500' : 'bg-red-500'}`}>
                    {(sug.confidence * 100).toFixed(0)}% confiança
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 mb-2">
                  <div>
                    <span className="text-xs text-cyan-300">Categoria Sugerida:</span>
                    <p className="text-white font-semibold">{sug.suggested_category}</p>
                  </div>
                  <div>
                    <span className="text-xs text-cyan-300">Centro de Custo:</span>
                    <p className="text-white font-semibold">{sug.suggested_cost_center || "N/A"}</p>
                  </div>
                </div>
                <p className="text-xs text-cyan-200 italic">{sug.reasoning}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* SAZONALIDADE */}
      {seasonalImpacts && (
        <Card className="border-orange-500/50 bg-gradient-to-br from-orange-900/80 to-orange-800/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-orange-400" />
              🌍 Impacto de Eventos Externos e Sazonalidade
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-orange-950/50 p-4 rounded-lg">
              <p className="text-sm font-semibold text-orange-300 mb-2">📅 Período Atual:</p>
              <p className="text-sm text-orange-100">{seasonalImpacts.current_season_impact}</p>
            </div>
            <div className="bg-orange-950/50 p-4 rounded-lg">
              <p className="text-sm font-semibold text-orange-300 mb-2">🔮 Próximo Trimestre:</p>
              <p className="text-sm text-orange-100">{seasonalImpacts.next_quarter_predictions}</p>
            </div>
            <div className="space-y-2">
              <p className="text-sm font-semibold text-orange-300">📆 Eventos Previstos:</p>
              {seasonalImpacts.seasonal_events.map((event, i) => (
                <div key={i} className="bg-orange-950/30 p-3 rounded-lg border border-orange-600">
                  <div className="flex justify-between items-start mb-1">
                    <p className="font-semibold text-white">{event.event_name}</p>
                    <Badge className={event.impact_type === 'receita' ? 'bg-green-500' : 'bg-red-500'}>
                      {event.month}
                    </Badge>
                  </div>
                  <p className="text-sm text-orange-200 mb-1">
                    Impacto Estimado: R$ {event.estimated_impact.toLocaleString("pt-BR")}
                  </p>
                  <p className="text-xs text-orange-300 italic">{event.preparation_needed}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ANÁLISES IA */}
      {predictiveAnalysis && (
        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-400" />
              🔮 Análise Preditiva - Fluxo de Caixa Futuro
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <Card className="bg-blue-950/50 border-blue-600">
                <CardContent className="pt-6">
                  <p className="text-sm text-blue-300 mb-2">Próximos 30 Dias</p>
                  <p className="text-lg font-bold text-white">R$ {predictiveAnalysis.next_30_days.expected_balance.toLocaleString("pt-BR")}</p>
                  <p className="text-xs text-blue-400 mt-2">Confiança: {predictiveAnalysis.next_30_days.confidence}</p>
                </CardContent>
              </Card>
              <Card className="bg-blue-950/50 border-blue-600">
                <CardContent className="pt-6">
                  <p className="text-sm text-blue-300 mb-2">Próximos 60 Dias</p>
                  <p className="text-lg font-bold text-white">R$ {predictiveAnalysis.next_60_days.expected_balance.toLocaleString("pt-BR")}</p>
                  <p className="text-xs text-blue-400 mt-2">Confiança: {predictiveAnalysis.next_60_days.confidence}</p>
                </CardContent>
              </Card>
              <Card className="bg-blue-950/50 border-blue-600">
                <CardContent className="pt-6">
                  <p className="text-sm text-blue-300 mb-2">Próximos 90 Dias</p>
                  <p className="text-lg font-bold text-white">R$ {predictiveAnalysis.next_90_days.expected_balance.toLocaleString("pt-BR")}</p>
                  <p className="text-xs text-blue-400 mt-2">Confiança: {predictiveAnalysis.next_90_days.confidence}</p>
                </CardContent>
              </Card>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-950/30 p-4 rounded-lg">
                <p className="text-sm text-blue-300 font-semibold mb-2">📊 Tendências Identificadas:</p>
                <ul className="text-sm text-blue-200 space-y-1">
                  {predictiveAnalysis.trends.map((t, i) => <li key={i}>• {t}</li>)}
                </ul>
              </div>
              <div className="bg-red-950/30 p-4 rounded-lg">
                <p className="text-sm text-red-300 font-semibold mb-2">⚠️ Riscos:</p>
                <ul className="text-sm text-red-200 space-y-1">
                  {predictiveAnalysis.risks.map((r, i) => <li key={i}>• {r}</li>)}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {anomalies.length > 0 && (
        <Card className="border-red-500/50 bg-gradient-to-br from-red-900/80 to-red-800/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-400" />
              ⚠️ Anomalias Detectadas
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {anomalies.map((anomaly, i) => (
              <div key={i} className="bg-red-950/50 p-4 rounded-lg border border-red-600">
                <div className="flex justify-between items-start mb-2">
                  <p className="font-semibold text-white">{anomaly.category}</p>
                  <Badge className={`${anomaly.severity === 'alta' ? 'bg-red-500' : anomaly.severity === 'média' ? 'bg-yellow-500' : 'bg-blue-500'}`}>
                    {anomaly.severity}
                  </Badge>
                </div>
                <p className="text-sm text-red-200 mb-2">{anomaly.description}</p>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <span className="text-red-300">Atual:</span>
                    <span className="text-white ml-1 font-semibold">R$ {anomaly.current_value.toLocaleString("pt-BR")}</span>
                  </div>
                  <div>
                    <span className="text-red-300">Esperado:</span>
                    <span className="text-white ml-1 font-semibold">R$ {anomaly.expected_value.toLocaleString("pt-BR")}</span>
                  </div>
                  <div>
                    <span className="text-red-300">Desvio:</span>
                    <span className="text-white ml-1 font-semibold">{anomaly.deviation_percentage.toFixed(1)}%</span>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {optimizations.length > 0 && (
        <Card className="border-green-500/50 bg-gradient-to-br from-green-900/80 to-green-800/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              💡 Otimizações de Orçamento Sugeridas
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {optimizations.map((opt, i) => (
              <div key={i} className="bg-green-950/50 p-4 rounded-lg border border-green-600">
                <div className="flex justify-between items-start mb-2">
                  <p className="font-semibold text-white">{opt.category}</p>
                  <div className="flex gap-2">
                    <Badge className={`${opt.priority === 'alta' ? 'bg-red-500' : opt.priority === 'média' ? 'bg-yellow-500' : 'bg-blue-500'}`}>
                      {opt.priority}
                    </Badge>
                    <Badge className="bg-green-500/20 text-green-300 border-green-500">
                      R$ {opt.potential_savings.toLocaleString("pt-BR")} economia
                    </Badge>
                  </div>
                </div>
                <p className="text-sm text-green-200 mb-2">{opt.action_plan}</p>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <span className="text-green-300">Gasto Atual:</span>
                    <span className="text-white ml-1 font-semibold">R$ {opt.current_spending.toLocaleString("pt-BR")}</span>
                  </div>
                  <div>
                    <span className="text-green-300">Orçamento Ideal:</span>
                    <span className="text-white ml-1 font-semibold">R$ {opt.suggested_budget.toLocaleString("pt-BR")}</span>
                  </div>
                  <div>
                    <span className="text-green-300">Dificuldade:</span>
                    <span className="text-white ml-1 font-semibold">{opt.implementation_difficulty}</span>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <Card className="border-blue-500/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-blue-400" />
              Análise Executiva Textual
            </CardTitle>
            <div className="flex gap-2">
              <Button
                onClick={generatePredictiveAnalysis}
                disabled={loadingAI}
                className="bg-gradient-to-r from-purple-600 to-purple-500"
              >
                <Sparkles className={`w-4 h-4 mr-2 ${loadingAI ? 'animate-spin' : ''}`} />
                Análise Preditiva
              </Button>
              <Button
                onClick={generateAIAnalysis}
                disabled={loadingAI}
                className="bg-gradient-to-r from-blue-600 to-blue-500"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${loadingAI ? 'animate-spin' : ''}`} />
                Análise Executiva
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loadingAI ? (
            <div className="text-center py-8">
              <RefreshCw className="w-8 h-8 animate-spin text-blue-400 mx-auto mb-3" />
              <p className="text-blue-300">Analisando dados...</p>
            </div>
          ) : aiAnalysis ? (
            <div className="prose prose-invert max-w-none text-sm whitespace-pre-wrap text-blue-100">
              {aiAnalysis}
            </div>
          ) : (
            <p className="text-blue-300 text-center py-8">Clique para gerar análises</p>
          )}
        </CardContent>
      </Card>

      {/* GRÁFICOS */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 bg-blue-950/50">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="categories">Por Categoria</TabsTrigger>
          <TabsTrigger value="costcenter">Por Centro Custo</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
            <CardHeader>
              <CardTitle className="text-white">Evolução Últimos 6 Meses</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={evolucaoMensal}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
                  <XAxis dataKey="month" stroke="#93c5fd" />
                  <YAxis stroke="#93c5fd" />
                  <Tooltip contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px", color: "#fff" }} />
                  <Legend />
                  <Line type="monotone" dataKey="receitas" stroke="#10B981" strokeWidth={3} name="Receitas" />
                  <Line type="monotone" dataKey="despesas" stroke="#EF4444" strokeWidth={3} name="Despesas" />
                  <Line type="monotone" dataKey="saldo" stroke="#3B82F6" strokeWidth={3} name="Saldo" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories">
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
            <CardHeader>
              <CardTitle className="text-white">Despesas por Categoria</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={categoriasChart}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
                  <XAxis dataKey="name" stroke="#93c5fd" angle={-45} textAnchor="end" height={120} />
                  <YAxis stroke="#93c5fd" />
                  <Tooltip contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px", color: "#fff" }} />
                  <Bar dataKey="value" fill="#EF4444" name="Valor" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="costcenter">
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
            <CardHeader>
              <CardTitle className="text-white">Despesas por Centro de Custo</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <PieChart>
                  <Pie
                    data={centroCustoChart}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={120}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {centroCustoChart.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px", color: "#fff" }} />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}