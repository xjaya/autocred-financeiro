import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  Settings as SettingsIcon,
  Upload,
  Sparkles,
  Shield,
  Bell,
  Palette,
  Save,
  Image as ImageIcon,
  CheckCircle,
  Brain,
  TrendingUp,
  AlertTriangle,
  Target,
  Calculator,
  Users,
  DollarSign,
  FileText,
  Search,
  Clock,
  Database,
  Zap,
  Globe,
  RefreshCw,
  Lock
} from "lucide-react";
import { toast } from "sonner";

export default function Settings() {
  const [uploading, setUploading] = useState(false);
  const [logoPreview, setLogoPreview] = useState(null);
  const [saving, setSaving] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [backupProgress, setBackupProgress] = useState(0);

  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useQuery({
    queryKey: ["companySettings"],
    queryFn: async () => {
      const list = await base44.entities.CompanySettings.list();
      return list[0] || null;
    },
    initialData: null,
  });

  const updateMutation = useMutation({
    mutationFn: async (data) => {
      if (settings?.id) {
        return await base44.entities.CompanySettings.update(settings.id, data);
      } else {
        return await base44.entities.CompanySettings.create(data);
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["companySettings"] });
      
      // Aplicar cores em tempo real
      if (data.primary_color) {
        document.documentElement.style.setProperty('--primary', data.primary_color);
      }
      if (data.secondary_color) {
        document.documentElement.style.setProperty('--secondary', data.secondary_color);
      }
      if (data.background_color) {
        document.body.style.background = data.background_color;
      }
      
      setSaving(false);
      alert("✅ Configurações salvas com sucesso!");
    },
  });

  useEffect(() => {
    if (settings?.logo_url) {
      setLogoPreview(settings.logo_url);
    }
  }, [settings]);

  const handleLogoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setLogoPreview(file_url);
      await updateMutation.mutateAsync({
        ...settings,
        logo_url: file_url,
      });
    } catch (error) {
      console.error("Erro ao fazer upload:", error);
      alert("❌ Erro ao fazer upload do logo");
    }
    setUploading(false);
  };

  const handleSave = async (section, data) => {
    setSaving(true);
    await updateMutation.mutateAsync({
      ...settings,
      ...data,
    });
  };

  const downloadCompleteDatabase = async (format = 'json') => {
    setDownloading(true);
    setBackupProgress(0);
    toast.info("📦 Preparando backup completo do banco de dados...");

    try {
      // Buscar todos os dados
      setBackupProgress(10);
      const [transactions, contacts, categories, costCenters, bankAccounts, goals, transfers, contracts, notifications, reports] = await Promise.all([
        base44.entities.Transaction.list(),
        base44.entities.Client.list(),
        base44.entities.Category.list(),
        base44.entities.CostCenter.list(),
        base44.entities.BankAccount.list(),
        base44.entities.Goal.list(),
        base44.entities.Transfer.list(),
        base44.entities.Contract.list(),
        base44.entities.Notification.list(),
        base44.entities.Report.list(),
      ]);

      setBackupProgress(50);

      const backup = {
        info: {
          sistema: settings?.company_name || "AUTOCRED PROMOTORA",
          data_backup: new Date().toISOString(),
          total_transacoes: transactions.length,
          total_contatos: contacts.length,
          localizacao: "Base44 Cloud Database",
          servidor: "https://api.base44.com",
        },
        transactions,
        contacts,
        categories,
        costCenters,
        bankAccounts,
        goals,
        transfers,
        contracts,
        notifications,
        reports
      };

      setBackupProgress(80);

      if (format === 'csv') {
        // CSV com todas as transações
        const csvContent = [
          ['Data', 'Tipo', 'Descrição', 'Categoria', 'Valor', 'Status', 'Conta'].join(';'),
          ...transactions.map(t => [
            t.due_date,
            t.type,
            t.description,
            t.category || '',
            t.amount,
            t.status,
            t.bank_account || ''
          ].join(';'))
        ].join('\n');
        
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `backup_transacoes_${new Date().toISOString().split('T')[0]}.csv`;
        link.click();
      } else {
        // JSON completo
        const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `backup_completo_${new Date().toISOString().split('T')[0]}.json`;
        link.click();
      }

      setBackupProgress(100);
      toast.success(`✅ Backup completo baixado em ${format.toUpperCase()}!`);
    } catch (error) {
      console.error("Erro no backup:", error);
      toast.error("❌ Erro ao gerar backup");
    }

    setDownloading(false);
    setBackupProgress(0);
  };

  const aiFeatures = [
    {
      id: "ai_auto_categorization",
      title: "Categorização Automática",
      description: "IA categoriza transações automaticamente",
      icon: Brain,
      color: "text-purple-400",
    },
    {
      id: "ai_fraud_detection",
      title: "Detecção de Fraudes",
      description: "Identifica transações suspeitas em tempo real",
      icon: Shield,
      color: "text-red-400",
    },
    {
      id: "ai_cashflow_prediction",
      title: "Previsão de Fluxo de Caixa",
      description: "Prevê entradas e saídas futuras",
      icon: TrendingUp,
      color: "text-green-400",
    },
    {
      id: "ai_spending_insights",
      title: "Insights de Gastos",
      description: "Análise inteligente de padrões de despesas",
      icon: Search,
      color: "text-blue-400",
    },
    {
      id: "ai_budget_optimization",
      title: "Otimização de Orçamento",
      description: "Sugestões para otimizar alocação de recursos",
      icon: Target,
      color: "text-yellow-400",
    },
    {
      id: "ai_tax_optimization",
      title: "Otimização Fiscal",
      description: "Recomendações para economia de impostos",
      icon: Calculator,
      color: "text-indigo-400",
    },
    {
      id: "ai_supplier_analysis",
      title: "Análise de Fornecedores",
      description: "Avalia desempenho e confiabilidade",
      icon: Users,
      color: "text-orange-400",
    },
    {
      id: "ai_customer_insights",
      title: "Insights de Clientes",
      description: "Análise de comportamento e lucratividade",
      icon: DollarSign,
      color: "text-teal-400",
    },
    {
      id: "ai_anomaly_detection",
      title: "Detecção de Anomalias",
      description: "Identifica padrões incomuns nas finanças",
      icon: AlertTriangle,
      color: "text-red-400",
    },
    {
      id: "ai_investment_recommendations",
      title: "Recomendações de Investimento",
      description: "Sugestões baseadas em análise financeira",
      icon: TrendingUp,
      color: "text-green-400",
    },
  ];

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="flex items-center justify-center h-64">
          <Sparkles className="w-8 h-8 text-blue-400 animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex items-center gap-3">
        <SettingsIcon className="w-8 h-8 text-blue-400" />
        <div>
          <h1 className="text-4xl font-bold text-white drop-shadow-lg">Configurações</h1>
          <p className="text-blue-200 mt-1">Personalize e configure sua plataforma</p>
        </div>
      </div>

      <Tabs defaultValue="company" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-7 h-auto bg-blue-950/50">
          <TabsTrigger value="company" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white text-xs md:text-sm">
            <ImageIcon className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
            Empresa
          </TabsTrigger>
          <TabsTrigger value="ai" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white text-xs md:text-sm">
            <Sparkles className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
            IA
          </TabsTrigger>
          <TabsTrigger value="notifications" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white text-xs md:text-sm">
            <Bell className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
            Notif.
          </TabsTrigger>
          <TabsTrigger value="appearance" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white text-xs md:text-sm">
            <Palette className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
            Visual
          </TabsTrigger>
          <TabsTrigger value="security" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white text-xs md:text-sm">
            <Shield className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
            Segur.
          </TabsTrigger>
          <TabsTrigger value="integrations" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white text-xs md:text-sm">
            <Database className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
            Integr.
          </TabsTrigger>
          <TabsTrigger value="advanced" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white text-xs md:text-sm">
            <Zap className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
            Avançado
          </TabsTrigger>
        </TabsList>

        {/* Aba Empresa */}
        <TabsContent value="company">
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
            <CardHeader>
              <CardTitle className="text-white">Informações da Empresa</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Upload de Logo */}
              <div className="space-y-3">
                <Label className="text-blue-200">Logo da Empresa</Label>
                <div className="flex items-center gap-6">
                  <div className="w-32 h-32 bg-blue-950/50 border-2 border-dashed border-blue-700 rounded-lg flex items-center justify-center overflow-hidden">
                    {logoPreview ? (
                      <img src={logoPreview} alt="Logo" className="w-full h-full object-contain p-2" />
                    ) : (
                      <ImageIcon className="w-12 h-12 text-blue-400 opacity-50" />
                    )}
                  </div>
                  <div>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="hidden"
                      id="logo-upload"
                    />
                    <label htmlFor="logo-upload" className="cursor-pointer">
                     <div
                       className={`inline-flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600 text-white rounded-lg font-medium transition-all ${uploading ? 'opacity-50 cursor-not-allowed' : ''}`}
                     >
                       <Upload className={`w-4 h-4 ${uploading ? "animate-spin" : ""}`} />
                       {uploading ? "Enviando..." : "Upload Logo"}
                     </div>
                    </label>
                    <p className="text-xs text-blue-300 mt-2">PNG, JPG ou SVG (máx. 2MB)</p>
                  </div>
                </div>
              </div>

              <Separator className="bg-blue-700/50" />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Nome da Empresa</Label>
                  <Input
                    defaultValue={settings?.company_name}
                    onBlur={(e) => handleSave("company", { company_name: e.target.value })}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">CNPJ</Label>
                  <Input
                    defaultValue={settings?.cnpj}
                    onBlur={(e) => handleSave("company", { cnpj: e.target.value })}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Email</Label>
                  <Input
                    defaultValue={settings?.email}
                    type="email"
                    onBlur={(e) => handleSave("company", { email: e.target.value })}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Telefone</Label>
                  <Input
                    defaultValue={settings?.phone}
                    onBlur={(e) => handleSave("company", { phone: e.target.value })}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label className="text-blue-200">Endereço</Label>
                  <Input
                    defaultValue={settings?.address}
                    onBlur={(e) => handleSave("company", { address: e.target.value })}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Website</Label>
                  <Input
                    defaultValue={settings?.website}
                    onBlur={(e) => handleSave("company", { website: e.target.value })}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Taxa de Comissão Padrão (%)</Label>
                  <Input
                    type="number"
                    step="0.1"
                    defaultValue={settings?.default_commission_rate}
                    onBlur={(e) => handleSave("company", { default_commission_rate: parseFloat(e.target.value) })}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Aba IA - 10 Funcionalidades Inteligentes */}
        <TabsContent value="ai">
          <Card className="border-purple-700/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-purple-400" />
                Funcionalidades Inteligentes de IA
              </CardTitle>
              <p className="text-sm text-purple-200 mt-2">
                Configure as análises e automações baseadas em inteligência artificial
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-purple-950/30 border border-purple-700 rounded-lg p-4 mb-6">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-purple-400 mt-0.5" />
                  <div>
                    <p className="text-white font-medium">IA Ativada Globalmente</p>
                    <p className="text-sm text-purple-300 mt-1">
                      Todas as funcionalidades de IA estão ativas. Desative individualmente abaixo.
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {aiFeatures.map((feature) => (
                  <Card key={feature.id} className="bg-blue-950/50 border-blue-700 hover:border-purple-500 transition-all">
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-3 flex-1">
                          <feature.icon className={`w-6 h-6 ${feature.color} mt-1`} />
                          <div className="flex-1">
                            <h4 className="text-white font-medium">{feature.title}</h4>
                            <p className="text-xs text-blue-300 mt-1">{feature.description}</p>
                          </div>
                        </div>
                        <Switch
                          checked={settings?.[feature.id] !== false}
                          onCheckedChange={(checked) => {
                            handleSave("ai", { [feature.id]: checked });
                          }}
                        />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Separator className="bg-purple-700/50 my-6" />

              <div className="space-y-3">
                <Label className="text-purple-200">Frequência de Análises Automáticas</Label>
                <select
                  defaultValue={settings?.ai_suggestions_frequency || "diaria"}
                  onChange={(e) => handleSave("ai", { ai_suggestions_frequency: e.target.value })}
                  className="w-full bg-blue-950/50 border border-blue-700 rounded-lg px-4 py-2 text-white"
                >
                  <option value="manual">Manual (sob demanda)</option>
                  <option value="diaria">Diária</option>
                  <option value="semanal">Semanal</option>
                  <option value="mensal">Mensal</option>
                </select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Aba Notificações e WhatsApp */}
        <TabsContent value="notifications">
          <div className="space-y-6">
            <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
              <CardHeader>
                <CardTitle className="text-white">Preferências de Notificações</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Notificações por Email</p>
                    <p className="text-sm text-blue-300">Receba alertas importantes por email</p>
                  </div>
                  <Switch
                    checked={settings?.email_notifications_enabled !== false}
                    onCheckedChange={(checked) => handleSave("notifications", { email_notifications_enabled: checked })}
                  />
                </div>

                <Separator className="bg-blue-700/50" />

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Notificações por WhatsApp</p>
                    <p className="text-sm text-blue-300">Receba alertas via WhatsApp</p>
                  </div>
                  <Switch
                    checked={settings?.whatsapp_notifications_enabled !== false}
                    onCheckedChange={(checked) => handleSave("notifications", { whatsapp_notifications_enabled: checked })}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Configurações WhatsApp */}
            {settings?.whatsapp_notifications_enabled && (
              <Card className="border-green-700/50 bg-gradient-to-br from-green-900/80 to-green-800/80">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                    </svg>
                    Configurações de Relatórios WhatsApp
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    <Label className="text-green-200 font-medium">Número WhatsApp (com DDI)</Label>
                    <Input
                      type="tel"
                      placeholder="Ex: 5511999999999"
                      defaultValue={settings?.whatsapp_number || ""}
                      onBlur={(e) => handleSave("notifications", { whatsapp_number: e.target.value })}
                      className="bg-green-950/50 border-green-700 text-white"
                    />
                    <p className="text-xs text-green-300">Formato: 55 + DDD + Número (sem espaços ou caracteres)</p>
                  </div>

                  <Separator className="bg-green-700/50" />

                  <div className="space-y-4">
                    <h3 className="text-white font-semibold">Relatórios Automáticos</h3>
                    
                    <div className="space-y-3 bg-green-950/30 p-4 rounded-lg border border-green-700">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-white font-medium">Contas a Pagar Vencendo</p>
                          <p className="text-xs text-green-300">Alerta de despesas próximas do vencimento</p>
                        </div>
                        <Switch
                          checked={settings?.whatsapp_bills_to_pay !== false}
                          onCheckedChange={(checked) => handleSave("notifications", { whatsapp_bills_to_pay: checked })}
                        />
                      </div>
                      {settings?.whatsapp_bills_to_pay !== false && (
                        <div>
                          <Label className="text-green-200 text-xs">Antecedência (dias)</Label>
                          <Input
                            type="number"
                            min="1"
                            max="30"
                            defaultValue={settings?.whatsapp_bills_days || 3}
                            onBlur={(e) => handleSave("notifications", { whatsapp_bills_days: parseInt(e.target.value) || 3 })}
                            className="w-24 bg-green-950/50 border-green-700 text-white text-sm"
                          />
                        </div>
                      )}
                    </div>

                    <div className="space-y-3 bg-green-950/30 p-4 rounded-lg border border-green-700">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-white font-medium">Contas a Receber Vencendo</p>
                          <p className="text-xs text-green-300">Alerta de receitas próximas</p>
                        </div>
                        <Switch
                          checked={settings?.whatsapp_bills_to_receive !== false}
                          onCheckedChange={(checked) => handleSave("notifications", { whatsapp_bills_to_receive: checked })}
                        />
                      </div>
                      {settings?.whatsapp_bills_to_receive !== false && (
                        <div>
                          <Label className="text-green-200 text-xs">Antecedência (dias)</Label>
                          <Input
                            type="number"
                            min="1"
                            max="30"
                            defaultValue={settings?.whatsapp_receive_days || 3}
                            onBlur={(e) => handleSave("notifications", { whatsapp_receive_days: parseInt(e.target.value) || 3 })}
                            className="w-24 bg-green-950/50 border-green-700 text-white text-sm"
                          />
                        </div>
                      )}
                    </div>

                    <div className="space-y-3 bg-green-950/30 p-4 rounded-lg border border-green-700">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-white font-medium">Resumo Diário</p>
                          <p className="text-xs text-green-300">Relatório com receitas e despesas do dia</p>
                        </div>
                        <Switch
                          checked={settings?.whatsapp_daily_summary !== false}
                          onCheckedChange={(checked) => handleSave("notifications", { whatsapp_daily_summary: checked })}
                        />
                      </div>
                      {settings?.whatsapp_daily_summary !== false && (
                        <div>
                          <Label className="text-green-200 text-xs">Horário de Envio</Label>
                          <Input
                            type="time"
                            defaultValue={settings?.whatsapp_daily_time || "18:00"}
                            onBlur={(e) => handleSave("notifications", { whatsapp_daily_time: e.target.value })}
                            className="w-32 bg-green-950/50 border-green-700 text-white text-sm"
                          />
                        </div>
                      )}
                    </div>

                    <div className="space-y-3 bg-green-950/30 p-4 rounded-lg border border-green-700">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-white font-medium">Resumo Semanal</p>
                          <p className="text-xs text-green-300">Relatório semanal de finanças</p>
                        </div>
                        <Switch
                          checked={settings?.whatsapp_weekly_summary !== false}
                          onCheckedChange={(checked) => handleSave("notifications", { whatsapp_weekly_summary: checked })}
                        />
                      </div>
                      {settings?.whatsapp_weekly_summary !== false && (
                        <div>
                          <Label className="text-green-200 text-xs">Dia da Semana</Label>
                          <select
                            defaultValue={settings?.whatsapp_weekly_day || "friday"}
                            onChange={(e) => handleSave("notifications", { whatsapp_weekly_day: e.target.value })}
                            className="w-full bg-green-950/50 border border-green-700 rounded-lg px-3 py-1.5 text-white text-sm"
                          >
                            <option value="monday">Segunda-feira</option>
                            <option value="tuesday">Terça-feira</option>
                            <option value="wednesday">Quarta-feira</option>
                            <option value="thursday">Quinta-feira</option>
                            <option value="friday">Sexta-feira</option>
                            <option value="saturday">Sábado</option>
                            <option value="sunday">Domingo</option>
                          </select>
                        </div>
                      )}
                    </div>

                    <div className="space-y-3 bg-green-950/30 p-4 rounded-lg border border-green-700">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-white font-medium">Resumo Mensal</p>
                          <p className="text-xs text-green-300">Relatório mensal completo</p>
                        </div>
                        <Switch
                          checked={settings?.whatsapp_monthly_summary !== false}
                          onCheckedChange={(checked) => handleSave("notifications", { whatsapp_monthly_summary: checked })}
                        />
                      </div>
                      {settings?.whatsapp_monthly_summary !== false && (
                        <div>
                          <Label className="text-green-200 text-xs">Dia do Mês</Label>
                          <Input
                            type="number"
                            min="1"
                            max="28"
                            defaultValue={settings?.whatsapp_monthly_day || 1}
                            onBlur={(e) => handleSave("notifications", { whatsapp_monthly_day: parseInt(e.target.value) || 1 })}
                            className="w-24 bg-green-950/50 border-green-700 text-white text-sm"
                          />
                        </div>
                      )}
                    </div>

                    <div className="space-y-3 bg-green-950/30 p-4 rounded-lg border border-green-700">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-white font-medium">Alertas de Saldo Baixo</p>
                          <p className="text-xs text-green-300">Notificação quando saldo estiver baixo</p>
                        </div>
                        <Switch
                          checked={settings?.whatsapp_low_balance !== false}
                          onCheckedChange={(checked) => handleSave("notifications", { whatsapp_low_balance: checked })}
                        />
                      </div>
                      {settings?.whatsapp_low_balance !== false && (
                        <div>
                          <Label className="text-green-200 text-xs">Valor Mínimo (R$)</Label>
                          <Input
                            type="number"
                            min="0"
                            step="100"
                            defaultValue={settings?.whatsapp_balance_threshold || 1000}
                            onBlur={(e) => handleSave("notifications", { whatsapp_balance_threshold: parseFloat(e.target.value) || 1000 })}
                            className="w-32 bg-green-950/50 border-green-700 text-white text-sm"
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  <Separator className="bg-green-700/50" />

                  <Button
                    onClick={async () => {
                      if (!settings?.whatsapp_number) {
                        toast.error("❌ Configure o número WhatsApp primeiro");
                        return;
                      }
                      
                      setSaving(true);
                      toast.info("💾 Salvando configurações...");
                      
                      try {
                        // Salvar todas as configurações de WhatsApp
                        await updateMutation.mutateAsync({
                          ...settings,
                          whatsapp_number: settings.whatsapp_number,
                          whatsapp_notifications_enabled: settings.whatsapp_notifications_enabled,
                          whatsapp_bills_to_pay: settings.whatsapp_bills_to_pay,
                          whatsapp_bills_days: settings.whatsapp_bills_days,
                          whatsapp_bills_to_receive: settings.whatsapp_bills_to_receive,
                          whatsapp_receive_days: settings.whatsapp_receive_days,
                          whatsapp_daily_summary: settings.whatsapp_daily_summary,
                          whatsapp_daily_time: settings.whatsapp_daily_time,
                          whatsapp_weekly_summary: settings.whatsapp_weekly_summary,
                          whatsapp_weekly_day: settings.whatsapp_weekly_day,
                          whatsapp_monthly_summary: settings.whatsapp_monthly_summary,
                          whatsapp_monthly_day: settings.whatsapp_monthly_day,
                          whatsapp_low_balance: settings.whatsapp_low_balance,
                          whatsapp_balance_threshold: settings.whatsapp_balance_threshold,
                        });
                        
                        // Enviar email de confirmação
                        await base44.integrations.Core.SendEmail({
                          to: settings.email || "admin@autocred.com",
                          subject: "✅ Configurações WhatsApp Salvas - Relatórios Automáticos",
                          body: `Configurações de WhatsApp salvas com sucesso!

📱 Número WhatsApp: ${settings.whatsapp_number}

📊 Relatórios Ativos:
- Contas a Pagar: ${settings.whatsapp_bills_to_pay !== false ? `✅ Ativo (${settings.whatsapp_bills_days || 3} dias antes)` : '❌ Inativo'}
- Contas a Receber: ${settings.whatsapp_bills_to_receive !== false ? `✅ Ativo (${settings.whatsapp_receive_days || 3} dias antes)` : '❌ Inativo'}
- Resumo Diário: ${settings.whatsapp_daily_summary !== false ? `✅ Ativo (${settings.whatsapp_daily_time || '18:00'})` : '❌ Inativo'}
- Resumo Semanal: ${settings.whatsapp_weekly_summary !== false ? `✅ Ativo (${settings.whatsapp_weekly_day || 'friday'})` : '❌ Inativo'}
- Resumo Mensal: ${settings.whatsapp_monthly_summary !== false ? `✅ Ativo (dia ${settings.whatsapp_monthly_day || 1})` : '❌ Inativo'}
- Saldo Baixo: ${settings.whatsapp_low_balance !== false ? `✅ Ativo (R$ ${settings.whatsapp_balance_threshold || 1000})` : '❌ Inativo'}

Os relatórios serão enviados automaticamente conforme configurado.

--
Sistema Financeiro - ${settings.company_name || 'AUTOCRED PROMOTORA'}`
                        });
                        
                        toast.success("✅ Configurações salvas! Relatórios automáticos ativados.");
                      } catch (error) {
                        console.error("Erro ao salvar:", error);
                        toast.error("❌ Erro ao salvar configurações");
                      }
                      
                      setSaving(false);
                    }}
                    disabled={saving}
                    className="w-full bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600"
                  >
                    {saving ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        Salvando...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Salvar Configurações WhatsApp
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Aba Aparência - 10 Funcionalidades */}
        <TabsContent value="appearance">
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Palette className="w-6 h-6 text-blue-400" />
                Personalização Visual do Sistema
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label className="text-blue-200 flex items-center gap-2">
                    <Palette className="w-4 h-4" />
                    Cor Primária do Sistema
                  </Label>
                  <Input
                    type="color"
                    defaultValue={settings?.primary_color || "#1e3a8a"}
                    onChange={(e) => {
                      document.documentElement.style.setProperty('--primary', e.target.value);
                      handleSave("appearance", { primary_color: e.target.value });
                    }}
                    className="h-16 w-full bg-blue-950/50 border-blue-700 cursor-pointer"
                  />
                  <p className="text-xs text-blue-300">Cor principal dos botões, links e elementos</p>
                </div>

                <div className="space-y-3">
                  <Label className="text-blue-200 flex items-center gap-2">
                    <Palette className="w-4 h-4" />
                    Cor Secundária
                  </Label>
                  <Input
                    type="color"
                    defaultValue={settings?.secondary_color || "#059669"}
                    onChange={(e) => {
                      document.documentElement.style.setProperty('--secondary', e.target.value);
                      handleSave("appearance", { secondary_color: e.target.value });
                    }}
                    className="h-16 w-full bg-blue-950/50 border-blue-700 cursor-pointer"
                  />
                  <p className="text-xs text-blue-300">Cor de destaques e elementos secundários</p>
                </div>

                <div className="space-y-3">
                  <Label className="text-blue-200 flex items-center gap-2">
                    <Palette className="w-4 h-4" />
                    Cor de Sucesso
                  </Label>
                  <Input
                    type="color"
                    defaultValue={settings?.success_color || "#10b981"}
                    onChange={(e) => handleSave("appearance", { success_color: e.target.value })}
                    className="h-16 w-full bg-blue-950/50 border-blue-700 cursor-pointer"
                  />
                  <p className="text-xs text-blue-300">Cor de mensagens positivas e receitas</p>
                </div>

                <div className="space-y-3">
                  <Label className="text-blue-200 flex items-center gap-2">
                    <Palette className="w-4 h-4" />
                    Cor de Erro/Despesa
                  </Label>
                  <Input
                    type="color"
                    defaultValue={settings?.error_color || "#ef4444"}
                    onChange={(e) => handleSave("appearance", { error_color: e.target.value })}
                    className="h-16 w-full bg-blue-950/50 border-blue-700 cursor-pointer"
                  />
                  <p className="text-xs text-blue-300">Cor de alertas e despesas</p>
                </div>

                <div className="space-y-3">
                  <Label className="text-blue-200 flex items-center gap-2">
                    <Palette className="w-4 h-4" />
                    Cor de Alerta
                  </Label>
                  <Input
                    type="color"
                    defaultValue={settings?.warning_color || "#f59e0b"}
                    onChange={(e) => handleSave("appearance", { warning_color: e.target.value })}
                    className="h-16 w-full bg-blue-950/50 border-blue-700 cursor-pointer"
                  />
                  <p className="text-xs text-blue-300">Cor de avisos e pendências</p>
                </div>

                <div className="space-y-3">
                  <Label className="text-blue-200 flex items-center gap-2">
                    <Palette className="w-4 h-4" />
                    Cor do Fundo
                  </Label>
                  <Input
                    type="color"
                    defaultValue={settings?.background_color || "#001F3F"}
                    onChange={(e) => {
                      document.body.style.background = e.target.value;
                      handleSave("appearance", { background_color: e.target.value });
                    }}
                    className="h-16 w-full bg-blue-950/50 border-blue-700 cursor-pointer"
                  />
                  <p className="text-xs text-blue-300">Cor de fundo principal do sistema</p>
                </div>
              </div>

              <Separator className="bg-blue-700/50" />

              <div className="space-y-4">
                <h3 className="text-white font-medium flex items-center gap-2">
                  <Zap className="w-5 h-5 text-yellow-400" />
                  Configurações Visuais Adicionais
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between bg-blue-950/50 p-4 rounded-lg">
                    <div>
                      <p className="text-white font-medium">Modo Escuro Forçado</p>
                      <p className="text-xs text-blue-300">Sempre usar tema escuro</p>
                    </div>
                    <Switch
                      checked={settings?.dark_mode_forced !== false}
                      onCheckedChange={(checked) => handleSave("appearance", { dark_mode_forced: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between bg-blue-950/50 p-4 rounded-lg">
                    <div>
                      <p className="text-white font-medium">Animações</p>
                      <p className="text-xs text-blue-300">Ativar transições animadas</p>
                    </div>
                    <Switch
                      checked={settings?.animations_enabled !== false}
                      onCheckedChange={(checked) => handleSave("appearance", { animations_enabled: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between bg-blue-950/50 p-4 rounded-lg">
                    <div>
                      <p className="text-white font-medium">Efeitos de Vidro</p>
                      <p className="text-xs text-blue-300">Blur e transparência nos cards</p>
                    </div>
                    <Switch
                      checked={settings?.glass_effects !== false}
                      onCheckedChange={(checked) => handleSave("appearance", { glass_effects: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between bg-blue-950/50 p-4 rounded-lg">
                    <div>
                      <p className="text-white font-medium">Sombras Realçadas</p>
                      <p className="text-xs text-blue-300">Sombras mais pronunciadas</p>
                    </div>
                    <Switch
                      checked={settings?.enhanced_shadows !== false}
                      onCheckedChange={(checked) => handleSave("appearance", { enhanced_shadows: checked })}
                    />
                  </div>
                </div>
              </div>

              <Separator className="bg-blue-700/50" />

              <div className="bg-blue-950/50 p-4 rounded-lg border border-blue-700">
                <p className="text-white font-medium mb-2 flex items-center gap-2">
                  <Globe className="w-4 h-4" />
                  Pré-visualização das Cores
                </p>
                <div className="flex gap-2 flex-wrap">
                  <div className="px-4 py-2 rounded-lg text-white font-medium" style={{ background: settings?.primary_color || '#1e3a8a' }}>
                    Primária
                  </div>
                  <div className="px-4 py-2 rounded-lg text-white font-medium" style={{ background: settings?.secondary_color || '#059669' }}>
                    Secundária
                  </div>
                  <div className="px-4 py-2 rounded-lg text-white font-medium" style={{ background: settings?.success_color || '#10b981' }}>
                    Sucesso
                  </div>
                  <div className="px-4 py-2 rounded-lg text-white font-medium" style={{ background: settings?.error_color || '#ef4444' }}>
                    Erro
                  </div>
                  <div className="px-4 py-2 rounded-lg text-white font-medium" style={{ background: settings?.warning_color || '#f59e0b' }}>
                    Alerta
                  </div>
                </div>
              </div>

              <Button
                onClick={() => {
                  handleSave("appearance", {
                    primary_color: "#1e3a8a",
                    secondary_color: "#059669",
                    success_color: "#10b981",
                    error_color: "#ef4444",
                    warning_color: "#f59e0b",
                    background_color: "#001F3F"
                  });
                  window.location.reload();
                }}
                variant="outline"
                className="w-full border-blue-700 text-blue-200 hover:bg-blue-800"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Restaurar Cores Padrão
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Aba Segurança */}
        <TabsContent value="security">
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Shield className="w-6 h-6 text-blue-400" />
                Segurança e Autenticação
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* AUTENTICAÇÃO DE ACESSO */}
              <div className="bg-blue-950/50 border border-blue-700 rounded-lg p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-bold text-lg flex items-center gap-2">
                      <Lock className="w-5 h-5 text-yellow-400" />
                      Exigir Login no Sistema
                    </p>
                    <p className="text-sm text-blue-300 mt-1">Protege o acesso ao sistema com usuário e senha</p>
                  </div>
                  <div className="flex items-center gap-3">
                    {saving && (
                      <div className="text-blue-300 text-sm flex items-center gap-2">
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        Salvando...
                      </div>
                    )}
                    <Switch
                      checked={settings?.require_auth === true}
                      disabled={saving}
                      onCheckedChange={async (checked) => {
                        try {
                          setSaving(true);
                          await updateMutation.mutateAsync({
                            ...settings,
                            require_auth: checked
                          });
                          setSaving(false);
                          if (checked) {
                            toast.success("🔒 Autenticação ativada! Recarregue a página.");
                            setTimeout(() => window.location.reload(), 1500);
                          } else {
                            localStorage.removeItem("app_authenticated");
                            toast.success("✅ Autenticação desativada!");
                            setTimeout(() => window.location.reload(), 1500);
                          }
                        } catch (error) {
                          console.error("Erro:", error);
                          setSaving(false);
                          toast.error("Erro ao salvar configuração");
                        }
                      }}
                    />
                  </div>
                </div>

                {settings?.require_auth && (
                  <>
                    <Separator className="bg-blue-700/50" />

                    <div className="space-y-3">
                      <Label className="text-blue-200 font-medium">Usuário de Acesso</Label>
                      <Input
                        type="text"
                        placeholder="Digite o usuário (padrão: admin)"
                        defaultValue={settings?.auth_username || "admin"}
                        onBlur={async (e) => {
                          try {
                            await updateMutation.mutateAsync({
                              ...settings,
                              auth_username: e.target.value || "admin"
                            });
                            toast.success("✅ Usuário salvo!");
                          } catch (error) {
                            toast.error("Erro ao salvar");
                          }
                        }}
                        className="bg-blue-950/50 border-blue-700 text-white"
                      />
                    </div>

                    <div className="space-y-3">
                      <Label className="text-blue-200 font-medium">Senha de Acesso</Label>
                      <Input
                        type="password"
                        placeholder="Digite a senha (padrão: 1020)"
                        defaultValue={settings?.auth_password || ""}
                        onBlur={async (e) => {
                          try {
                            await updateMutation.mutateAsync({
                              ...settings,
                              auth_password: e.target.value || "1020"
                            });
                            toast.success("✅ Senha salva!");
                          } catch (error) {
                            toast.error("Erro ao salvar");
                          }
                        }}
                        className="bg-blue-950/50 border-blue-700 text-white"
                      />
                      <p className="text-xs text-blue-300">
                        Deixe vazio para usar senha padrão: <span className="font-mono">1020</span>
                      </p>
                    </div>

                    <div className="bg-yellow-950/30 border border-yellow-700 rounded-lg p-4 mt-4">
                      <div className="flex gap-3">
                        <AlertTriangle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="text-yellow-200 font-medium text-sm">Importante:</p>
                          <p className="text-yellow-300 text-xs mt-1">
                            Guarde suas credenciais em local seguro. Sem elas, você não conseguirá acessar o sistema.
                          </p>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>

              <Separator className="bg-blue-700/50" />

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-medium">Autenticação de Dois Fatores (2FA)</p>
                  <p className="text-sm text-blue-300">Adiciona camada extra de segurança</p>
                </div>
                <Switch
                  checked={settings?.two_factor_auth_enabled === true}
                  onCheckedChange={(checked) => handleSave("security", { two_factor_auth_enabled: checked })}
                />
              </div>

              <Separator className="bg-blue-700/50" />

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-medium">Backup Automático</p>
                  <p className="text-sm text-blue-300">Backup diário dos seus dados</p>
                </div>
                <Switch
                  checked={settings?.auto_backup_enabled !== false}
                  onCheckedChange={(checked) => handleSave("security", { auto_backup_enabled: checked })}
                />
              </div>

              <Separator className="bg-blue-700/50" />

              <div>
                <Label className="text-blue-200">Retenção de Dados (dias)</Label>
                <Input
                  type="number"
                  defaultValue={settings?.data_retention_days || 1825}
                  onBlur={(e) => handleSave("security", { data_retention_days: parseInt(e.target.value) })}
                  className="bg-blue-950/50 border-blue-700 text-white"
                />
                <p className="text-xs text-blue-300 mt-1">Padrão: 1825 dias (5 anos)</p>
              </div>

              <Separator className="bg-blue-700/50" />

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-medium">Sessão Automática</p>
                  <p className="text-sm text-blue-300">Tempo para logout automático (minutos)</p>
                </div>
                <Input
                  type="number"
                  min="5"
                  max="1440"
                  defaultValue={settings?.session_timeout || 480}
                  onBlur={(e) => handleSave("security", { session_timeout: parseInt(e.target.value) || 480 })}
                  className="w-24 bg-blue-950/50 border-blue-700 text-white"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Aba Integrações */}
        <TabsContent value="integrations">
          <div className="space-y-6">
            {/* BACKUP E BANCO DE DADOS */}
            <Card className="border-green-700/50 bg-gradient-to-br from-green-900/80 to-green-800/80">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Database className="w-6 h-6 text-green-400" />
                  Backup e Banco de Dados
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-green-950/30 border border-green-700 rounded-lg p-6">
                  <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                    <Globe className="w-5 h-5 text-green-400" />
                    Localização do Banco de Dados
                  </h3>
                  <div className="space-y-3 text-green-200">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium">Servidor Base44 Cloud</p>
                        <p className="text-sm text-green-300">https://api.base44.com</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium">Armazenamento</p>
                        <p className="text-sm text-green-300">Cloud distribuído com redundância automática</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium">Backup Automático</p>
                        <p className="text-sm text-green-300">Diário às 03:00 AM (horário do servidor)</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium">Retenção</p>
                        <p className="text-sm text-green-300">30 dias de histórico de backups</p>
                      </div>
                    </div>
                  </div>
                </div>

                <Separator className="bg-green-700/50" />

                <div>
                  <h3 className="text-white font-semibold mb-4">Baixar Banco de Dados Completo</h3>
                  <p className="text-green-200 text-sm mb-4">
                    Faça download de todos os seus dados para backup local ou migração.
                  </p>
                  {downloading && (
                    <div className="mb-4">
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-green-200">Preparando backup...</span>
                        <span className="text-white font-medium">{backupProgress}%</span>
                      </div>
                      <div className="w-full bg-green-950 rounded-full h-3 overflow-hidden">
                        <div 
                          className="bg-gradient-to-r from-green-600 to-green-500 h-full transition-all duration-300"
                          style={{ width: `${backupProgress}%` }}
                        />
                      </div>
                    </div>
                  )}
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      onClick={() => downloadCompleteDatabase('json')}
                      disabled={downloading}
                      className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600"
                    >
                      {downloading ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Gerando...
                        </>
                      ) : (
                        <>
                          <Database className="w-4 h-4 mr-2" />
                          Download JSON
                        </>
                      )}
                    </Button>
                    <Button
                      onClick={() => downloadCompleteDatabase('csv')}
                      disabled={downloading}
                      className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600"
                    >
                      {downloading ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Gerando...
                        </>
                      ) : (
                        <>
                          <FileText className="w-4 h-4 mr-2" />
                          Download CSV
                        </>
                      )}
                    </Button>
                  </div>
                  <p className="text-xs text-green-300 mt-2">
                    JSON: Backup completo com todas as tabelas | CSV: Somente transações (compatível Excel)
                  </p>
                </div>

                <Separator className="bg-green-700/50" />

                <div className="bg-blue-950/30 border border-blue-700 rounded-lg p-6">
                  <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                    <Zap className="w-5 h-5 text-blue-400" />
                    Hospedar no Seu Próprio Servidor
                  </h3>
                  <div className="space-y-4 text-blue-200">
                    <p className="text-sm">
                      Para migrar seus dados para um servidor próprio ou outro provedor:
                    </p>
                    <ol className="list-decimal list-inside space-y-2 text-sm">
                      <li>Baixe o backup completo em Excel (botão acima)</li>
                      <li>Exporte também os dados em JSON via API Rest</li>
                      <li>Configure seu servidor com PostgreSQL, MySQL ou MongoDB</li>
                      <li>Importe os dados usando o formato Excel ou JSON</li>
                      <li>Configure a conexão no arquivo de ambiente</li>
                    </ol>
                    
                    <div className="bg-blue-900/30 rounded-lg p-4 mt-4">
                      <p className="text-xs font-mono text-blue-300">
                        # Exemplo de configuração (arquivo .env):
                        <br/>DATABASE_HOST=seu-servidor.com
                        <br/>DATABASE_PORT=5432
                        <br/>DATABASE_NAME=financeiro_db
                        <br/>DATABASE_USER=admin
                        <br/>DATABASE_PASSWORD=***
                      </p>
                    </div>

                    <div className="bg-yellow-950/30 border border-yellow-700 rounded-lg p-4 mt-4">
                      <div className="flex gap-3">
                        <AlertTriangle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="text-yellow-200 font-medium text-sm">Atenção:</p>
                          <p className="text-yellow-300 text-xs mt-1">
                            Ao migrar para servidor próprio, você será responsável por backups, segurança e manutenção.
                            Recomendamos manter o Base44 Cloud para melhor performance e segurança.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* INTEGRAÇÕES EXTERNAS */}
            <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Database className="w-6 h-6 text-blue-400" />
                  Integrações Externas
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                <div>
                  <p className="font-medium text-white">Open Finance (Integração Bancária)</p>
                  <p className="text-sm text-blue-300">Sincronização automática de extratos</p>
                </div>
                <Switch
                  checked={settings?.bank_integration_enabled || false}
                  onCheckedChange={(checked) => handleSave("integrations", { bank_integration_enabled: checked })}
                />
              </div>
              <div className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                <div>
                  <p className="font-medium text-white">API de Cotações (B3, Tesouro)</p>
                  <p className="text-sm text-blue-300">Preços de investimentos em tempo real</p>
                </div>
                <Switch
                  checked={settings?.market_api_enabled || false}
                  onCheckedChange={(checked) => handleSave("integrations", { market_api_enabled: checked })}
                />
              </div>
              <div className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                <div>
                  <p className="font-medium text-white">Integração Contábil</p>
                  <p className="text-sm text-blue-300">Exportação para sistema contábil</p>
                </div>
                <Switch
                  checked={settings?.accounting_integration_enabled || false}
                  onCheckedChange={(checked) => handleSave("integrations", { accounting_integration_enabled: checked })}
                />
              </div>
              <div className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                <div>
                  <p className="font-medium text-white">Google Drive Sync</p>
                  <p className="text-sm text-blue-300">Backup automático de relatórios</p>
                </div>
                <Switch
                  checked={settings?.google_drive_sync || false}
                  onCheckedChange={(checked) => handleSave("integrations", { google_drive_sync: checked })}
                />
              </div>
              <div className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                <div>
                  <p className="font-medium text-white">Webhooks</p>
                  <p className="text-sm text-blue-300">Notificações para sistemas externos</p>
                </div>
                <Switch
                  checked={settings?.webhooks_enabled || false}
                  onCheckedChange={(checked) => handleSave("integrations", { webhooks_enabled: checked })}
                />
              </div>
            </CardContent>
          </Card>
          </div>
        </TabsContent>

        {/* Aba Avançado */}
        <TabsContent value="advanced">
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Zap className="w-6 h-6 text-yellow-400" />
                Configurações Avançadas do Sistema
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label className="text-blue-200 font-medium">Senha de Proteção de Valores</Label>
                <p className="text-xs text-blue-300">Senha para ocultar/mostrar valores (deixe vazio para 1020 padrão)</p>
                <Input
                  type="password"
                  placeholder="Digite a senha (ex: 1020)"
                  defaultValue={settings?.system_password || ""}
                  onBlur={(e) => handleSave("advanced", { system_password: e.target.value })}
                  className="bg-blue-950/50 border-blue-700 text-white"
                />
              </div>

              <Separator className="bg-blue-700/50" />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                  <div>
                    <p className="font-medium text-white">Modo Debug</p>
                    <p className="text-xs text-blue-300">Logs detalhados no console</p>
                  </div>
                  <Switch
                    checked={settings?.debug_mode || false}
                    onCheckedChange={(checked) => handleSave("advanced", { debug_mode: checked })}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                  <div>
                    <p className="font-medium text-white">Cache Inteligente</p>
                    <p className="text-xs text-blue-300">Performance otimizada</p>
                  </div>
                  <Switch
                    checked={settings?.smart_cache !== false}
                    onCheckedChange={(checked) => handleSave("advanced", { smart_cache: checked })}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                  <div>
                    <p className="font-medium text-white">Logs de Auditoria</p>
                    <p className="text-xs text-blue-300">Registrar todas as ações</p>
                  </div>
                  <Switch
                    checked={settings?.advanced_audit_logs || false}
                    onCheckedChange={(checked) => handleSave("advanced", { advanced_audit_logs: checked })}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                  <div>
                    <p className="font-medium text-white">Compressão de Dados</p>
                    <p className="text-xs text-blue-300">Reduzir banda e storage</p>
                  </div>
                  <Switch
                    checked={settings?.data_compression !== false}
                    onCheckedChange={(checked) => handleSave("advanced", { data_compression: checked })}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                  <div>
                    <p className="font-medium text-white">Modo Offline</p>
                    <p className="text-xs text-blue-300">Uso sem internet (limitado)</p>
                  </div>
                  <Switch
                    checked={settings?.offline_mode || false}
                    onCheckedChange={(checked) => handleSave("advanced", { offline_mode: checked })}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-blue-950/50 rounded-lg">
                  <div>
                    <p className="font-medium text-white">Sincronização em Tempo Real</p>
                    <p className="text-xs text-blue-300">Atualizações instantâneas</p>
                  </div>
                  <Switch
                    checked={settings?.realtime_sync !== false}
                    onCheckedChange={(checked) => handleSave("advanced", { realtime_sync: checked })}
                  />
                </div>
              </div>

              <Separator className="bg-blue-700/50" />

              <div className="space-y-3">
                <Label className="text-blue-200">Limite de Transações por Página</Label>
                <Input
                  type="number"
                  min="10"
                  max="200"
                  defaultValue={settings?.transactions_per_page || 50}
                  onBlur={(e) => handleSave("advanced", { transactions_per_page: parseInt(e.target.value) })}
                  className="bg-blue-950/50 border-blue-700 text-white"
                />
              </div>

              <div className="space-y-3">
                <Label className="text-blue-200">Formato de Data</Label>
                <select
                  defaultValue={settings?.date_format || "dd/MM/yyyy"}
                  onChange={(e) => handleSave("advanced", { date_format: e.target.value })}
                  className="w-full bg-blue-950/50 border border-blue-700 rounded-lg px-4 py-2 text-white"
                >
                  <option value="dd/MM/yyyy">DD/MM/AAAA (Brasileiro)</option>
                  <option value="MM/dd/yyyy">MM/DD/AAAA (Americano)</option>
                  <option value="yyyy-MM-dd">AAAA-MM-DD (ISO)</option>
                </select>
              </div>

              <div className="space-y-3">
                <Label className="text-blue-200">Moeda Padrão</Label>
                <select
                  defaultValue={settings?.default_currency || "BRL"}
                  onChange={(e) => handleSave("advanced", { default_currency: e.target.value })}
                  className="w-full bg-blue-950/50 border border-blue-700 rounded-lg px-4 py-2 text-white"
                >
                  <option value="BRL">Real Brasileiro (R$)</option>
                  <option value="USD">Dólar Americano (US$)</option>
                  <option value="EUR">Euro (€)</option>
                </select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}