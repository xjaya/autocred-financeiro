import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  TrendingUp,
  TrendingDown,
  Sparkles,
  Calendar,
  DollarSign,
  AlertTriangle,
  Target,
  RefreshCw,
  Brain,
  ArrowUpCircle,
  ArrowDownCircle,
  CheckCircle
} from "lucide-react";
import { format, addMonths, startOfMonth, endOfMonth, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

export default function FinancialPredictions() {
  const [predicting, setPredicting] = useState(false);
  const [predictions, setPredictions] = useState(null);
  const [aiInsights, setAiInsights] = useState(null);
  const [monthsToPredict, setMonthsToPredict] = useState(6);

  const { data: transactions = [] } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list("-due_date"),
    initialData: [],
  });

  const { data: goals = [] } = useQuery({
    queryKey: ["goals"],
    queryFn: () => base44.entities.Goal.list(),
    initialData: [],
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ["bankAccounts"],
    queryFn: () => base44.entities.BankAccount.list(),
    initialData: [],
  });

  const generatePredictions = async () => {
    setPredicting(true);
    toast.info("🤖 Analisando histórico e gerando previsões...");

    try {
      // Análise dos últimos 12 meses
      const last12Months = Array.from({ length: 12 }, (_, i) => {
        const date = addMonths(new Date(), -11 + i);
        const monthStart = startOfMonth(date);
        const monthEnd = endOfMonth(date);

        const monthTransactions = transactions.filter(t => {
          const tDate = new Date(t.due_date);
          return t.status === "pago" && tDate >= monthStart && tDate <= monthEnd;
        });

        const receitas = monthTransactions
          .filter(t => t.type === "receita")
          .reduce((sum, t) => sum + t.amount, 0);

        const despesas = monthTransactions
          .filter(t => t.type === "despesa")
          .reduce((sum, t) => sum + t.amount, 0);

        return {
          month: format(date, "MMM/yy", { locale: ptBR }),
          receitas,
          despesas,
          saldo: receitas - despesas,
        };
      });

      // Calcular médias e tendências
      const avgReceitas = last12Months.reduce((sum, m) => sum + m.receitas, 0) / 12;
      const avgDespesas = last12Months.reduce((sum, m) => sum + m.despesas, 0) / 12;
      const avgSaldo = avgReceitas - avgDespesas;

      // Tendência (últimos 3 meses vs 3 meses anteriores)
      const recent3 = last12Months.slice(-3);
      const previous3 = last12Months.slice(-6, -3);

      const recentAvgReceitas = recent3.reduce((sum, m) => sum + m.receitas, 0) / 3;
      const previousAvgReceitas = previous3.reduce((sum, m) => sum + m.receitas, 0) / 3;
      const receitasTrend = ((recentAvgReceitas - previousAvgReceitas) / previousAvgReceitas) * 100;

      const recentAvgDespesas = recent3.reduce((sum, m) => sum + m.despesas, 0) / 3;
      const previousAvgDespesas = previous3.reduce((sum, m) => sum + m.despesas, 0) / 3;
      const despesasTrend = ((recentAvgDespesas - previousAvgDespesas) / previousAvgDespesas) * 100;

      // PREVISÕES COM IA
      const aiPredictionResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Você é um analista financeiro especialista. Analise o histórico de 12 meses e gere PREVISÕES DETALHADAS para os próximos ${monthsToPredict} meses.

HISTÓRICO (12 meses):
${JSON.stringify(last12Months, null, 2)}

MÉDIAS:
- Receitas Mensais: R$ ${avgReceitas.toFixed(2)}
- Despesas Mensais: R$ ${avgDespesas.toFixed(2)}
- Saldo Médio: R$ ${avgSaldo.toFixed(2)}

TENDÊNCIAS RECENTES:
- Receitas: ${receitasTrend > 0 ? '+' : ''}${receitasTrend.toFixed(1)}%
- Despesas: ${despesasTrend > 0 ? '+' : ''}${despesasTrend.toFixed(1)}%

METAS ATIVAS:
${goals.filter(g => g.status === 'ativa').map(g => `- ${g.name}: R$ ${g.target_value.toFixed(2)}`).join('\n')}

Forneça previsões mensais considerando:
1. Sazonalidade
2. Tendências recentes
3. Metas estabelecidas
4. Padrões históricos

Para cada mês previsto, inclua:
- receitas_previstas (número)
- despesas_previstas (número)
- saldo_previsto (número)
- confianca (1-10)

Além disso, forneça:
- insights: análise detalhada das previsões
- alertas: lista de possíveis problemas
- recomendacoes: lista de ações sugeridas
- deficit_months: lista de meses com déficit previsto
- surplus_months: lista de meses com superávit previsto`,
        response_json_schema: {
          type: "object",
          properties: {
            monthly_predictions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  month: { type: "string" },
                  receitas_previstas: { type: "number" },
                  despesas_previstas: { type: "number" },
                  saldo_previsto: { type: "number" },
                  confianca: { type: "number" }
                }
              }
            },
            insights: { type: "string" },
            alertas: { type: "array", items: { type: "string" } },
            recomendacoes: { type: "array", items: { type: "string" } },
            deficit_months: { type: "array", items: { type: "string" } },
            surplus_months: { type: "array", items: { type: "string" } }
          }
        }
      });

      // Gerar previsões locais também (fallback)
      const localPredictions = Array.from({ length: monthsToPredict }, (_, i) => {
        const date = addMonths(new Date(), i + 1);
        const growthFactor = 1 + (receitasTrend / 100);
        const expenseGrowthFactor = 1 + (despesasTrend / 100);

        return {
          month: format(date, "MMM/yy", { locale: ptBR }),
          receitas_previstas: avgReceitas * Math.pow(growthFactor, i + 1),
          despesas_previstas: avgDespesas * Math.pow(expenseGrowthFactor, i + 1),
          confianca: Math.max(5, 10 - i) // Confiança diminui com o tempo
        };
      });

      // Combinar dados históricos com previsões
      const fullData = [
        ...last12Months.map(m => ({ ...m, tipo: "histórico" })),
        ...(aiPredictionResult?.monthly_predictions || localPredictions).map(m => ({
          month: m.month,
          receitas: m.receitas_previstas,
          despesas: m.despesas_previstas,
          saldo: m.receitas_previstas - m.despesas_previstas,
          tipo: "previsão",
          confianca: m.confianca
        }))
      ];

      setPredictions({
        fullData,
        aiPredictions: aiPredictionResult?.monthly_predictions || localPredictions,
        historical: last12Months,
        metrics: {
          avgReceitas,
          avgDespesas,
          avgSaldo,
          receitasTrend,
          despesasTrend
        }
      });

      setAiInsights(aiPredictionResult);

      toast.success("✅ Previsões geradas com sucesso!");
    } catch (error) {
      console.error("Erro ao gerar previsões:", error);
      toast.error("❌ Erro ao gerar previsões");
    }

    setPredicting(false);
  };

  const totalCurrentBalance = bankAccounts.reduce((sum, acc) => sum + (acc.initial_balance || 0), 0);

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white drop-shadow-lg">Previsões Financeiras com IA</h1>
          <p className="text-blue-200 mt-1">Análise preditiva baseada em histórico e inteligência artificial</p>
        </div>
        <div className="flex gap-2">
          <select
            value={monthsToPredict}
            onChange={(e) => setMonthsToPredict(parseInt(e.target.value))}
            className="bg-blue-950/50 border border-blue-700 rounded-lg px-4 py-2 text-white"
          >
            <option value="3">3 meses</option>
            <option value="6">6 meses</option>
            <option value="12">12 meses</option>
          </select>
          <Button
            onClick={generatePredictions}
            disabled={predicting}
            className="bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600"
          >
            {predicting ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Analisando...
              </>
            ) : (
              <>
                <Brain className="w-4 h-4 mr-2" />
                Gerar Previsões
              </>
            )}
          </Button>
        </div>
      </div>

      {!predictions && (
        <Card className="border-purple-700/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
          <CardContent className="py-16 text-center">
            <Brain className="w-20 h-20 text-purple-400 mx-auto mb-6 opacity-50" />
            <h3 className="text-2xl font-bold text-white mb-3">Análise Preditiva Avançada</h3>
            <p className="text-purple-200 mb-6 max-w-2xl mx-auto">
              Use inteligência artificial para prever fluxo de caixa futuro, identificar déficits e superávits,
              e receber recomendações personalizadas para ajustar suas metas financeiras.
            </p>
            <Button
              onClick={generatePredictions}
              className="bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Iniciar Análise Preditiva
            </Button>
          </CardContent>
        </Card>
      )}

      {predictions && (
        <>
          {/* Resumo das Tendências */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="border-green-500/50 bg-gradient-to-br from-green-800/80 to-green-700/80">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-200">Receita Média</p>
                    <p className="text-2xl font-bold text-white mt-1">
                      R$ {predictions.metrics.avgReceitas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                    <Badge className={`mt-2 ${predictions.metrics.receitasTrend >= 0 ? 'bg-green-500' : 'bg-red-500'}`}>
                      {predictions.metrics.receitasTrend >= 0 ? '↗' : '↘'} {Math.abs(predictions.metrics.receitasTrend).toFixed(1)}%
                    </Badge>
                  </div>
                  <TrendingUp className="w-10 h-10 text-green-300 opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-red-500/50 bg-gradient-to-br from-red-800/80 to-red-700/80">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-red-200">Despesa Média</p>
                    <p className="text-2xl font-bold text-white mt-1">
                      R$ {predictions.metrics.avgDespesas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                    <Badge className={`mt-2 ${predictions.metrics.despesasTrend >= 0 ? 'bg-red-500' : 'bg-green-500'}`}>
                      {predictions.metrics.despesasTrend >= 0 ? '↗' : '↘'} {Math.abs(predictions.metrics.despesasTrend).toFixed(1)}%
                    </Badge>
                  </div>
                  <TrendingDown className="w-10 h-10 text-red-300 opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-blue-500/50 bg-gradient-to-br from-blue-800/80 to-blue-700/80">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-200">Saldo Médio</p>
                    <p className="text-2xl font-bold text-white mt-1">
                      R$ {predictions.metrics.avgSaldo.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <DollarSign className="w-10 h-10 text-blue-300 opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-purple-500/50 bg-gradient-to-br from-purple-800/80 to-purple-700/80">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-purple-200">Saldo Atual</p>
                    <p className="text-2xl font-bold text-white mt-1">
                      R$ {totalCurrentBalance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <Target className="w-10 h-10 text-purple-300 opacity-50" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Gráfico Principal - Histórico + Previsão */}
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-400" />
                Fluxo de Caixa - Histórico e Previsão
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={predictions.fullData}>
                  <defs>
                    <linearGradient id="colorReceitas" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10B981" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#10B981" stopOpacity={0.1}/>
                    </linearGradient>
                    <linearGradient id="colorDespesas" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#EF4444" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#EF4444" stopOpacity={0.1}/>
                    </linearGradient>
                    <linearGradient id="colorSaldo" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#3B82F6" stopOpacity={0.1}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e40af" />
                  <XAxis 
                    dataKey="month" 
                    stroke="#93c5fd" 
                    fontSize={12}
                  />
                  <YAxis stroke="#93c5fd" fontSize={12} />
                  <Tooltip
                    contentStyle={{ 
                      backgroundColor: "#1e3a8a", 
                      border: "1px solid #3b82f6", 
                      borderRadius: "8px" 
                    }}
                    formatter={(value) => `R$ ${value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
                  />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="receitas" 
                    stroke="#10B981" 
                    fillOpacity={1}
                    fill="url(#colorReceitas)"
                    strokeWidth={2}
                    name="Receitas"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="despesas" 
                    stroke="#EF4444" 
                    fillOpacity={1}
                    fill="url(#colorDespesas)"
                    strokeWidth={2}
                    name="Despesas"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="saldo" 
                    stroke="#3B82F6" 
                    strokeWidth={3}
                    name="Saldo"
                    dot={{ r: 4 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
              <div className="flex items-center justify-center gap-4 mt-4 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-0.5 bg-blue-400" />
                  <span className="text-blue-200">Histórico</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-0.5 bg-purple-400 border-t-2 border-dashed border-purple-400" />
                  <span className="text-purple-200">Previsão</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Insights e Alertas da IA */}
          {aiInsights && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="border-purple-700/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-purple-400" />
                    Insights da IA
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-purple-100 text-sm whitespace-pre-wrap leading-relaxed">
                    {aiInsights.insights}
                  </p>
                  {aiInsights.recomendacoes && aiInsights.recomendacoes.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-purple-200 font-semibold flex items-center gap-2">
                        <Target className="w-4 h-4" />
                        Recomendações
                      </h4>
                      <ul className="space-y-2">
                        {aiInsights.recomendacoes.map((rec, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-purple-200">
                            <span className="text-green-400">✓</span>
                            <span>{rec}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-red-700/50 bg-gradient-to-br from-red-900/80 to-red-800/80">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-red-400" />
                    Alertas e Riscos
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {aiInsights.alertas && aiInsights.alertas.length > 0 ? (
                    <ul className="space-y-3">
                      {aiInsights.alertas.map((alert, i) => (
                        <li key={i} className="flex items-start gap-2 p-3 bg-red-950/30 rounded-lg border border-red-700">
                          <AlertTriangle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-red-200">{alert}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-red-200 text-sm">Nenhum alerta crítico identificado.</p>
                  )}

                  {aiInsights.deficit_months && aiInsights.deficit_months.length > 0 && (
                    <div className="mt-4">
                      <h4 className="text-red-200 font-semibold mb-2 flex items-center gap-2">
                        <ArrowDownCircle className="w-4 h-4" />
                        Meses com Déficit Previsto
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {aiInsights.deficit_months.map((month, i) => (
                          <Badge key={i} className="bg-red-500 text-white">{month}</Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {aiInsights.surplus_months && aiInsights.surplus_months.length > 0 && (
                    <div className="mt-4">
                      <h4 className="text-green-200 font-semibold mb-2 flex items-center gap-2">
                        <ArrowUpCircle className="w-4 h-4" />
                        Meses com Superávit Previsto
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {aiInsights.surplus_months.map((month, i) => (
                          <Badge key={i} className="bg-green-500 text-white">{month}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Tabela de Previsões Mensais */}
          {predictions && (
            <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
              <CardHeader>
                <CardTitle className="text-white">Previsões Detalhadas por Mês</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-blue-700">
                        <th className="text-left text-blue-300 p-3">Mês</th>
                        <th className="text-right text-blue-300 p-3">Receitas</th>
                        <th className="text-right text-blue-300 p-3">Despesas</th>
                        <th className="text-right text-blue-300 p-3">Saldo</th>
                        <th className="text-center text-blue-300 p-3">Confiança</th>
                      </tr>
                    </thead>
                    <tbody>
                      {predictions.aiPredictions.map((pred, idx) => {
                        const saldo = pred.receitas_previstas - pred.despesas_previstas;
                        return (
                          <tr key={idx} className="border-b border-blue-700/50 hover:bg-blue-800/30">
                            <td className="text-white p-3 flex items-center gap-2">
                              <Calendar className="w-4 h-4 text-purple-400" />
                              {pred.month}
                            </td>
                            <td className="text-right text-green-300 font-semibold p-3">
                              R$ {pred.receitas_previstas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                            </td>
                            <td className="text-right text-red-300 font-semibold p-3">
                              R$ {pred.despesas_previstas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                            </td>
                            <td className={`text-right font-bold p-3 ${saldo >= 0 ? 'text-green-300' : 'text-red-300'}`}>
                              R$ {saldo.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                            </td>
                            <td className="text-center p-3">
                              <div className="flex items-center justify-center gap-2">
                                <Progress value={pred.confianca * 10} className="w-16 h-2" />
                                <span className="text-xs text-blue-200">{pred.confianca}/10</span>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Comparação com Metas */}
          {goals.length > 0 && predictions && (
            <Card className="border-green-700/50 bg-gradient-to-br from-green-900/80 to-green-800/80">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Target className="w-5 h-5 text-green-400" />
                  Análise de Metas vs Previsões
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {goals.filter(g => g.status === 'ativa').map(goal => {
                  const goalEndDate = new Date(goal.end_date);
                  const daysToEnd = differenceInDays(goalEndDate, new Date());
                  
                  // Calcular previsão acumulada até o fim da meta
                  const relevantPredictions = predictions.aiPredictions.filter(p => {
                    const predMonth = new Date(p.month);
                    return predMonth <= goalEndDate;
                  });

                  const predictedTotal = relevantPredictions.reduce((sum, p) => {
                    if (goal.type === "receita") return sum + p.receitas_previstas;
                    if (goal.type === "despesa") return sum + (predictions.metrics.avgDespesas - p.despesas_previstas);
                    return sum + (p.receitas_previstas - p.despesas_previstas);
                  }, 0);

                  const likelihood = (predictedTotal / goal.target_value) * 100;

                  return (
                    <div key={goal.id} className="bg-blue-950/30 p-4 rounded-lg border border-green-700">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="text-white font-semibold">{goal.name}</h4>
                          <p className="text-sm text-green-300">
                            Meta: R$ {goal.target_value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </p>
                        </div>
                        <Badge className={likelihood >= 100 ? 'bg-green-500' : likelihood >= 80 ? 'bg-yellow-500' : 'bg-red-500'}>
                          {likelihood >= 100 ? '✅ Atingível' : likelihood >= 80 ? '⚠️ Desafiador' : '❌ Difícil'}
                        </Badge>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-blue-200">Previsão de alcance:</span>
                          <span className="text-white font-semibold">{likelihood.toFixed(1)}%</span>
                        </div>
                        <Progress value={Math.min(likelihood, 100)} className="h-2" />
                        <p className="text-xs text-blue-300">
                          Projeção: R$ {predictedTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })} em {daysToEnd} dias
                        </p>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}