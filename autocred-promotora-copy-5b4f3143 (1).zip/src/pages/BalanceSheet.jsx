import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, RefreshCw } from "lucide-react";
import { startOfMonth, endOfMonth, format } from "date-fns";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import ReportFilters from "../components/reports/ReportFilters";
import ReportExportButtons from "../components/reports/ReportExportButtons";

const COLORS = ["#60A5FA", "#34D399", "#FBBF24", "#F87171"];

export default function BalanceSheet() {
  const [startDate, setStartDate] = useState(format(startOfMonth(new Date()), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(endOfMonth(new Date()), "yyyy-MM-dd"));
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [loadingAI, setLoadingAI] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedCostCenter, setSelectedCostCenter] = useState("all");

  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list(),
    initialData: [],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list(),
    initialData: [],
  });

  const { data: costCenters = [] } = useQuery({
    queryKey: ["costCenters"],
    queryFn: () => base44.entities.CostCenter.list(),
    initialData: [],
  });

  const filteredTransactions = transactions.filter((t) => {
    const tDate = new Date(t.due_date);
    const dateMatch = tDate >= new Date(startDate) && tDate <= new Date(endDate) && t.status === "pago";
    const categoryMatch = selectedCategory === "all" || t.category === selectedCategory;
    const costCenterMatch = selectedCostCenter === "all" || t.cost_center === selectedCostCenter;
    return dateMatch && categoryMatch && costCenterMatch;
  });

  const ativoCirculante = filteredTransactions.filter(t => t.type === "receita").reduce((sum, t) => sum + t.amount, 0);
  const passivoCirculante = filteredTransactions.filter(t => t.type === "despesa").reduce((sum, t) => sum + t.amount, 0);
  const patrimonioLiquido = ativoCirculante - passivoCirculante;
  const liquidez = passivoCirculante > 0 ? (ativoCirculante / passivoCirculante) : 0;

  const chartData = [
    { name: "Ativo", value: ativoCirculante },
    { name: "Passivo", value: passivoCirculante },
    { name: "Patrimônio", value: Math.abs(patrimonioLiquido) },
  ];

  const generateAIAnalysis = async () => {
    setLoadingAI(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analise Balanço de ${format(new Date(startDate), "dd/MM/yyyy")} a ${format(new Date(endDate), "dd/MM/yyyy")}:

ATIVO: R$ ${ativoCirculante.toFixed(2)}
PASSIVO: R$ ${passivoCirculante.toFixed(2)}
PATRIMÔNIO: R$ ${patrimonioLiquido.toFixed(2)}
LIQUIDEZ: ${liquidez.toFixed(2)}

DIAGNÓSTICO EM 3 SEÇÕES:

🟢 PONTOS POSITIVOS
- Solidez patrimonial
- Indicadores saudáveis

🟠 ALERTAS
- Riscos de liquidez
- Atenção necessária

🔴 CRÍTICO
- Problemas graves
- Ações urgentes

Seja direto e use números.`,
      });

      setAiAnalysis(result);
    } catch (error) {
      console.error("Erro:", error);
    }
    setLoadingAI(false);
  };

  useEffect(() => {
    if (!isLoading && transactions.length > 0) {
      generateAIAnalysis();
    }
  }, [startDate, endDate, isLoading]);

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="w-8 h-8 text-blue-400 animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold text-white">Balanço Patrimonial</h1>
          <p className="text-blue-200 mt-1">Diagnóstico com IA</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={generateAIAnalysis} disabled={loadingAI} variant="outline" className="border-purple-600 text-purple-300 hover:bg-purple-700">
            <Sparkles className={`w-4 h-4 mr-2 ${loadingAI ? "animate-spin" : ""}`} />
            {loadingAI ? "Analisando..." : "IA Analisar"}
          </Button>
          <ReportExportButtons
            reportTitle="BalancoPatrimonial"
            data={filteredTransactions}
            columns={[
              { header: "Data", accessor: (t) => format(new Date(t.due_date), "dd/MM/yyyy") },
              { header: "Descrição", accessor: (t) => t.description },
              { header: "Tipo", accessor: (t) => t.type },
              { header: "Valor", accessor: (t) => t.amount.toFixed(2) }
            ]}
            startDate={startDate}
            endDate={endDate}
            onPdfExport={() => window.print()}
          />
        </div>
      </div>

      <ReportFilters
        startDate={startDate}
        endDate={endDate}
        onStartDateChange={setStartDate}
        onEndDateChange={setEndDate}
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
        selectedCostCenter={selectedCostCenter}
        onCostCenterChange={setSelectedCostCenter}
        categories={categories}
        costCenters={costCenters}
        onReset={() => {
          setSelectedCategory("all");
          setSelectedCostCenter("all");
        }}
      />

      <div className="grid grid-cols-3 gap-6">
        <Card className="border-blue-500/50 bg-gradient-to-br from-blue-800/80 to-blue-700/80">
          <CardContent className="pt-6 text-center">
            <p className="text-sm text-blue-200">Ativo Circulante</p>
            <p className="text-3xl font-bold text-white mt-1">R$ {ativoCirculante.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
          </CardContent>
        </Card>

        <Card className="border-red-500/50 bg-gradient-to-br from-red-800/80 to-red-700/80">
          <CardContent className="pt-6 text-center">
            <p className="text-sm text-red-200">Passivo Circulante</p>
            <p className="text-3xl font-bold text-white mt-1">R$ {passivoCirculante.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
          </CardContent>
        </Card>

        <Card className="border-green-500/50 bg-gradient-to-br from-green-800/80 to-green-700/80">
          <CardContent className="pt-6 text-center">
            <p className="text-sm text-green-200">Patrimônio Líquido</p>
            <p className="text-3xl font-bold text-white mt-1">R$ {patrimonioLiquido.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
          </CardContent>
        </Card>
      </div>

      {aiAnalysis && (
        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/90 to-blue-900/90 shadow-2xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Sparkles className="w-6 h-6 text-purple-400" />
              Diagnóstico Patrimonial
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose prose-invert max-w-none text-sm whitespace-pre-wrap leading-relaxed text-white">
              {aiAnalysis}
            </div>
          </CardContent>
        </Card>
      )}

      {loadingAI && (
        <Card className="border-purple-500/50 bg-purple-900/50">
          <CardContent className="py-8">
            <div className="flex items-center justify-center gap-3">
              <RefreshCw className="w-5 h-5 animate-spin text-purple-400" />
              <span className="text-purple-200">Gerando diagnóstico...</span>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white">Composição</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <PieChart>
              <Pie data={chartData} cx="50%" cy="50%" labelLine={false} label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`} outerRadius={120} dataKey="value">
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: "#1e3a8a", border: "1px solid #3b82f6", borderRadius: "8px", color: "#fff" }} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}