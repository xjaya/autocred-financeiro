import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Bell,
  Calendar,
  TrendingDown,
  AlertTriangle,
  DollarSign,
  Settings as SettingsIcon,
  CheckCircle,
  Mail,
  Smartphone,
  Zap
} from "lucide-react";
import { format, addDays, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";

export default function FinancialAlerts() {
  const [alertConfig, setAlertConfig] = useState({
    bills_due_days: 2,
    bills_due_enabled: true,
    low_balance_threshold: 1000,
    low_balance_enabled: true,
    unusual_amount_multiplier: 3,
    unusual_amount_enabled: true,
    large_expense_threshold: 5000,
    large_expense_enabled: true,
    email_enabled: true,
    in_app_enabled: true,
  });

  const queryClient = useQueryClient();

  const { data: transactions = [] } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list("-due_date"),
    initialData: [],
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ["bankAccounts"],
    queryFn: () => base44.entities.BankAccount.list(),
    initialData: [],
  });

  const { data: settings } = useQuery({
    queryKey: ["companySettings"],
    queryFn: async () => {
      const list = await base44.entities.CompanySettings.list();
      return list[0] || null;
    },
  });

  useEffect(() => {
    if (settings) {
      setAlertConfig({
        bills_due_days: settings.alert_bills_due_days || 2,
        bills_due_enabled: settings.alert_bills_due_enabled !== false,
        low_balance_threshold: settings.alert_low_balance_threshold || 1000,
        low_balance_enabled: settings.alert_low_balance_enabled !== false,
        unusual_amount_multiplier: settings.alert_unusual_multiplier || 3,
        unusual_amount_enabled: settings.alert_unusual_enabled !== false,
        large_expense_threshold: settings.alert_large_expense_threshold || 5000,
        large_expense_enabled: settings.alert_large_expense_enabled !== false,
        email_enabled: settings.alert_email_enabled !== false,
        in_app_enabled: settings.alert_in_app_enabled !== false,
      });
    }
  }, [settings]);

  const updateMutation = useMutation({
    mutationFn: async (data) => {
      if (settings?.id) {
        return await base44.entities.CompanySettings.update(settings.id, data);
      } else {
        return await base44.entities.CompanySettings.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["companySettings"] });
      toast.success("✅ Configurações salvas!");
    },
  });

  const handleSave = async () => {
    await updateMutation.mutateAsync({
      alert_bills_due_days: alertConfig.bills_due_days,
      alert_bills_due_enabled: alertConfig.bills_due_enabled,
      alert_low_balance_threshold: alertConfig.low_balance_threshold,
      alert_low_balance_enabled: alertConfig.low_balance_enabled,
      alert_unusual_multiplier: alertConfig.unusual_amount_multiplier,
      alert_unusual_enabled: alertConfig.unusual_amount_enabled,
      alert_large_expense_threshold: alertConfig.large_expense_threshold,
      alert_large_expense_enabled: alertConfig.large_expense_enabled,
      alert_email_enabled: alertConfig.email_enabled,
      alert_in_app_enabled: alertConfig.in_app_enabled,
    });
  };

  // DETECTAR ALERTAS ATIVOS
  const today = new Date();
  const dueThreshold = addDays(today, alertConfig.bills_due_days);

  const upcomingBills = transactions.filter(t => {
    const dueDate = new Date(t.due_date);
    return t.status === "pendente" && dueDate >= today && dueDate <= dueThreshold;
  });

  const lowBalanceAccounts = bankAccounts.filter(acc => {
    const balance = acc.initial_balance || 0;
    return balance < alertConfig.low_balance_threshold;
  });

  const avgExpense = transactions
    .filter(t => t.type === "despesa" && t.status === "pago")
    .reduce((sum, t, _, arr) => sum + t.amount / arr.length, 0);

  const unusualTransactions = transactions.filter(t => {
    return t.amount > avgExpense * alertConfig.unusual_amount_multiplier;
  }).slice(0, 10);

  const largeExpenses = transactions.filter(t => {
    const dueDate = new Date(t.due_date);
    return t.type === "despesa" && t.status === "pendente" && 
           t.amount >= alertConfig.large_expense_threshold &&
           dueDate >= today;
  });

  const totalAlerts = 
    (alertConfig.bills_due_enabled ? upcomingBills.length : 0) +
    (alertConfig.low_balance_enabled ? lowBalanceAccounts.length : 0) +
    (alertConfig.unusual_amount_enabled ? unusualTransactions.length : 0) +
    (alertConfig.large_expense_enabled ? largeExpenses.length : 0);

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-4xl font-bold text-white flex items-center gap-3">
            <Bell className="w-10 h-10 text-yellow-400" />
            Alertas Financeiros Proativos
          </h1>
          <p className="text-blue-200 mt-1">Sistema inteligente de notificações automáticas</p>
        </div>
        <Badge className="bg-yellow-500 text-white text-lg px-4 py-2">
          {totalAlerts} Alertas Ativos
        </Badge>
      </div>

      {/* Resumo de Alertas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-yellow-500/50 bg-gradient-to-br from-yellow-800/80 to-yellow-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <Calendar className="w-8 h-8 text-yellow-300 mx-auto mb-2" />
              <p className="text-sm text-yellow-200">Contas a Vencer</p>
              <p className="text-3xl font-bold text-white mt-1">{upcomingBills.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-red-500/50 bg-gradient-to-br from-red-800/80 to-red-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <TrendingDown className="w-8 h-8 text-red-300 mx-auto mb-2" />
              <p className="text-sm text-red-200">Saldo Baixo</p>
              <p className="text-3xl font-bold text-white mt-1">{lowBalanceAccounts.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-orange-500/50 bg-gradient-to-br from-orange-800/80 to-orange-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <AlertTriangle className="w-8 h-8 text-orange-300 mx-auto mb-2" />
              <p className="text-sm text-orange-200">Valores Incomuns</p>
              <p className="text-3xl font-bold text-white mt-1">{unusualTransactions.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-800/80 to-purple-700/80">
          <CardContent className="pt-6">
            <div className="text-center">
              <DollarSign className="w-8 h-8 text-purple-300 mx-auto mb-2" />
              <p className="text-sm text-purple-200">Grandes Despesas</p>
              <p className="text-3xl font-bold text-white mt-1">{largeExpenses.length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Configurações */}
      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <SettingsIcon className="w-5 h-5 text-blue-400" />
            Configurar Alertas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Contas a Vencer */}
          <div className="bg-yellow-950/30 p-4 rounded-lg border border-yellow-700">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-yellow-400" />
                <div>
                  <p className="text-white font-medium">Contas a Vencer</p>
                  <p className="text-sm text-yellow-300">Notificar sobre vencimentos próximos</p>
                </div>
              </div>
              <Switch
                checked={alertConfig.bills_due_enabled}
                onCheckedChange={(val) => setAlertConfig({...alertConfig, bills_due_enabled: val})}
              />
            </div>
            {alertConfig.bills_due_enabled && (
              <div>
                <Label className="text-yellow-200">Alertar com quantos dias de antecedência?</Label>
                <Input
                  type="number"
                  value={alertConfig.bills_due_days}
                  onChange={(e) => setAlertConfig({...alertConfig, bills_due_days: parseInt(e.target.value)})}
                  className="bg-yellow-950/50 border-yellow-700 text-white mt-2"
                />
              </div>
            )}
          </div>

          {/* Saldo Baixo */}
          <div className="bg-red-950/30 p-4 rounded-lg border border-red-700">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <TrendingDown className="w-5 h-5 text-red-400" />
                <div>
                  <p className="text-white font-medium">Saldo Baixo</p>
                  <p className="text-sm text-red-300">Notificar quando saldo estiver abaixo do limite</p>
                </div>
              </div>
              <Switch
                checked={alertConfig.low_balance_enabled}
                onCheckedChange={(val) => setAlertConfig({...alertConfig, low_balance_enabled: val})}
              />
            </div>
            {alertConfig.low_balance_enabled && (
              <div>
                <Label className="text-red-200">Limite mínimo de saldo (R$)</Label>
                <Input
                  type="number"
                  step="100"
                  value={alertConfig.low_balance_threshold}
                  onChange={(e) => setAlertConfig({...alertConfig, low_balance_threshold: parseFloat(e.target.value)})}
                  className="bg-red-950/50 border-red-700 text-white mt-2"
                />
              </div>
            )}
          </div>

          {/* Valores Incomuns */}
          <div className="bg-orange-950/30 p-4 rounded-lg border border-orange-700">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-orange-400" />
                <div>
                  <p className="text-white font-medium">Valores Incomuns</p>
                  <p className="text-sm text-orange-300">Detectar transações fora do padrão</p>
                </div>
              </div>
              <Switch
                checked={alertConfig.unusual_amount_enabled}
                onCheckedChange={(val) => setAlertConfig({...alertConfig, unusual_amount_enabled: val})}
              />
            </div>
            {alertConfig.unusual_amount_enabled && (
              <div>
                <Label className="text-orange-200">Multiplicador (quantas vezes a média?)</Label>
                <Input
                  type="number"
                  step="0.5"
                  value={alertConfig.unusual_amount_multiplier}
                  onChange={(e) => setAlertConfig({...alertConfig, unusual_amount_multiplier: parseFloat(e.target.value)})}
                  className="bg-orange-950/50 border-orange-700 text-white mt-2"
                />
                <p className="text-xs text-orange-300 mt-1">
                  Média de despesas: R$ {avgExpense.toFixed(2)} • Limite: R$ {(avgExpense * alertConfig.unusual_amount_multiplier).toFixed(2)}
                </p>
              </div>
            )}
          </div>

          {/* Grandes Despesas */}
          <div className="bg-purple-950/30 p-4 rounded-lg border border-purple-700">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <DollarSign className="w-5 h-5 text-purple-400" />
                <div>
                  <p className="text-white font-medium">Grandes Despesas Futuras</p>
                  <p className="text-sm text-purple-300">Alertar sobre despesas elevadas pendentes</p>
                </div>
              </div>
              <Switch
                checked={alertConfig.large_expense_enabled}
                onCheckedChange={(val) => setAlertConfig({...alertConfig, large_expense_enabled: val})}
              />
            </div>
            {alertConfig.large_expense_enabled && (
              <div>
                <Label className="text-purple-200">Valor mínimo para alerta (R$)</Label>
                <Input
                  type="number"
                  step="100"
                  value={alertConfig.large_expense_threshold}
                  onChange={(e) => setAlertConfig({...alertConfig, large_expense_threshold: parseFloat(e.target.value)})}
                  className="bg-purple-950/50 border-purple-700 text-white mt-2"
                />
              </div>
            )}
          </div>

          {/* Canais de Notificação */}
          <div className="bg-blue-950/30 p-4 rounded-lg border border-blue-700">
            <p className="text-white font-medium mb-3 flex items-center gap-2">
              <Zap className="w-5 h-5 text-blue-400" />
              Canais de Notificação
            </p>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-blue-300" />
                  <span className="text-blue-200">Notificações por Email</span>
                </div>
                <Switch
                  checked={alertConfig.email_enabled}
                  onCheckedChange={(val) => setAlertConfig({...alertConfig, email_enabled: val})}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Bell className="w-5 h-5 text-blue-300" />
                  <span className="text-blue-200">Notificações no Sistema</span>
                </div>
                <Switch
                  checked={alertConfig.in_app_enabled}
                  onCheckedChange={(val) => setAlertConfig({...alertConfig, in_app_enabled: val})}
                />
              </div>
            </div>
          </div>

          <Button onClick={handleSave} className="w-full bg-gradient-to-r from-green-600 to-green-500">
            <CheckCircle className="w-4 h-4 mr-2" />
            Salvar Configurações
          </Button>
        </CardContent>
      </Card>

      {/* Alertas Ativos */}
      {alertConfig.bills_due_enabled && upcomingBills.length > 0 && (
        <Card className="border-yellow-500/50 bg-gradient-to-br from-yellow-900/30 to-blue-900/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-yellow-400" />
              🔔 Contas a Vencer ({upcomingBills.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {upcomingBills.slice(0, 5).map(bill => (
                <div key={bill.id} className="bg-yellow-950/50 p-4 rounded-lg border border-yellow-700 flex justify-between items-center">
                  <div>
                    <p className="text-white font-medium">{bill.description}</p>
                    <p className="text-sm text-yellow-300">
                      Vence em {differenceInDays(new Date(bill.due_date), today)} dias - {format(new Date(bill.due_date), "dd/MM/yyyy")}
                    </p>
                  </div>
                  <p className="text-xl font-bold text-yellow-300">R$ {bill.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {alertConfig.low_balance_enabled && lowBalanceAccounts.length > 0 && (
        <Card className="border-red-500/50 bg-gradient-to-br from-red-900/30 to-blue-900/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingDown className="w-5 h-5 text-red-400" />
              ⚠️ Contas com Saldo Baixo ({lowBalanceAccounts.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {lowBalanceAccounts.map(acc => (
                <div key={acc.id} className="bg-red-950/50 p-4 rounded-lg border border-red-700 flex justify-between items-center">
                  <div>
                    <p className="text-white font-medium">{acc.name} - {acc.bank}</p>
                    <p className="text-sm text-red-300">Abaixo do limite de R$ {alertConfig.low_balance_threshold.toLocaleString("pt-BR")}</p>
                  </div>
                  <p className="text-xl font-bold text-red-300">R$ {(acc.initial_balance || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {alertConfig.large_expense_enabled && largeExpenses.length > 0 && (
        <Card className="border-purple-500/50 bg-gradient-to-br from-purple-900/30 to-blue-900/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-purple-400" />
              💰 Grandes Despesas Pendentes ({largeExpenses.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {largeExpenses.slice(0, 5).map(exp => (
                <div key={exp.id} className="bg-purple-950/50 p-4 rounded-lg border border-purple-700 flex justify-between items-center">
                  <div>
                    <p className="text-white font-medium">{exp.description}</p>
                    <p className="text-sm text-purple-300">Vencimento: {format(new Date(exp.due_date), "dd/MM/yyyy")}</p>
                  </div>
                  <p className="text-xl font-bold text-purple-300">R$ {exp.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}