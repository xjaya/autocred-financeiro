import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Transactions from "./Transactions";

import Contracts from "./Contracts";

import DRE from "./DRE";

import ImportExtract from "./ImportExtract";

import Suppliers from "./Suppliers";

import Reports from "./Reports";

import BalanceSheet from "./BalanceSheet";

import CashFlow from "./CashFlow";

import Contacts from "./Contacts";

import Categories from "./Categories";

import CostCenters from "./CostCenters";

import BankAccounts from "./BankAccounts";

import Notifications from "./Notifications";

import Settings from "./Settings";

import FinancialAnalysis from "./FinancialAnalysis";

import Clients from "./Clients";

import Goals from "./Goals";

import Transfers from "./Transfers";

import ImportExtractPage from "./ImportExtractPage";

import BankIntegrationPage from "./BankIntegrationPage";

import CustomReports from "./CustomReports";

import BackupRestore from "./BackupRestore";

import AITraining from "./AITraining";

import FinancialReportsAdvanced from "./FinancialReportsAdvanced";

import AIFinancialAdvisor from "./AIFinancialAdvisor";

import AIManagement from "./AIManagement";

import FinancialAlerts from "./FinancialAlerts";

import FinancialReports from "./FinancialReports";

import FinancialPredictions from "./FinancialPredictions";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Transactions: Transactions,
    
    Contracts: Contracts,
    
    DRE: DRE,
    
    ImportExtract: ImportExtract,
    
    Suppliers: Suppliers,
    
    Reports: Reports,
    
    BalanceSheet: BalanceSheet,
    
    CashFlow: CashFlow,
    
    Contacts: Contacts,
    
    Categories: Categories,
    
    CostCenters: CostCenters,
    
    BankAccounts: BankAccounts,
    
    Notifications: Notifications,
    
    Settings: Settings,
    
    FinancialAnalysis: FinancialAnalysis,
    
    Clients: Clients,
    
    Goals: Goals,
    
    Transfers: Transfers,
    
    ImportExtractPage: ImportExtractPage,
    
    BankIntegrationPage: BankIntegrationPage,
    
    CustomReports: CustomReports,
    
    BackupRestore: BackupRestore,
    
    AITraining: AITraining,
    
    FinancialReportsAdvanced: FinancialReportsAdvanced,
    
    AIFinancialAdvisor: AIFinancialAdvisor,
    
    AIManagement: AIManagement,
    
    FinancialAlerts: FinancialAlerts,
    
    FinancialReports: FinancialReports,
    
    FinancialPredictions: FinancialPredictions,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Transactions" element={<Transactions />} />
                
                <Route path="/Contracts" element={<Contracts />} />
                
                <Route path="/DRE" element={<DRE />} />
                
                <Route path="/ImportExtract" element={<ImportExtract />} />
                
                <Route path="/Suppliers" element={<Suppliers />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/BalanceSheet" element={<BalanceSheet />} />
                
                <Route path="/CashFlow" element={<CashFlow />} />
                
                <Route path="/Contacts" element={<Contacts />} />
                
                <Route path="/Categories" element={<Categories />} />
                
                <Route path="/CostCenters" element={<CostCenters />} />
                
                <Route path="/BankAccounts" element={<BankAccounts />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/FinancialAnalysis" element={<FinancialAnalysis />} />
                
                <Route path="/Clients" element={<Clients />} />
                
                <Route path="/Goals" element={<Goals />} />
                
                <Route path="/Transfers" element={<Transfers />} />
                
                <Route path="/ImportExtractPage" element={<ImportExtractPage />} />
                
                <Route path="/BankIntegrationPage" element={<BankIntegrationPage />} />
                
                <Route path="/CustomReports" element={<CustomReports />} />
                
                <Route path="/BackupRestore" element={<BackupRestore />} />
                
                <Route path="/AITraining" element={<AITraining />} />
                
                <Route path="/FinancialReportsAdvanced" element={<FinancialReportsAdvanced />} />
                
                <Route path="/AIFinancialAdvisor" element={<AIFinancialAdvisor />} />
                
                <Route path="/AIManagement" element={<AIManagement />} />
                
                <Route path="/FinancialAlerts" element={<FinancialAlerts />} />
                
                <Route path="/FinancialReports" element={<FinancialReports />} />
                
                <Route path="/FinancialPredictions" element={<FinancialPredictions />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}