import React from "react";
import AITrainingPanel from "../components/AITrainingPanel";

export default function AITraining() {
  return (
    <div className="p-4 md:p-8">
      <AITrainingPanel />
    </div>
  );
}