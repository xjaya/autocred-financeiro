import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import CurrencyInput from "../components/CurrencyInput";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Plus,
  Search,
  TrendingUp,
  TrendingDown,
  Sparkles,
  Pencil,
  Trash2,
  Calendar,
  DollarSign,
  X,
  CheckCircle,
  Clock,
  Repeat,
  FileText,
} from "lucide-react";
import { format, addMonths, addDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import RecurringOptions from "../components/RecurringOptions";
import AdvancedAIAssistant from "../components/AdvancedAIAssistant";
import AITrainingButton from "../components/AITrainingButton";

const statusColors = {
  pendente: "bg-yellow-100 text-yellow-800 border-yellow-300",
  pago: "bg-green-100 text-green-800 border-green-300",
  recebido: "bg-green-100 text-green-800 border-green-300",
  vencido: "bg-red-100 text-red-800 border-red-300",
  parcialmente_pago: "bg-blue-100 text-blue-800 border-blue-300",
  cancelado: "bg-gray-100 text-gray-800 border-gray-300",
};

const statusLabels = {
  pendente: "Pendente",
  pago: "Pago",
  recebido: "Recebido",
  vencido: "Vencido",
  parcialmente_pago: "Parcialmente Pago",
  cancelado: "Cancelado",
};

export default function Transactions() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");
  const [showDialog, setShowDialog] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [transactionType, setTransactionType] = useState("despesa");
  const [activeTab, setActiveTab] = useState("all");
  const [isRecurring, setIsRecurring] = useState(false);
  const [recurringFrequency, setRecurringFrequency] = useState("mensal");
  const [recurringQuantity, setRecurringQuantity] = useState(1);
  const [selectedForDeletion, setSelectedForDeletion] = useState([]);
  const [showQuickContactDialog, setShowQuickContactDialog] = useState(false);
  const [showQuickCategoryDialog, setShowQuickCategoryDialog] = useState(false);
  const [showQuickCostCenterDialog, setShowQuickCostCenterDialog] = useState(false);
  const [selectedContactName, setSelectedContactName] = useState("");
  const [formDates, setFormDates] = useState({ due_date: "", payment_date: "", issue_date: "", competence_date: "" });
  const [showAutoReview, setShowAutoReview] = useState(false);
  const [aiSuggestedTransactions, setAiSuggestedTransactions] = useState([]);

  const queryClient = useQueryClient();

  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => base44.entities.Transaction.list("-due_date"),
    initialData: [],
    onSuccess: (data) => {
      // Identificar transações que precisam de revisão (recentes sem categoria ou com baixa confiança)
      const needReview = data.filter(t => {
        const isRecent = new Date(t.created_date) > new Date(Date.now() - 24 * 60 * 60 * 1000); // últimas 24h
        const needsReview = !t.category || (t.notes && t.notes.includes("IA:"));
        return isRecent && needsReview;
      });
      setAiSuggestedTransactions(needReview);
      if (needReview.length > 0) {
        setShowAutoReview(true);
      }
    }
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts"],
    queryFn: () => base44.entities.Client.list(),
    initialData: [],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list(),
    initialData: [],
  });

  const { data: costCenters = [] } = useQuery({
    queryKey: ["costCenters"],
    queryFn: () => base44.entities.CostCenter.list(),
    initialData: [],
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ["bankAccounts"],
    queryFn: () => base44.entities.BankAccount.list(),
    initialData: [],
  });

  const { data: aiLearnings = [] } = useQuery({
    queryKey: ["aiLearnings"],
    queryFn: () => base44.entities.AILearning.list(),
    initialData: [],
  });

  const { data: companySettings } = useQuery({
    queryKey: ["companySettings"],
    queryFn: async () => {
      const list = await base44.entities.CompanySettings.list();
      return list[0] || null;
    },
  });

  const createContactMutation = useMutation({
    mutationFn: (data) => base44.entities.Client.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
      setShowQuickContactDialog(false);
      toast.success("Contato cadastrado!");
    },
  });

  const createCategoryMutation = useMutation({
    mutationFn: (data) => base44.entities.Category.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["categories"] });
      setShowQuickCategoryDialog(false);
      toast.success("Categoria cadastrada!");
    },
  });

  const createCostCenterMutation = useMutation({
    mutationFn: (data) => base44.entities.CostCenter.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["costCenters"] });
      setShowQuickCostCenterDialog(false);
      toast.success("Centro de Custo cadastrado!");
    },
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Transaction.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      setShowDialog(false);
      setEditingTransaction(null);
      toast.success("Lançamento criado com sucesso!");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Transaction.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      setShowDialog(false);
      setEditingTransaction(null);
      toast.success("Lançamento atualizado com sucesso!");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Transaction.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      toast.success("Lançamento excluído com sucesso!");
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => {
      const transaction = transactions.find(t => t.id === id);
      return base44.entities.Transaction.update(id, { 
        ...transaction,
        status,
        payment_date: status === "pago" || status === "recebido" ? new Date().toISOString().split('T')[0] : transaction.payment_date
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      toast.success("Status atualizado com sucesso!");
    },
  });

  const filteredTransactions = transactions.filter((t) => {
    const matchesSearch =
      t.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.supplier_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.client_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.category?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = filterType === "all" || t.type === filterType;
    const matchesStatus = filterStatus === "all" || t.status === filterStatus;
    const matchesCategory = filterCategory === "all" || t.category === filterCategory;
    
    const matchesTab =
      activeTab === "all" ||
      (activeTab === "receitas" && t.type === "receita") ||
      (activeTab === "despesas" && t.type === "despesa") ||
      (activeTab === "vencidas" && t.status === "vencido") ||
      (activeTab === "pendentes" && t.status === "pendente");

    return matchesSearch && matchesType && matchesStatus && matchesCategory && matchesTab;
  });

  const totalReceitas = filteredTransactions
    .filter((t) => t.type === "receita" && (t.status === "pago" || t.status === "recebido"))
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const totalDespesas = filteredTransactions
    .filter((t) => t.type === "despesa" && t.status === "pago")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const totalPendente = filteredTransactions
    .filter((t) => t.status === "pendente")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const allCategories = [...new Set(transactions.map((t) => t.category).filter(Boolean))];

  const clients = contacts.filter(c => c.type === "cliente" || c.type === "ambos");
  const suppliers = contacts.filter(c => c.type === "fornecedor" || c.type === "ambos");

  // Função para criar lançamentos recorrentes
  const createRecurringTransactions = async (baseData) => {
    const transactions = [];
    const baseDate = new Date(baseData.due_date);
    
    // Calcular intervalo em dias/meses
    const intervalMap = {
      diario: { unit: "days", value: 1 },
      semanal: { unit: "days", value: 7 },
      quinzenal: { unit: "days", value: 15 },
      mensal: { unit: "months", value: 1 },
      bimestral: { unit: "months", value: 2 },
      trimestral: { unit: "months", value: 3 },
      semestral: { unit: "months", value: 6 },
      anual: { unit: "months", value: 12 },
    };
    
    const interval = intervalMap[recurringFrequency] || { unit: "months", value: 1 }; // Default to monthly

    for (let i = 0; i < recurringQuantity; i++) {
      let nextDate;
      if (interval.unit === "months") {
        nextDate = addMonths(baseDate, interval.value * i);
      } else { // 'days'
        nextDate = addDays(baseDate, interval.value * i);
      }
      
      transactions.push({
        ...baseData,
        due_date: format(nextDate, "yyyy-MM-dd"),
        issue_date: format(nextDate, "yyyy-MM-dd"), // Issue date also advances with due date
        payment_date: null, // Recurring transactions start as pending
        status: "pendente",
        installment: `${i + 1}/${recurringQuantity}`,
        notes: `${baseData.notes || ""} [Recorrência ${i + 1}/${recurringQuantity}]`.trim(),
        recurring: false, // Individual transactions are not recurring themselves
      });
    }
    
    return transactions;
  };

  const handleContactSelect = async (contactName) => {
    if (!contactName) return;
    setSelectedContactName(contactName);
    
    // Buscar padrões da IA
    const patterns = aiLearnings.filter(l => l.learned_supplier === contactName && l.transaction_type === transactionType);
    
    if (patterns.length > 0) {
      const mostUsed = patterns.sort((a, b) => (b.times_used || 0) - (a.times_used || 0))[0];
      
      // Auto-preencher com padrões aprendidos
      const form = document.querySelector('form');
      if (form) {
        if (mostUsed.description_pattern) {
          const descInput = form.querySelector('[name="description"]');
          if (descInput && !descInput.value) descInput.value = mostUsed.description_pattern;
        }
        if (mostUsed.learned_category) {
          const catSelect = form.querySelector('[name="category"]');
          if (catSelect) catSelect.value = mostUsed.learned_category;
        }
        if (mostUsed.learned_cost_center) {
          const ccSelect = form.querySelector('[name="cost_center"]');
          if (ccSelect) ccSelect.value = mostUsed.learned_cost_center;
        }
      }
    }
  };

  const handleDateChange = (field, value) => {
    const newDates = { ...formDates, [field]: value };
    
    // Auto-preencher outras datas se estiverem vazias
    if (value && !formDates.due_date && !formDates.payment_date && !formDates.issue_date && !formDates.competence_date) {
      newDates.due_date = value;
      newDates.payment_date = value;
      newDates.issue_date = value;
      newDates.competence_date = value;
    }
    
    setFormDates(newDates);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    if (!formData.get("bank_account")) {
      toast.error("Conta bancária é obrigatória!");
      return;
    }

    const data = {
      type: formData.get("type"),
      description: formData.get("description"),
      category: formData.get("category"),
      subcategory: formData.get("subcategory"),
      cost_center: formData.get("cost_center"),
      amount: parseFloat(formData.get("amount")),
      due_date: formData.get("due_date"),
      payment_date: formData.get("payment_date") || null,
      issue_date: formData.get("issue_date") || null,
      competence_date: formData.get("competence_date") || null,
      payment_method: formData.get("payment_method"),
      status: formData.get("status"),
      supplier_name: formData.get("supplier_name"),
      client_name: formData.get("client_name"),
      document_number: formData.get("document_number"),
      invoice_number: formData.get("invoice_number"),
      bank_account: formData.get("bank_account"),
      installment: formData.get("installment"),
      recurring: isRecurring,
      recurring_frequency: isRecurring ? recurringFrequency : null,
      notes: formData.get("notes"),
      interest_value: parseFloat(formData.get("interest_value") || 0),
      discount_value: parseFloat(formData.get("discount_value") || 0),
      fine_value: parseFloat(formData.get("fine_value") || 0),
    };

    // Salvar padrão na IA
    if (!editingTransaction && (data.client_name || data.supplier_name)) {
      const contactName = data.client_name || data.supplier_name;
      const existing = aiLearnings.find(l => 
        l.learned_supplier === contactName && 
        l.description_pattern === data.description &&
        l.transaction_type === data.type
      );

      if (existing) {
        await base44.entities.AILearning.update(existing.id, {
          ...existing,
          times_used: (existing.times_used || 0) + 1,
          last_used: new Date().toISOString()
        });
      } else {
        await base44.entities.AILearning.create({
          description_pattern: data.description,
          learned_category: data.category,
          learned_subcategory: data.subcategory,
          learned_cost_center: data.cost_center,
          learned_supplier: contactName,
          transaction_type: data.type,
          confidence_score: 5,
          times_used: 1,
          last_used: new Date().toISOString()
        });
      }
      queryClient.invalidateQueries({ queryKey: ["aiLearnings"] });
    }

    if (editingTransaction) {
      updateMutation.mutate({ id: editingTransaction.id, data });
    } else {
      if (isRecurring && recurringQuantity > 1) {
        toast.info(`Criando ${recurringQuantity} lançamentos recorrentes...`);
        try {
          const recurringTransactions = await createRecurringTransactions(data);
          
          for (const transaction of recurringTransactions) {
            await base44.entities.Transaction.create(transaction);
          }
          
          queryClient.invalidateQueries({ queryKey: ["transactions"] });
          setShowDialog(false);
          toast.success(`✅ ${recurringQuantity} lançamentos recorrentes criados com sucesso!`);
        } catch (error) {
          toast.error("Falha ao criar lançamentos recorrentes. Tente novamente.");
          console.error("Error creating recurring transactions:", error);
        }
      } else {
        createMutation.mutate(data);
      }
    }
  };

  const clearFilters = () => {
    setFilterType("all");
    setFilterStatus("all");
    setFilterCategory("all");
    setSearchTerm("");
  };

  const correctDatesMutation = useMutation({
    mutationFn: async () => {
      let correctedCount = 0;
      
      for (const trans of transactions) {
        if (!trans.due_date) continue;
        
        // Encontrar transações com datas próximas (±1 dia)
        const similarTransactions = transactions.filter(t => {
          if (!t.due_date || t.id === trans.id) return false;
          const date1 = new Date(trans.due_date);
          const date2 = new Date(t.due_date);
          const diffDays = Math.abs((date1 - date2) / (1000 * 60 * 60 * 24));
          return diffDays >= 0.9 && diffDays <= 1.1;
        });
        
        if (similarTransactions.length > 0) {
          // Usar a data mais comum como referência
          const allDates = [trans, ...similarTransactions].map(t => t.due_date);
          const dateCounts = {};
          allDates.forEach(d => dateCounts[d] = (dateCounts[d] || 0) + 1);
          const correctDate = Object.keys(dateCounts).reduce((a, b) => dateCounts[a] > dateCounts[b] ? a : b);
          
          // Corrigir datas diferentes
          for (const t of [trans, ...similarTransactions]) {
            if (t.due_date !== correctDate) {
              await base44.entities.Transaction.update(t.id, {
                due_date: correctDate,
                payment_date: t.payment_date === t.due_date ? correctDate : t.payment_date,
                issue_date: t.issue_date === t.due_date ? correctDate : t.issue_date,
                competence_date: t.competence_date === t.due_date ? correctDate : t.competence_date
              });
              correctedCount++;
            }
          }
        }
      }
      
      return correctedCount;
    },
    onSuccess: (correctedCount) => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      if (correctedCount > 0) {
        toast.success(`📅 ${correctedCount} datas corrigidas!`);
      } else {
        toast.info("✅ Todas as datas estão corretas");
      }
    },
    onError: () => {
      toast.error("❌ Erro ao corrigir datas");
    }
  });

  const handleStatusChange = (id, newStatus) => {
    updateStatusMutation.mutate({ id, status: newStatus });
  };

  const getStatusDisplay = (transaction) => {
    if (transaction.type === "receita") {
      return transaction.status === "pago" ? "Recebido" : statusLabels[transaction.status];
    }
    return statusLabels[transaction.status];
  };

  const generateReceipt = async (transaction) => {
    if (transaction.type !== "receita") {
      toast.error("Recibo disponível apenas para receitas");
      return;
    }

    const settings = companySettings || {};
    const receiptHTML = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Recibo - ${transaction.document_number || transaction.id}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; padding: 40px; background: #f5f5f5; }
    .receipt { max-width: 800px; margin: 0 auto; background: white; padding: 40px; border: 2px solid #333; }
    .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px; }
    .header h1 { font-size: 24px; color: #333; margin-bottom: 10px; }
    .header p { font-size: 12px; color: #666; }
    .receipt-title { text-align: center; font-size: 28px; font-weight: bold; margin: 20px 0; text-transform: uppercase; }
    .value-box { text-align: center; background: #f9f9f9; border: 2px solid #333; padding: 20px; margin: 20px 0; }
    .value-box .label { font-size: 14px; color: #666; margin-bottom: 10px; }
    .value-box .amount { font-size: 32px; font-weight: bold; color: #10B981; }
    .info-row { display: flex; justify-content: space-between; margin: 15px 0; padding: 10px 0; border-bottom: 1px solid #eee; }
    .info-row .label { font-weight: bold; color: #333; }
    .info-row .value { color: #666; }
    .signature { margin-top: 60px; padding-top: 20px; }
    .signature-line { border-top: 1px solid #333; width: 300px; margin: 0 auto; padding-top: 10px; text-align: center; font-size: 12px; }
    .footer { margin-top: 30px; text-align: center; font-size: 11px; color: #999; border-top: 1px solid #eee; padding-top: 20px; }
    @media print { body { padding: 0; background: white; } }
  </style>
</head>
<body>
  <div class="receipt">
    <div class="header">
      <h1>${settings.company_name || "AUTOCRED PROMOTORA"}</h1>
      ${settings.cnpj ? `<p>CNPJ: ${settings.cnpj}</p>` : ""}
      ${settings.address ? `<p>${settings.address}</p>` : ""}
      ${settings.phone ? `<p>Tel: ${settings.phone}</p>` : ""}
      ${settings.email ? `<p>Email: ${settings.email}</p>` : ""}
    </div>

    <div class="receipt-title">RECIBO</div>

    <div class="value-box">
      <div class="label">VALOR RECEBIDO</div>
      <div class="amount">R$ ${transaction.amount?.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
    </div>

    <div class="info-row">
      <span class="label">Recebemos de:</span>
      <span class="value">${transaction.client_name || "---"}</span>
    </div>

    <div class="info-row">
      <span class="label">Referente a:</span>
      <span class="value">${transaction.description}</span>
    </div>

    ${transaction.category ? `
    <div class="info-row">
      <span class="label">Categoria:</span>
      <span class="value">${transaction.category}</span>
    </div>
    ` : ""}

    <div class="info-row">
      <span class="label">Data de Emissão:</span>
      <span class="value">${transaction.issue_date ? format(new Date(transaction.issue_date), "dd/MM/yyyy") : format(new Date(), "dd/MM/yyyy")}</span>
    </div>

    ${transaction.payment_date ? `
    <div class="info-row">
      <span class="label">Data de Pagamento:</span>
      <span class="value">${format(new Date(transaction.payment_date), "dd/MM/yyyy")}</span>
    </div>
    ` : ""}

    <div class="info-row">
      <span class="label">Forma de Pagamento:</span>
      <span class="value">${transaction.payment_method?.replace("_", " ").toUpperCase() || "---"}</span>
    </div>

    ${transaction.document_number ? `
    <div class="info-row">
      <span class="label">Documento Nº:</span>
      <span class="value">${transaction.document_number}</span>
    </div>
    ` : ""}

    ${transaction.invoice_number ? `
    <div class="info-row">
      <span class="label">Nota Fiscal Nº:</span>
      <span class="value">${transaction.invoice_number}</span>
    </div>
    ` : ""}

    ${transaction.notes ? `
    <div class="info-row">
      <span class="label">Observações:</span>
      <span class="value">${transaction.notes}</span>
    </div>
    ` : ""}

    <div class="signature">
      <div class="signature-line">
        ${settings.company_name || "AUTOCRED PROMOTORA"}
        <br>Assinatura e Carimbo
      </div>
    </div>

    <div class="footer">
      <p>Este recibo foi gerado eletronicamente em ${format(new Date(), "dd/MM/yyyy 'às' HH:mm")}</p>
      <p>Documento sem valor fiscal</p>
    </div>
  </div>
  <script>
    window.onload = function() { window.print(); };
  </script>
</body>
</html>
    `;

    const printWindow = window.open("", "_blank");
    printWindow.document.write(receiptHTML);
    printWindow.document.close();
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white drop-shadow-lg">Lançamentos Financeiros</h1>
          <p className="text-blue-200 mt-1">Contas a Pagar e Receber</p>
          {aiSuggestedTransactions.length > 0 && (
            <Badge className="bg-purple-500 text-white mt-2 animate-pulse">
              <Sparkles className="w-3 h-3 mr-1" />
              {aiSuggestedTransactions.length} transação(ões) precisam de revisão
            </Badge>
          )}
        </div>
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button 
              onClick={() => {
                setEditingTransaction(null);
                setTransactionType("despesa");
                setIsRecurring(false);
                setRecurringQuantity(1);
                setRecurringFrequency("mensal");
                setFormDates({ due_date: "", payment_date: "", issue_date: "", competence_date: "" });
                setSelectedContactName("");
              }} 
              className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600 shadow-lg"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Lançamento
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-blue-900 border-blue-700 text-white">
            <DialogHeader>
              <DialogTitle className="text-xl text-white">
                {editingTransaction ? "Editar Lançamento" : "Novo Lançamento"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Tipo*</Label>
                  <Select 
                    name="type" 
                    defaultValue={editingTransaction?.type || transactionType} 
                    onValueChange={setTransactionType}
                    required
                  >
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      <SelectItem value="receita">Receita / Conta a Receber</SelectItem>
                      <SelectItem value="despesa">Despesa / Conta a Pagar</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-blue-200">Status*</Label>
                  <Select name="status" defaultValue={editingTransaction?.status || "pendente"} required>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      {transactionType === "receita" ? (
                        <>
                          <SelectItem value="pendente">A Receber</SelectItem>
                          <SelectItem value="pago">Recebida</SelectItem>
                        </>
                      ) : (
                        <>
                          <SelectItem value="pendente">A Pagar</SelectItem>
                          <SelectItem value="pago">Paga</SelectItem>
                        </>
                      )}
                      <SelectItem value="vencido">Vencido</SelectItem>
                      <SelectItem value="parcialmente_pago">Parcialmente Pago</SelectItem>
                      <SelectItem value="cancelado">Cancelado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                {transactionType === "receita" ? (
                  <>
                    <Label className="text-blue-200 flex items-center justify-between">
                      Cliente
                      <Button type="button" size="sm" variant="outline" onClick={() => setShowQuickContactDialog(true)} className="h-6 px-2">
                        <Plus className="w-3 h-3" />
                      </Button>
                    </Label>
                    <Select name="client_name" defaultValue={editingTransaction?.client_name} onValueChange={handleContactSelect}>
                      <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                        <SelectValue placeholder="Selecione o cliente" />
                      </SelectTrigger>
                      <SelectContent className="bg-blue-900 border-blue-700">
                        {clients.map((client) => (
                          <SelectItem key={client.id} value={client.name}>
                            {client.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </>
                ) : (
                  <>
                    <Label className="text-blue-200 flex items-center justify-between">
                      Fornecedor
                      <Button type="button" size="sm" variant="outline" onClick={() => setShowQuickContactDialog(true)} className="h-6 px-2">
                        <Plus className="w-3 h-3" />
                      </Button>
                    </Label>
                    <Select name="supplier_name" defaultValue={editingTransaction?.supplier_name} onValueChange={handleContactSelect}>
                      <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                        <SelectValue placeholder="Selecione o fornecedor" />
                      </SelectTrigger>
                      <SelectContent className="bg-blue-900 border-blue-700">
                        {suppliers.map((supplier) => (
                          <SelectItem key={supplier.id} value={supplier.name}>
                            {supplier.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </>
                )}
              </div>

              <div>
                <Label className="text-blue-200">Descrição*</Label>
                <Input
                  name="description"
                  defaultValue={editingTransaction?.description}
                  placeholder="Descrição do lançamento"
                  required
                  className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-blue-200 flex items-center justify-between">
                    Categoria
                    <Button type="button" size="sm" variant="outline" onClick={() => setShowQuickCategoryDialog(true)} className="h-6 px-2">
                      <Plus className="w-3 h-3" />
                    </Button>
                  </Label>
                  <Select name="category" defaultValue={editingTransaction?.category}>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      {categories.filter(c => c.type === transactionType || c.type === "ambos").map((cat) => (
                        <SelectItem key={cat.id} value={cat.name}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-blue-200">Subcategoria</Label>
                  <Input
                    name="subcategory"
                    defaultValue={editingTransaction?.subcategory}
                    placeholder="Ex: Anúncios Online"
                    className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                  />
                </div>
                <div>
                  <Label className="text-blue-200 flex items-center justify-between">
                    Centro de Custo
                    <Button type="button" size="sm" variant="outline" onClick={() => setShowQuickCostCenterDialog(true)} className="h-6 px-2">
                      <Plus className="w-3 h-3" />
                    </Button>
                  </Label>
                  <Select name="cost_center" defaultValue={editingTransaction?.cost_center}>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      {costCenters.map((cc) => (
                        <SelectItem key={cc.id} value={cc.name}>
                          {cc.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-blue-200">Valor (R$)*</Label>
                  <Input
                    name="amount"
                    type="number"
                    step="0.01"
                    defaultValue={editingTransaction?.amount}
                    placeholder="0,00"
                    required
                    className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Forma de Pagamento</Label>
                  <Select name="payment_method" defaultValue={editingTransaction?.payment_method}>
                    <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent className="bg-blue-900 border-blue-700">
                      <SelectItem value="dinheiro">Dinheiro</SelectItem>
                      <SelectItem value="pix">PIX</SelectItem>
                      <SelectItem value="transferencia_bancaria">Transferência Bancária</SelectItem>
                      <SelectItem value="cartao_credito">Cartão de Crédito</SelectItem>
                      <SelectItem value="cartao_debito">Cartão de Débito</SelectItem>
                      <SelectItem value="boleto">Boleto</SelectItem>
                      <SelectItem value="cheque">Cheque</SelectItem>
                      <SelectItem value="outros">Outros</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-4">
                <div>
                  <Label className="text-blue-200">Data de Vencimento*</Label>
                  <Input
                    name="due_date"
                    type="date"
                    value={formDates.due_date || editingTransaction?.due_date || ""}
                    onChange={(e) => handleDateChange("due_date", e.target.value)}
                    required
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Data de Pagamento</Label>
                  <Input
                    name="payment_date"
                    type="date"
                    value={formDates.payment_date || editingTransaction?.payment_date || ""}
                    onChange={(e) => handleDateChange("payment_date", e.target.value)}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Data de Emissão</Label>
                  <Input
                    name="issue_date"
                    type="date"
                    value={formDates.issue_date || editingTransaction?.issue_date || ""}
                    onChange={(e) => handleDateChange("issue_date", e.target.value)}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Data de Competência</Label>
                  <Input
                    name="competence_date"
                    type="date"
                    value={formDates.competence_date || editingTransaction?.competence_date || ""}
                    onChange={(e) => handleDateChange("competence_date", e.target.value)}
                    className="bg-blue-950/50 border-blue-700 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-blue-200">Nº Documento</Label>
                  <Input
                    name="document_number"
                    defaultValue={editingTransaction?.document_number}
                    placeholder="Número do documento"
                    className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Nº Nota Fiscal</Label>
                  <Input
                    name="invoice_number"
                    defaultValue={editingTransaction?.invoice_number}
                    placeholder="NF-e"
                    className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Parcela</Label>
                  <Input
                    name="installment"
                    defaultValue={editingTransaction?.installment}
                    placeholder="Ex: 1/12"
                    className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                  />
                </div>
              </div>

              <div>
                <Label className="text-blue-200">Conta Bancária* (Obrigatório)</Label>
                <Select name="bank_account" defaultValue={editingTransaction?.bank_account} required>
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue placeholder="Selecione a conta (obrigatório)" />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    {bankAccounts.map((ba) => (
                      <SelectItem key={ba.id} value={ba.name}>
                        {ba.name} - {ba.bank}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* RECORRÊNCIA */}
              <div className="border-t border-blue-700 pt-4">
                <div className="flex items-center space-x-2 mb-4">
                  <Checkbox 
                    id="recurring" 
                    checked={isRecurring}
                    onCheckedChange={setIsRecurring}
                  />
                  <label htmlFor="recurring" className="text-blue-200 cursor-pointer flex items-center gap-2">
                    <Repeat className="w-4 h-4" />
                    Lançamento Recorrente (criar múltiplos lançamentos automaticamente)
                  </label>
                </div>
                {isRecurring && (
                  <RecurringOptions
                    frequency={recurringFrequency}
                    quantity={recurringQuantity}
                    onFrequencyChange={setRecurringFrequency}
                    onQuantityChange={setRecurringQuantity}
                  />
                )}
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-blue-200">Juros (R$)</Label>
                  <Input
                    name="interest_value"
                    type="number"
                    step="0.01"
                    defaultValue={editingTransaction?.interest_value || 0}
                    placeholder="0,00"
                    className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Desconto (R$)</Label>
                  <Input
                    name="discount_value"
                    type="number"
                    step="0.01"
                    defaultValue={editingTransaction?.discount_value || 0}
                    placeholder="0,00"
                    className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                  />
                </div>
                <div>
                  <Label className="text-blue-200">Multa (R$)</Label>
                  <Input
                    name="fine_value"
                    type="number"
                    step="0.01"
                    defaultValue={editingTransaction?.fine_value || 0}
                    placeholder="0,00"
                    className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                  />
                </div>
              </div>

              <div>
                <Label className="text-blue-200">Observações</Label>
                <Textarea
                  name="notes"
                  defaultValue={editingTransaction?.notes}
                  placeholder="Informações adicionais..."
                  rows={3}
                  className="bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-blue-700">
                <Button type="button" variant="outline" onClick={() => setShowDialog(false)} className="border-blue-700 text-blue-200 hover:bg-blue-800">
                  Cancelar
                </Button>
                <Button type="submit" className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600">
                  {editingTransaction ? "Atualizar" : (isRecurring && recurringQuantity > 1 ? `Criar ${recurringQuantity} Lançamentos` : "Criar Lançamento")}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Dialog Cadastro Rápido Contato */}
        <Dialog open={showQuickContactDialog} onOpenChange={setShowQuickContactDialog}>
          <DialogContent className="bg-blue-900 border-blue-700">
            <DialogHeader>
              <DialogTitle className="text-white">Cadastro Rápido - {transactionType === "receita" ? "Cliente" : "Fornecedor"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.target);
              createContactMutation.mutate({
                name: fd.get("name"),
                type: transactionType === "receita" ? "cliente" : "fornecedor",
                status: "ativo"
              });
            }} className="space-y-4">
              <div>
                <Label className="text-blue-200">Nome*</Label>
                <Input name="name" required className="bg-blue-950/50 border-blue-700 text-white" />
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setShowQuickContactDialog(false)} className="border-blue-700 text-blue-200">Cancelar</Button>
                <Button type="submit" className="bg-gradient-to-r from-blue-600 to-blue-500">Cadastrar</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Dialog Cadastro Rápido Categoria */}
        <Dialog open={showQuickCategoryDialog} onOpenChange={setShowQuickCategoryDialog}>
          <DialogContent className="bg-blue-900 border-blue-700">
            <DialogHeader>
              <DialogTitle className="text-white">Cadastro Rápido - Categoria</DialogTitle>
            </DialogHeader>
            <form onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.target);
              createCategoryMutation.mutate({
                name: fd.get("name"),
                type: transactionType,
                status: "ativo"
              });
            }} className="space-y-4">
              <div>
                <Label className="text-blue-200">Nome*</Label>
                <Input name="name" required className="bg-blue-950/50 border-blue-700 text-white" />
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setShowQuickCategoryDialog(false)} className="border-blue-700 text-blue-200">Cancelar</Button>
                <Button type="submit" className="bg-gradient-to-r from-blue-600 to-blue-500">Cadastrar</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Dialog Cadastro Rápido Centro de Custo */}
        <Dialog open={showQuickCostCenterDialog} onOpenChange={setShowQuickCostCenterDialog}>
          <DialogContent className="bg-blue-900 border-blue-700">
            <DialogHeader>
              <DialogTitle className="text-white">Cadastro Rápido - Centro de Custo</DialogTitle>
            </DialogHeader>
            <form onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.target);
              createCostCenterMutation.mutate({
                name: fd.get("name"),
                status: "ativo"
              });
            }} className="space-y-4">
              <div>
                <Label className="text-blue-200">Nome*</Label>
                <Input name="name" required className="bg-blue-950/50 border-blue-700 text-white" />
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setShowQuickCostCenterDialog(false)} className="border-blue-700 text-blue-200">Cancelar</Button>
                <Button type="submit" className="bg-gradient-to-r from-blue-600 to-blue-500">Cadastrar</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Revisão de Auto-Categorização */}
      {showAutoReview && aiSuggestedTransactions.length > 0 && (
        <Card className="border-purple-700/50 bg-gradient-to-br from-purple-900/80 to-purple-800/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-400" />
                Revisão de Categorização Automática
              </div>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setShowAutoReview(false)}
                className="text-purple-300 hover:text-white"
              >
                <X className="w-4 h-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {aiSuggestedTransactions.slice(0, 3).map((trans) => (
              <SmartCategorization
                key={trans.id}
                transaction={trans}
                onApprove={async () => {
                  setAiSuggestedTransactions(prev => prev.filter(t => t.id !== trans.id));
                  if (aiSuggestedTransactions.length <= 1) {
                    setShowAutoReview(false);
                  }
                }}
                onCorrect={async (corrections) => {
                  await updateMutation.mutateAsync({
                    id: trans.id,
                    data: {
                      category: corrections.category,
                      subcategory: corrections.subcategory,
                      cost_center: corrections.cost_center
                    }
                  });
                  setAiSuggestedTransactions(prev => prev.filter(t => t.id !== trans.id));
                  if (aiSuggestedTransactions.length <= 1) {
                    setShowAutoReview(false);
                  }
                }}
              />
            ))}
            {aiSuggestedTransactions.length > 3 && (
              <p className="text-purple-300 text-sm text-center">
                +{aiSuggestedTransactions.length - 3} transação(ões) aguardando revisão
              </p>
            )}
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-green-500/50 bg-gradient-to-br from-green-800/80 to-green-700/80 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-200 font-medium">Receitas</p>
                <p className="text-2xl font-bold text-white mt-1">
                  R$ {totalReceitas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </p>
              </div>
              <TrendingUp className="w-10 h-10 text-green-300 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-red-500/50 bg-gradient-to-br from-red-800/80 to-red-700/80 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-200 font-medium">Despesas</p>
                <p className="text-2xl font-bold text-white mt-1">
                  R$ {totalDespesas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </p>
              </div>
              <TrendingDown className="w-10 h-10 text-red-300 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-500/50 bg-gradient-to-br from-blue-800/80 to-blue-700/80 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-200 font-medium">Saldo</p>
                <p className={`text-2xl font-bold mt-1 ${totalReceitas - totalDespesas >= 0 ? "text-white" : "text-red-300"}`}>
                  R$ {(totalReceitas - totalDespesas).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </p>
              </div>
              <DollarSign className="w-10 h-10 text-blue-300 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-yellow-500/50 bg-gradient-to-br from-yellow-800/80 to-yellow-700/80 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-yellow-200 font-medium">Pendentes</p>
                <p className="text-2xl font-bold text-white mt-1">
                  R$ {totalPendente.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </p>
              </div>
              <Calendar className="w-10 h-10 text-yellow-300 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <div className="flex flex-col md:flex-row gap-4">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full md:w-auto md:inline-grid grid-cols-5 h-auto bg-blue-950/50">
                <TabsTrigger value="all" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white">Todos</TabsTrigger>
                <TabsTrigger value="receitas" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white">Receitas</TabsTrigger>
                <TabsTrigger value="despesas" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white">Despesas</TabsTrigger>
                <TabsTrigger value="pendentes" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white">Pendentes</TabsTrigger>
                <TabsTrigger value="vencidas" className="text-blue-200 data-[state=active]:bg-blue-700 data-[state=active]:text-white">Vencidas</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="flex gap-2">
              {selectedForDeletion.length > 0 ? (
                <>
                  <Button
                    onClick={async () => {
                      if (!confirm(`Excluir ${selectedForDeletion.length} lançamentos selecionados?`)) return;
                      for (const id of selectedForDeletion) {
                        await deleteMutation.mutateAsync(id);
                      }
                      setSelectedForDeletion([]);
                      toast.success(`${selectedForDeletion.length} lançamentos excluídos!`);
                    }}
                    variant="outline"
                    className="border-red-700 text-red-300 hover:bg-red-900/20"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Excluir Selecionados ({selectedForDeletion.length})
                  </Button>
                  <Button
                    onClick={() => setSelectedForDeletion([])}
                    variant="outline"
                    className="border-blue-700 text-blue-300 hover:bg-blue-800"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Cancelar
                  </Button>
                </>
              ) : (
                <Button
                  onClick={() => {
                    setSelectedForDeletion(filteredTransactions.map(t => t.id));
                  }}
                  variant="outline"
                  className="border-yellow-700 text-yellow-300 hover:bg-yellow-900/20"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Selecionar Todos ({filteredTransactions.length})
                </Button>
              )}
            </div>
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-400 w-4 h-4" />
              <Input
                placeholder="Buscar por descrição, fornecedor, cliente ou categoria..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-blue-950/50 border-blue-700 text-white placeholder:text-blue-400"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-40 bg-blue-950/50 border-blue-700 text-white">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent className="bg-blue-900 border-blue-700">
                <SelectItem value="all">Todos status</SelectItem>
                <SelectItem value="pendente">Pendente</SelectItem>
                <SelectItem value="pago">Pago</SelectItem>
                <SelectItem value="recebido">Recebido</SelectItem>
                <SelectItem value="vencido">Vencido</SelectItem>
                <SelectItem value="parcialmente_pago">Parcialmente Pago</SelectItem>
                <SelectItem value="cancelado">Cancelado</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-full md:w-40 bg-blue-950/50 border-blue-700 text-white">
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent className="bg-blue-900 border-blue-700">
                <SelectItem value="all">Todas categorias</SelectItem>
                {allCategories.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {(searchTerm || filterType !== "all" || filterStatus !== "all" || filterCategory !== "all") && (
              <Button variant="outline" size="icon" onClick={clearFilters} className="border-blue-700 text-blue-300 hover:bg-blue-800">
                <X className="w-4 h-4" />
              </Button>
            )}
            <Button
              onClick={() => correctDatesMutation.mutate()}
              disabled={correctDatesMutation.isLoading}
              variant="outline"
              className="border-purple-700 text-purple-200 hover:bg-purple-800"
              title="Corrige automaticamente datas com diferença de ±1 dia"
            >
              {correctDatesMutation.isLoading ? <Clock className="w-4 h-4 mr-2 animate-spin" /> : <Calendar className="w-4 h-4 mr-2" />}
              {correctDatesMutation.isLoading ? "Corrigindo..." : "Corrigir Datas"}
            </Button>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-blue-950/50 border-blue-700 hover:bg-blue-950/70">
                  <TableHead className="text-blue-300 w-12">
                    <Checkbox
                      checked={selectedForDeletion.length === filteredTransactions.length && filteredTransactions.length > 0}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedForDeletion(filteredTransactions.map(t => t.id));
                        } else {
                          setSelectedForDeletion([]);
                        }
                      }}
                    />
                  </TableHead>
                  <TableHead className="text-blue-300">Vencimento</TableHead>
                  <TableHead className="text-blue-300">Descrição</TableHead>
                  <TableHead className="text-blue-300">Cliente/Fornecedor</TableHead>
                  <TableHead className="text-blue-300">Categoria</TableHead>
                  <TableHead className="text-blue-300">Conta</TableHead>
                  <TableHead className="text-blue-300">Tipo</TableHead>
                  <TableHead className="text-blue-300">Valor</TableHead>
                  <TableHead className="text-blue-300">Status</TableHead>
                  <TableHead className="text-right text-blue-300">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  [...Array(5)].map((_, i) => (
                    <TableRow key={i} className="border-blue-700">
                      <TableCell><Skeleton className="h-4 w-8 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-20 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-32 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-20 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-20 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-20 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-6 w-20 bg-blue-700/50" /></TableCell>
                      <TableCell><Skeleton className="h-8 w-20 bg-blue-700/50" /></TableCell>
                    </TableRow>
                  ))
                ) : filteredTransactions.length === 0 ? (
                  <TableRow className="border-blue-700">
                    <TableCell colSpan={10} className="text-center py-8 text-blue-300">
                      Nenhum lançamento encontrado
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredTransactions.map((transaction) => (
                    <TableRow key={transaction.id} className={`border-blue-700 hover:bg-blue-800/30 ${selectedForDeletion.includes(transaction.id) ? 'bg-red-900/20' : ''}`}>
                      <TableCell>
                        <Checkbox
                          checked={selectedForDeletion.includes(transaction.id)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedForDeletion([...selectedForDeletion, transaction.id]);
                            } else {
                              setSelectedForDeletion(selectedForDeletion.filter(id => id !== transaction.id));
                            }
                          }}
                        />
                      </TableCell>
                      <TableCell className="font-medium text-white">
                        {format(new Date(transaction.due_date), "dd/MM/yyyy", { locale: ptBR })}
                      </TableCell>
                      <TableCell className="max-w-xs truncate text-blue-100">{transaction.description}</TableCell>
                      <TableCell className="text-sm text-blue-200">
                        {transaction.supplier_name || transaction.client_name || "-"}
                      </TableCell>
                      <TableCell className="text-sm text-blue-200">{transaction.category || "-"}</TableCell>
                      <TableCell className="text-sm text-blue-200">{transaction.bank_account || "-"}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={transaction.type === "receita" ? "text-green-300 border-green-500 bg-green-900/30" : "text-red-300 border-red-500 bg-red-900/30"}>
                          {transaction.type === "receita" ? "Receita" : "Despesa"}
                        </Badge>
                      </TableCell>
                      <TableCell className={`font-semibold ${transaction.type === "receita" ? "text-green-300" : "text-red-300"}`}>
                        R$ {transaction.amount?.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Badge 
                              variant="outline" 
                              className={`cursor-pointer ${
                                transaction.status === "pendente" ? "bg-yellow-100 text-yellow-800 border-yellow-300" :
                                (transaction.status === "pago" || transaction.status === "recebido") ? "bg-green-100 text-green-800 border-green-300" :
                                "bg-gray-100 text-gray-800 border-gray-300"
                              }`}
                            >
                              {getStatusDisplay(transaction)}
                            </Badge>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent className="bg-blue-900 border-blue-700">
                            <DropdownMenuItem 
                              onClick={() => handleStatusChange(transaction.id, transaction.type === "receita" ? "recebido" : "pago")}
                              className="text-white hover:bg-blue-800"
                            >
                              <CheckCircle className="w-4 h-4 mr-2 text-green-400" />
                              Marcar como {transaction.type === "receita" ? "Recebido" : "Pago"}
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleStatusChange(transaction.id, "pendente")}
                              className="text-white hover:bg-blue-800"
                            >
                              <Clock className="w-4 h-4 mr-2 text-yellow-400" />
                              Marcar como Pendente
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          {transaction.type === "receita" && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => generateReceipt(transaction)}
                              className="border-green-700 text-green-300 hover:bg-green-700 hover:text-white"
                              title="Emitir Recibo PDF"
                            >
                              <FileText className="w-4 h-4 mr-1" />
                              Recibo
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setEditingTransaction(transaction);
                              setTransactionType(transaction.type);
                              setIsRecurring(transaction.recurring || false);
                              setRecurringFrequency(transaction.recurring_frequency || "mensal");
                              setRecurringQuantity(1);
                              setFormDates({
                                due_date: transaction.due_date || "",
                                payment_date: transaction.payment_date || "",
                                issue_date: transaction.issue_date || "",
                                competence_date: transaction.competence_date || ""
                              });
                              setShowDialog(true);
                            }}
                            className="border-blue-700 text-blue-300 hover:bg-blue-700 hover:text-white"
                            title="Editar Lançamento"
                          >
                            <Pencil className="w-4 h-4 mr-1" />
                            Editar
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              if (confirm("Tem certeza que deseja excluir este lançamento?")) {
                                deleteMutation.mutate(transaction.id);
                              }
                            }}
                            className="border-red-700 text-red-300 hover:bg-red-700 hover:text-white"
                            title="Excluir Lançamento"
                          >
                            <Trash2 className="w-4 h-4 mr-1" />
                            Excluir
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Assistente IA Avançado */}
      <AdvancedAIAssistant 
        context={`Total Transações: ${transactions.length}, Receitas: ${totalReceitas.toFixed(2)}, Despesas: ${totalDespesas.toFixed(2)}, Pendente: ${totalPendente.toFixed(2)}`}
        pageInfo="Lançamentos Financeiros - Gestão completa de receitas e despesas"
      />
    </div>
  );
}