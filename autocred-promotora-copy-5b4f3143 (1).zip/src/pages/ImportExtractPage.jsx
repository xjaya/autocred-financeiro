import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Upload,
  FileText,
  CheckCircle,
  Sparkles,
  RefreshCw,
  Trash2,
  TrendingUp,
  TrendingDown,
  Filter,
  Brain,
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";
import TransactionPreviewTable from "../components/extract/TransactionPreviewTable";
import BankHeaderDetector from "../components/extract/BankHeaderDetector";
import AITrainingPanel from "../components/extract/AITrainingPanel";
import ErrorReportPanel from "../components/extract/ErrorReportPanel";

export default function ImportExtractPage() {
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState("");
  const [progress, setProgress] = useState(0);
  const [extractedTransactions, setExtractedTransactions] = useState([]);
  const [bankInfo, setBankInfo] = useState(null);
  const [selectedAccount, setSelectedAccount] = useState("");
  const [showPreview, setShowPreview] = useState(false);
  const [deduplicateEnabled, setDeduplicateEnabled] = useState(true);
  const [showAccountMapping, setShowAccountMapping] = useState(false);
  const [accountMapping, setAccountMapping] = useState({});
  const [extractionErrors, setExtractionErrors] = useState([]);
  const [showTraining, setShowTraining] = useState(false);

  const queryClient = useQueryClient();

  const { data: imports = [] } = useQuery({
    queryKey: ["extractImports"],
    queryFn: () => base44.entities.ExtractImport.list("-import_date"),
    initialData: [],
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ["bankAccounts"],
    queryFn: () => base44.entities.BankAccount.list(),
    initialData: [],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => base44.entities.Category.list(),
    initialData: [],
  });

  const { data: costCenters = [] } = useQuery({
    queryKey: ["costCenters"],
    queryFn: () => base44.entities.CostCenter.list(),
    initialData: [],
  });

  const { data: aiLearnings = [] } = useQuery({
    queryKey: ["aiLearnings"],
    queryFn: () => base44.entities.AILearning.list(),
    initialData: [],
  });

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      const fileName = file.name.toLowerCase();
      const isPDF = fileName.endsWith('.pdf');
      const isOFX = fileName.endsWith('.ofx');
      
      if (isPDF) {
        const correctedFile = new File([file], file.name, { type: "application/pdf" });
        setSelectedFile(correctedFile);
        setShowPreview(false);
        setExtractedTransactions([]);
        setBankInfo(null);
        toast.success("✅ PDF selecionado para processamento");
      } else if (isOFX) {
        setSelectedFile(file);
        setShowPreview(false);
        setExtractedTransactions([]);
        setBankInfo(null);
        toast.success("✅ Arquivo OFX selecionado - Processamento direto!");
      } else {
        toast.error("Selecione um arquivo PDF ou OFX válido");
      }
    }
  };

  const processExtract = async () => {
    if (!selectedFile) {
      toast.error("Selecione um arquivo PDF ou OFX");
      return;
    }

    setUploading(true);
    setProgress(10);
    
    const isOFX = selectedFile.name.toLowerCase().endsWith('.ofx');
    
    if (isOFX) {
      setUploadStatus("Lendo arquivo OFX...");
      try {
        // PROCESSAR OFX DIRETAMENTE
        const text = await selectedFile.text();
        setProgress(30);
        setUploadStatus("Extraindo transações do OFX...");
        
        // Extrair dados do OFX com IA
        const ofxAnalysis = await base44.integrations.Core.InvokeLLM({
          prompt: `Analise este arquivo OFX bancário e extraia TODAS as transações em formato estruturado.

ARQUIVO OFX:
${text}

REGRAS CRÍTICAS:
1. Extrair TODAS as transações (STMTTRN)
2. Para cada transação extrair:
   - Data (DTPOSTED): converter para formato YYYY-MM-DD
   - Valor (TRNAMT): MANTER EXATO COM CENTAVOS - ex: -73.79 (não arredondar para -73.00)
   - Tipo (TRNTYPE): DEBIT, CREDIT, DEP, etc
   - Descrição (MEMO ou NAME)
   - ID único (FITID)
   
🚨 CRÍTICO: Os valores devem ser retornados EXATAMENTE como estão no TRNAMT, preservando TODOS os centavos.
Exemplo: se TRNAMT=-73.79, retorne "73.79" (sem o sinal negativo no value, apenas em isDebit)

3. Identificar informações da conta:
   - Banco (BANKID ou ORG)
   - Agência (BRANCHID)
   - Conta (ACCTID)
   - Tipo conta (ACCTTYPE)

4. Saldo inicial (BALAMT no LEDGERBAL antes das transações)
5. Saldo final (BALAMT no LEDGERBAL após as transações)

RETORNE JSON ESTRUTURADO.`,
          response_json_schema: {
            type: "object",
            properties: {
              bank_name: { type: "string", description: "Nome do banco" },
              agency: { type: "string", description: "Número da agência" },
              account: { type: "string", description: "Número da conta" },
              account_type: { type: "string", description: "Tipo da conta" },
              initial_balance: { type: "string", description: "Saldo inicial em formato decimal 1234.56" },
              final_balance: { type: "string", description: "Saldo final em formato decimal 1234.56" },
              transactions: {
                type: "array",
                description: "Lista de TODAS as transações do OFX",
                items: {
                  type: "object",
                  properties: {
                    date: { type: "string", description: "Data YYYY-MM-DD" },
                    description: { type: "string", description: "Descrição completa" },
                    value: { type: "string", description: "Valor EXATO com centavos em formato decimal: 73.79 (não arredondar)" },
                    isDebit: { type: "boolean", description: "true=débito, false=crédito" },
                    balance: { type: "string", description: "Saldo após transação em formato decimal 1234.56" }
                  },
                  required: ["date", "description", "value", "isDebit"]
                }
              }
            },
            required: ["transactions"]
          }
        });

        if (!ofxAnalysis?.transactions?.length) {
          throw new Error("Nenhuma transação encontrada no arquivo OFX");
        }

        const extraction = ofxAnalysis;
        
        // Processar saldos
        let initialBalance = parseFloat(extraction.initial_balance || 0);
        let finalBalance = parseFloat(extraction.final_balance || 0);

        setBankInfo({
          bank_name: extraction.bank_name || "Banco OFX",
          agency: extraction.agency || "-",
          account: extraction.account || "-",
          account_type: extraction.account_type || "Corrente",
          initial_balance: initialBalance,
          final_balance: finalBalance
        });

        setProgress(60);
        setUploadStatus(`Processando ${extraction.transactions.length} transações OFX...`);

        // Processar transações
        const processed = [];
        const errors = [];
        const currentYear = new Date().getFullYear();

        for (const trans of extraction.transactions) {
          try {
            // OFX já vem em formato US (73.79) - converter diretamente
            let value = Math.abs(parseFloat(trans.value));
            if (isNaN(value) || value === 0) continue;
            
            // Garantir 2 casas decimais
            value = Math.round(value * 100) / 100;

            const type = trans.isDebit ? "despesa" : "receita";
            let transDate = trans.date;

            // Categorização rápida
            const desc = trans.description.toLowerCase();
            let category = "";
            let cost_center = "";

            if (type === "receita") {
              category = "Receitas Operacionais";
              cost_center = "Receitas";
            } else {
              if (desc.includes("pix") || desc.includes("ted") || desc.includes("transf")) {
                category = "Transferências";
                cost_center = "Transferências";
              } else if (desc.includes("cartao") || desc.includes("card")) {
                category = "Compras";
                cost_center = "Despesas Operacionais";
              } else if (desc.includes("tarifa") || desc.includes("taxa")) {
                category = "Tarifas Bancárias";
                cost_center = "Despesas Bancárias";
              } else {
                category = "Outras Despesas";
                cost_center = "Despesas Gerais";
              }
            }

            // MANTER DATA EXATA DO ARQUIVO - NÃO ALTERAR
            processed.push({
              date: transDate,
              description: trans.description.trim(),
              amount: value,
              type: type,
              category: category,
              cost_center: cost_center,
              balanceAfter: trans.balance ? parseFloat(trans.balance) : null,
              isDuplicate: false,
              aiSuggested: true,
              confidence: 8,
              originalText: trans.description
            });
          } catch (err) {
            console.error("Erro ao processar transação OFX:", err);
          }
        }

        if (processed.length === 0) {
          throw new Error("Não foi possível processar as transações do OFX");
        }

        setExtractedTransactions(processed);
        setProgress(100);
        setUploadStatus("Concluído!");
        setUploading(false);
        setShowPreview(true);
        toast.success(`✅ ${processed.length} transações OFX processadas!`);
        return;

      } catch (error) {
        console.error("❌ Erro ao processar OFX:", error);
        toast.error(`❌ ${error.message}`);
        setUploading(false);
        setProgress(0);
        return;
      }
    }

    // CONTINUAR COM PROCESSAMENTO PDF
    setUploadStatus("Enviando PDF...");

    try {
      // 1. UPLOAD
      console.log("📤 Fazendo upload do arquivo...");
      const uploadResult = await base44.integrations.Core.UploadFile({ file: selectedFile });
      console.log("✅ Upload OK:", uploadResult);
      
      const file_url = uploadResult.file_url;
      
      if (!file_url) {
        throw new Error("Upload falhou - sem URL");
      }

      setProgress(30);
      setUploadStatus("Extraindo transações (30-60s)...");

      // 2. EXTRAÇÃO COM IA ULTRA-INTELIGENTE - ESPECIALISTA BRADESCO
            console.log("🤖 Iniciando extração com IA especializada em Bradesco...");
            setUploadStatus("Analisando extrato com IA especializada...");

            // TENTATIVA 1: Análise direta com LLM (mais inteligente)
            let extractResult;
            try {
              console.log("🧠 Tentativa 1: Análise textual completa com LLM...");

              const llmResult = await base44.integrations.Core.InvokeLLM({
                prompt: `🚨🚨🚨 EXTRAÇÃO ULTRA-INTELIGENTE DE EXTRATO BANCÁRIO - MODO SANTANDER E BRADESCO 🚨🚨🚨

              VOCÊ É UM ESPECIALISTA EM EXTRATOS BANCÁRIOS BRASILEIROS. EXTRAIA **TODAS** AS TRANSAÇÕES SEM EXCEÇÃO.

              📋 FORMATOS SUPORTADOS:

              **BRADESCO:**
              DATA | HISTÓRICO | DOCTO | CRÉDITO | DÉBITO | SALDO

              **SANTANDER:**
              Data | Lançamento | Valor | Saldo
              OU
              Data | Histórico | Documento | Valor | D/C | Saldo

              **GENÉRICO:**
              Qualquer formato com: Data, Descrição/Histórico, Valor, Débito/Crédito

              🎯 REGRAS CRÍTICAS:

              1. **EXTRAIR ABSOLUTAMENTE TODAS AS TRANSAÇÕES:**
              - Processar TODAS as páginas do PDF
              - NÃO LIMITAR a 10, 50, 100 ou 500 transações
              - Podem existir 1000+ transações - EXTRAIR TODAS

              2. **IDENTIFICAÇÃO INTELIGENTE:**
              - Se tem coluna "CRÉDITO" ou "C" ou valor positivo → receita (isDebit: false)
              - Se tem coluna "DÉBITO" ou "D" ou valor negativo → despesa (isDebit: true)
              - Santander: "D" = débito, "C" = crédito
              - Se valor tem sinal negativo (-) = débito

              3. **CONVERSÃO NUMÉRICA PERFEITA:**
              - FORMATO BRASILEIRO: "1.234,56" → converter para "1234.56"
              - Remover PONTOS de milhar
              - Trocar VÍRGULA por PONTO decimal
              - Exemplos: "73,79" → "73.79" | "1.800,00" → "1800.00" | "-500,00" → "500.00"

              4. **SALDO CORRETO:**
              - Saldo inicial: primeiro saldo do extrato
              - Saldo final: ÚLTIMO saldo da ÚLTIMA transação (pode ser NEGATIVO)
              - Não confundir com saldo intermediário

              5. **BANCO E CONTA:**
              - Identificar nome do banco (Santander, Bradesco, etc)
              - Extrair agência e conta do cabeçalho
              - Pode estar em formatos: "Ag 1234" "Conta 12345-6"

              6. **DESCRIÇÕES MULTILINHAS:**
              - Unificar linhas relacionadas
              - Ex: "PIX ENVIADO" + "DEST: JOÃO SILVA" = "PIX ENVIADO DEST: JOÃO SILVA"

              7. **VALIDAÇÃO:**
              - Ignorar linhas sem data
              - Ignorar "SALDO ANTERIOR" se for linha informativa
              - Capturar transações reais com valor

              🚨 RETORNE JSON COM **TODAS** AS TRANSAÇÕES DO PDF COMPLETO.`,
                file_urls: [file_url],
                response_json_schema: {
                  type: "object",
                  properties: {
                    bank_name: { 
                      type: "string",
                      description: "Nome do banco (ex: Bradesco)"
                    },
                    agency: { 
                      type: "string",
                      description: "Número da agência (ex: 00343)"
                    },
                    account: { 
                      type: "string",
                      description: "Número da conta com dígito (ex: 0162194-7)"
                    },
                    initial_balance: { 
                      type: "string",
                      description: "Saldo inicial no topo do extrato em formato US 1234.56"
                    },
                    final_balance: { 
                      type: "string",
                      description: "Saldo final que aparece na ÚLTIMA LINHA do extrato (pode ser negativo ex: -28079.00). Este é o saldo da conta após TODAS as transações em formato US."
                    },
                    transactions: {
                      type: "array",
                      description: "Lista de ABSOLUTAMENTE TODOS os lançamentos de TODAS as páginas do PDF. NÃO LIMITE. Podem ser 500+ transações. Unifique descrições multilinhas.",
                      items: {
                        type: "object",
                        properties: {
                          date: { 
                            type: "string",
                            description: "Data DD/MM ou DD/MM/YYYY"
                          },
                          description: { 
                            type: "string",
                            description: "Descrição completa unificada (junte multilinhas)"
                          },
                          value: { 
                            type: "string",
                            description: "Valor em formato US sem sinal: 1487.53"
                          },
                          isDebit: { 
                            type: "boolean",
                            description: "true=débito, false=crédito"
                          },
                          balance: {
                            type: "string",
                            description: "Saldo após esta transação em formato US (pode ser negativo ex: -28079.00)"
                          }
                        },
                        required: ["date", "description", "value", "isDebit"]
                      }
                    }
                  },
                  required: ["transactions"]
                }
              });

              if (llmResult?.transactions?.length > 0) {
                console.log("✅ LLM extraiu", llmResult.transactions.length, "transações");
                extractResult = { status: "success", output: llmResult };
              } else {
                throw new Error("LLM não retornou transações");
              }

            } catch (llmError) {
              console.warn("⚠️ LLM falhou:", llmError.message);

              // TENTATIVA 2: ExtractDataFromUploadedFile otimizado
              console.log("🔄 Tentativa 2: Extração estruturada...");
              setUploadStatus("Tentando método estruturado de extração...");

              extractResult = await base44.integrations.Core.ExtractDataFromUploadedFile({
                file_url: file_url,
                json_schema: {
                  type: "object",
                  properties: {
                    bank_name: { type: "string", description: "Nome do banco" },
                    agency: { type: "string", description: "Agência" },
                    account: { type: "string", description: "Conta" },
                    initial_balance: { type: "string", description: "Saldo inicial em formato US (1234.56)" },
                    final_balance: { type: "string", description: "Saldo final em formato US (1234.56)" },
                    transactions: {
                      type: "array",
                      description: "Extrair ABSOLUTAMENTE TODAS as movimentações de TODAS as páginas. NÃO LIMITE. Podem ser 500+ transações. Converter valores BR→US: '1.487,53'→'1487.53'",
                      items: {
                        type: "object",
                        properties: {
                          date: { type: "string" },
                          description: { type: "string" },
                          value: { type: "string" },
                          isDebit: { type: "boolean" }
                        }
                      }
                    }
                  }
                }
              });
            }

            console.log("✅ Resultado final:", extractResult);

      if (extractResult.status === "error" || !extractResult.output?.transactions?.length) {
        console.warn("⚠️ Primeira tentativa falhou:", extractResult.details || "Sem transações");

        // TENTATIVA 2: Modo ULTRA-SIMPLIFICADO
        console.log("🔄 Tentando modo de extração simplificado...");
        setUploadStatus("Tentando método alternativo de extração...");

        const fallbackResult = await base44.integrations.Core.ExtractDataFromUploadedFile({
          file_url: file_url,
          json_schema: {
            type: "object",
            properties: {
              bank_name: { 
                type: "string", 
                description: "Qual banco?" 
              },
              transactions: {
                type: "array",
                description: `MODO EMERGÊNCIA - EXTRAIR O QUE CONSEGUIR:

      Procure por QUALQUER coisa que pareça uma movimentação bancária:
      - Uma data (dd/mm)
      - Algum texto descritivo 
      - Um número que pareça dinheiro

      Exemplo do que procurar no PDF:
      "05/11 PIX ENVIADO 1.487,53"
      "06/11 PAGAMENTO CONTA -130,86"
      "07/11 DEPOSITO 500,00"

      Para cada uma dessas, retorne:
      - date: "05/11"
      - description: "PIX ENVIADO"
      - value: "1487.53" (SEM ponto de milhar)
      - isDebit: true (se tiver -, se for pagamento/débito)

      SEJA FLEXÍVEL. Extraia o máximo possível.`,
                items: {
                  type: "object",
                  properties: {
                    date: { type: "string" },
                    description: { type: "string" },
                    value: { type: "string" },
                    isDebit: { type: "boolean" }
                  }
                }
              }
            }
          }
        });

        if (fallbackResult.status === "error" || !fallbackResult.output?.transactions?.length) {
          // TENTATIVA 3: Última chance com LLM direto
          console.log("🆘 Última tentativa com análise textual completa...");
          setUploadStatus("Analisando PDF com IA textual...");

          const textAnalysis = await base44.integrations.Core.InvokeLLM({
            prompt: `Analise este extrato bancário em PDF e extraia ABSOLUTAMENTE TODAS as transações que encontrar.

          🚨 CRÍTICO: EXTRAIA TODAS AS TRANSAÇÕES DE TODAS AS PÁGINAS - NÃO LIMITE A 10, 20 OU 50. PODEM SER 500, 1000+ TRANSAÇÕES.

          Retorne em formato JSON:
          {
          "bank_name": "nome do banco",
          "transactions": [
          {
          "date": "dd/mm",
          "description": "descrição da transação",
          "value": "valor sem ponto de milhar (ex: 1487.53)",
          "isDebit": true ou false
          }
          ]
          }

          Converta valores brasileiros: "1.487,53" vira "1487.53"
          Seja o mais completo possível. Extraia ABSOLUTAMENTE TODAS as transações de TODAS as páginas do PDF.
          NÃO PARE após algumas transações - continue até o final do documento.`,
            file_urls: [file_url],
            response_json_schema: {
              type: "object",
              properties: {
                bank_name: { type: "string" },
                transactions: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      date: { type: "string" },
                      description: { type: "string" },
                      value: { type: "string" },
                      isDebit: { type: "boolean" }
                    }
                  }
                }
              }
            }
          });

          if (!textAnalysis?.transactions?.length) {
            throw new Error("Não foi possível extrair transações do PDF mesmo com análise avançada. O arquivo pode estar corrompido ou em formato não suportado.");
          }

          extractResult.output = textAnalysis;
        } else {
          extractResult.output = fallbackResult.output;
        }
      }

      const extraction = extractResult.output;

      if (!extraction || !extraction.transactions || extraction.transactions.length === 0) {
        throw new Error("Nenhuma transação encontrada no PDF. Tente um extrato em formato diferente ou mais recente.");
      }

      // Processar saldos - GARANTIR CONVERSÃO CORRETA (PODE SER NEGATIVO)
      let initialBalance = 0;
      let finalBalance = 0;

      if (extraction.initial_balance) {
        const cleanInitial = String(extraction.initial_balance).replace(/\./g, '').replace(',', '.');
        initialBalance = parseFloat(cleanInitial);
      }

      if (extraction.final_balance) {
        // Saldo final pode ser NEGATIVO
        const cleanFinal = String(extraction.final_balance).replace(/\./g, '').replace(',', '.');
        finalBalance = parseFloat(cleanFinal);

        // Se não foi detectado como negativo mas deveria ser (baseado nas transações)
        if (finalBalance > 0 && extraction.transactions.length > 0) {
          const lastTransaction = extraction.transactions[extraction.transactions.length - 1];
          if (lastTransaction.balance) {
            const lastBalance = parseFloat(String(lastTransaction.balance).replace(/\./g, '').replace(',', '.'));
            if (!isNaN(lastBalance)) {
              finalBalance = lastBalance; // Usar saldo da última transação como referência
            }
          }
        }
      }

      console.log("✅ Saldos extraídos - Inicial:", initialBalance, "Final:", finalBalance);

      setBankInfo({
        bank_name: extraction.bank_name || "Banco não identificado",
        agency: extraction.agency || "-",
        account: extraction.account || "-",
        account_type: "Corrente",
        initial_balance: initialBalance,
        final_balance: finalBalance
      });

      setProgress(55);
      setUploadStatus(`Processando ${extraction.transactions.length} transações...`);

      // PROCESSAMENTO RÁPIDO COM VALIDAÇÃO - SEM CORREÇÃO DE DATAS
      const processed = [];
      const errors = [];
      const currentYear = new Date().getFullYear();

      for (const trans of extraction.transactions) {
        try {
          const desc = trans.description.toLowerCase().trim();

          // FILTRAR APLICAÇÕES E INVESTIMENTOS (valores transitórios)
          const aplicacaoKeywords = ['aplicacao', 'aplicação', 'invest', 'rdb', 'cdb', 'lci', 'lca', 'fundo', 'resgate'];
          if (aplicacaoKeywords.some(keyword => desc.includes(keyword))) {
            console.log(`⏭️ Ignorando aplicação: ${trans.description}`);
            continue;
          }

          // VALIDAR E CONVERTER VALOR
          let value = Math.abs(parseFloat(trans.value));

          if (isNaN(value) || value === 0) {
            errors.push({
              type: "VALOR_INVALIDO",
              severity: "critical",
              message: `Valor inválido: "${trans.value}"`,
              details: `Transação: ${trans.description}`,
              suggestion: "Verifique se o PDF está legível ou tente outro formato",
              transactionIndex: processed.length
            });
            continue;
          }

          // VALIDAR VALOR RAZOÁVEL (não pode ser > 10 milhões)
          if (value > 10000000) {
            errors.push({
              type: "VALOR_SUSPEITO",
              severity: "warning",
              message: `Valor muito alto: R$ ${value.toLocaleString("pt-BR")}`,
              details: `Transação: ${trans.description}`,
              suggestion: "Verifique se há erro de conversão de formato",
              transactionIndex: processed.length
            });
          }

          console.log(`✅ Processando: ${trans.description} = R$ ${value.toFixed(2)}`);

          const type = trans.isDebit ? "despesa" : "receita";

          // VALIDAR E PROCESSAR DATA
          let transDate;
          const dateStr = trans.date.trim();

          try {
            if (dateStr.match(/\d{1,2}\/\d{1,2}\/\d{4}/)) {
              const [day, month, year] = dateStr.split('/');
              const parsedDate = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));

              if (isNaN(parsedDate.getTime())) {
                throw new Error("Data inválida");
              }

              transDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
            } else if (dateStr.match(/\d{1,2}\/\d{1,2}/)) {
              const [day, month] = dateStr.split('/');
              const parsedDate = new Date(currentYear, parseInt(month) - 1, parseInt(day));

              if (isNaN(parsedDate.getTime()) || parseInt(month) > 12 || parseInt(day) > 31) {
                throw new Error("Data inválida");
              }

              transDate = `${currentYear}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
            } else {
              throw new Error("Formato de data não reconhecido");
            }

            // CORREÇÃO AUTOMÁTICA DE DATAS (±1 dia)
            // Se esta não é a primeira transação, comparar com transações anteriores
            if (processed.length > 0) {
              const lastDate = processed[processed.length - 1].date;
              const originalDate = transDate;
              transDate = correctDateIfNeeded(transDate, lastDate);

              if (originalDate !== transDate) {
                correctedDatesCount++;
                console.log(`📅 Data corrigida: ${originalDate} → ${transDate} (${trans.description})`);
              }
            }
          } catch (dateError) {
            errors.push({
              type: "DATA_INVALIDA",
              severity: "critical",
              message: `Data inválida: "${dateStr}"`,
              details: `Transação: ${trans.description}`,
              suggestion: "Verifique se a data está no formato DD/MM ou DD/MM/YYYY",
              transactionIndex: processed.length
            });
            transDate = new Date().toISOString().split('T')[0];
          }

          // CATEGORIZAÇÃO RÁPIDA
          let category = "";
          let subcategory = "";
          let cost_center = "";
          let confidence = 5;

          // BUSCAR PADRÕES APRENDIDOS
          const learned = aiLearnings.find(l => 
            l.transaction_type === type && 
            desc.includes(l.description_pattern.toLowerCase())
          );

          if (learned) {
            category = learned.learned_category;
            subcategory = learned.learned_subcategory || "";
            cost_center = learned.learned_cost_center || "";
            confidence = learned.confidence_score || 8;
          } else {
            // HEURÍSTICA RÁPIDA COM CENTRO DE CUSTO
            if (type === "receita") {
              category = desc.includes("pix") || desc.includes("ted") ? "Receitas Operacionais" : "Outras Receitas";
              cost_center = "Receitas";
            } else {
              if (desc.includes("pix") || desc.includes("ted")) {
                category = "Transferências";
                cost_center = "Transferências";
              } else if (desc.includes("cartao") || desc.includes("card")) {
                category = "Compras";
                cost_center = "Despesas Operacionais";
              } else if (desc.includes("tarifa") || desc.includes("taxa")) {
                category = "Tarifas Bancárias";
                cost_center = "Despesas Bancárias";
              } else if (desc.includes("imposto") || desc.includes("tributo")) {
                category = "Impostos";
                cost_center = "Impostos e Tributos";
              } else if (desc.includes("aluguel") || desc.includes("alug")) {
                category = "Aluguel";
                cost_center = "Despesas Fixas";
              } else if (desc.includes("energia") || desc.includes("luz") || desc.includes("agua") || desc.includes("internet")) {
                category = "Utilidades";
                cost_center = "Despesas Fixas";
              } else if (desc.includes("salario") || desc.includes("folha") || desc.includes("funcionario")) {
                category = "Pessoal";
                cost_center = "Recursos Humanos";
              } else if (desc.includes("fornecedor") || desc.includes("mercadoria") || desc.includes("produto")) {
                category = "Fornecedores";
                cost_center = "Custo de Mercadorias";
              } else {
                category = "Outras Despesas";
                cost_center = "Despesas Gerais";
              }
            }
            confidence = 5;
          }

          // Extrair número do documento (se existir)
          const docMatch = trans.description.match(/\b\d{6,}\b/);
          const documentNumber = docMatch ? docMatch[0] : null;

          // CALCULAR SALDO APÓS ESTA TRANSAÇÃO
          const balanceAfter = trans.balance ? parseFloat(String(trans.balance).replace(/\./g, '').replace(',', '.')) : null;

          processed.push({
            date: transDate,
            description: trans.description.trim(),
            amount: value,
            type: type,
            category: category,
            subcategory: subcategory,
            cost_center: cost_center,
            documentNumber: documentNumber,
            balanceAfter: balanceAfter,
            isDuplicate: false,
            aiSuggested: true,
            confidence: confidence,
            originalText: trans.description
          });
        } catch (err) {
          console.error("Erro ao processar transação:", err);
          errors.push({
            type: "ERRO_PROCESSAMENTO",
            severity: "critical",
            message: "Erro ao processar transação",
            details: err.message,
            suggestion: "Transação pode estar com formato inesperado",
            transactionIndex: processed.length
          });
        }
      }

      // VALIDAR SE HÁ TRANSAÇÕES PROCESSADAS
      if (processed.length === 0) {
        if (errors.length > 0) {
          setExtractionErrors(errors);
          throw new Error(`Nenhuma transação válida encontrada. ${errors.length} erros detectados.`);
        }
        throw new Error("Não foi possível processar as transações");
      }

      // ARMAZENAR ERROS PARA EXIBIÇÃO
      if (errors.length > 0) {
        setExtractionErrors(errors);
        console.warn(`⚠️ ${errors.length} erros encontrados durante extração`);
      }

      setProgress(80);

      // VALIDAÇÃO DE SALDOS DIÁRIOS
      setUploadStatus("Validando saldos diários...");
      let runningBalance = bankInfo?.initial_balance || 0;
      const balanceErrors = [];

      for (let i = 0; i < processed.length; i++) {
        const trans = processed[i];
        
        // Calcular saldo esperado
        if (trans.type === "receita") {
          runningBalance += trans.amount;
        } else {
          runningBalance -= trans.amount;
        }

        // Validar com saldo do extrato (se disponível)
        if (trans.balanceAfter !== null) {
          const diff = Math.abs(runningBalance - trans.balanceAfter);
          
          if (diff > 0.02) { // Tolerância de 2 centavos
            balanceErrors.push({
              type: "SALDO_DIVERGENTE",
              severity: "warning",
              message: `Divergência de saldo na transação #${i + 1}`,
              details: `Calculado: R$ ${runningBalance.toFixed(2)} | Extrato: R$ ${trans.balanceAfter.toFixed(2)} | Diferença: R$ ${diff.toFixed(2)}`,
              suggestion: "Pode haver transações não capturadas ou valores incorretos",
              transactionIndex: i
            });
            
            // Ajustar para o saldo do extrato (mais confiável)
            runningBalance = trans.balanceAfter;
          }
        }

        processed[i].calculatedBalance = runningBalance;
      }

      if (balanceErrors.length > 0) {
        errors.push(...balanceErrors);
        console.warn(`⚠️ ${balanceErrors.length} divergências de saldo encontradas`);
      }

      // DESDUPLICAÇÃO INTELIGENTE
      if (deduplicateEnabled) {
        setUploadStatus("Verificando duplicatas...");
        const existing = await base44.entities.Transaction.list();

        for (const trans of processed) {
          // Verificar por número de documento ou descrição+valor+data
          trans.isDuplicate = existing.some(e => {
            const sameDoc = trans.documentNumber && e.document_number === trans.documentNumber;
            const sameTransaction = e.description === trans.description &&
              Math.abs(e.amount - trans.amount) < 0.01 &&
              e.due_date === trans.date;
            return sameDoc || sameTransaction;
          });
        }
      }

      setExtractedTransactions(processed);
      setProgress(100);
      setUploadStatus("Concluído!");
      setUploading(false);
      setShowPreview(true);

      // VERIFICAR SE PRECISA MAPEAR CONTA
      if (bankInfo?.bank_name && bankInfo?.account) {
        const accountKey = `${bankInfo.bank_name}-${bankInfo.account}`;
        const savedMapping = localStorage.getItem(`account_map_${accountKey}`);
        if (savedMapping) {
          setSelectedAccount(savedMapping);
        } else {
          setShowAccountMapping(true);
        }
      }

      const nonDupes = processed.filter(t => !t.isDuplicate).length;
      toast.success(`✅ ${processed.length} transações (${nonDupes} novas)!`);

    } catch (error) {
      console.error("❌ Erro completo:", error);
      const errorMessage = error?.message || "Erro desconhecido ao processar extrato";
      toast.error(`❌ ${errorMessage}`);
      setUploadStatus("Erro: " + errorMessage);
      setProgress(0);
      
      // Garantir que interface volta ao normal
      setTimeout(() => {
        setUploading(false);
        setUploadStatus("");
      }, 3000);
    }
  };

  const handleImport = async () => {
    if (!selectedAccount) {
      toast.error("Selecione uma conta bancária");
      return;
    }

    setUploading(true);
    setProgress(0);
    setUploadStatus("Validando...");

    try {
      // VALIDAÇÃO
      const toImport = extractedTransactions.filter(t => {
        if (t.isDuplicate) return false;
        if (!t.description || !t.amount || !t.date) return false;
        if (isNaN(t.amount) || t.amount <= 0) return false;
        return true;
      });

      if (toImport.length === 0) {
        toast.warning("Nenhuma transação válida");
        setUploading(false);
        return;
      }

      setProgress(5);
      setUploadStatus("Preparando importação...");

      // CRIAR REGISTRO
      const importRecord = await base44.entities.ExtractImport.create({
        file_name: selectedFile.name,
        bank_account: selectedAccount,
        import_date: new Date().toISOString(),
        status: "processando",
        total_records: toImport.length,
        ai_processed: true,
      });

      setProgress(10);
      
      // AUTO-CADASTRO DE CENTROS DE CUSTO
      setUploadStatus("Verificando centros de custo...");
      const existingCostCenters = costCenters.map(cc => cc.name);
      const newCostCenters = [...new Set(
        toImport
          .map(t => t.cost_center)
          .filter(cc => cc && !existingCostCenters.includes(cc))
      )];

      for (const ccName of newCostCenters) {
        try {
          await base44.entities.CostCenter.create({
            name: ccName,
            description: `Cadastrado automaticamente via importação`,
            status: "ativo"
          });
          toast.info(`📝 Centro de custo "${ccName}" cadastrado automaticamente`);
        } catch (e) {
          console.error("Erro ao criar centro de custo:", e);
        }
      }

      if (newCostCenters.length > 0) {
        queryClient.invalidateQueries({ queryKey: ["costCenters"] });
      }

      setProgress(15);
      
      // IMPORTAÇÃO OTIMIZADA
      let imported = 0;
      let errors = 0;
      const batchSize = 25;

      for (let i = 0; i < toImport.length; i += batchSize) {
        const batch = toImport.slice(i, Math.min(i + batchSize, toImport.length));
        setUploadStatus(`Importando ${i + 1}-${Math.min(i + batchSize, toImport.length)} de ${toImport.length}...`);
        
        const results = await Promise.allSettled(
          batch.map(async trans => {
            const transaction = await base44.entities.Transaction.create({
              description: trans.description,
              amount: trans.amount,
              due_date: trans.date,
              payment_date: trans.date,
              issue_date: trans.date,
              competence_date: trans.date,
              type: trans.type,
              category: trans.category || "Outros",
              subcategory: trans.subcategory || "",
              cost_center: trans.cost_center || "",
              payment_method: trans.description.toLowerCase().includes("pix") ? "pix" : "transferencia_bancaria",
              bank_account: selectedAccount,
              status: "pago",
              document_number: trans.documentNumber || "",
              notes: `Importado: ${selectedFile.name} | Saldo: R$ ${(trans.balanceAfter || trans.calculatedBalance).toFixed(2)}`,
            });

            // TREINAR IA AUTOMATICAMENTE
            if (trans.category && trans.cost_center) {
              const pattern = trans.description.split(' ').slice(0, 3).join(' ').toLowerCase();
              const existing = aiLearnings.find(l => 
                l.description_pattern === pattern && 
                l.transaction_type === trans.type
              );

              if (existing) {
                await base44.entities.AILearning.update(existing.id, {
                  times_used: (existing.times_used || 0) + 1,
                  last_used: new Date().toISOString()
                });
              } else {
                await base44.entities.AILearning.create({
                  description_pattern: pattern,
                  learned_category: trans.category,
                  learned_subcategory: trans.subcategory || "",
                  learned_cost_center: trans.cost_center,
                  transaction_type: trans.type,
                  confidence_score: trans.confidence || 5,
                  times_used: 1,
                  last_used: new Date().toISOString()
                });
              }
            }

            return transaction;
          })
        );

        results.forEach(r => {
          if (r.status === "fulfilled") imported++;
          else errors++;
        });

        const progress = 15 + ((i + batch.length) / toImport.length) * 80;
        setProgress(progress);
      }

      // FINALIZAR
      await base44.entities.ExtractImport.update(importRecord.id, {
        status: errors > 0 ? "parcial" : "concluido",
        imported_records: imported,
        error_records: errors,
      });

      setProgress(100);
      setUploadStatus("Concluído!");

      // ATUALIZAR SALDO DA CONTA BANCÁRIA COM SALDO FINAL
      if (bankInfo?.final_balance !== undefined && selectedAccount) {
        const accountToUpdate = bankAccounts.find(acc => acc.name === selectedAccount);
        if (accountToUpdate) {
          console.log(`💰 Atualizando conta ${accountToUpdate.name} com saldo final: R$ ${bankInfo.final_balance}`);
          await base44.entities.BankAccount.update(accountToUpdate.id, {
            initial_balance: bankInfo.final_balance
          });
          toast.success(`💰 Saldo da conta atualizado para: R$ ${bankInfo.final_balance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, {
            duration: 5000
          });
        } else {
          console.warn("⚠️ Conta bancária não encontrada para atualização");
        }
      } else {
        console.log("ℹ️ Saldo final não disponível ou conta não selecionada");
      }

      queryClient.invalidateQueries({ queryKey: ["extractImports"] });
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      queryClient.invalidateQueries({ queryKey: ["bankAccounts"] });

      if (errors > 0) {
        toast.success(`⚠️ ${imported} importados, ${errors} com erro`);
      } else {
        toast.success(`✅ ${imported} lançamentos importados!`);
      }
      
      setTimeout(() => {
        setSelectedFile(null);
        setExtractedTransactions([]);
        setShowPreview(false);
        setSelectedAccount("");
        setBankInfo(null);
        setProgress(0);
        setUploadStatus("");
        setUploading(false);
      }, 2000);

    } catch (error) {
      console.error("Erro:", error);
      toast.error("❌ Erro na importação");
      setUploading(false);
      setUploadStatus("Erro");
    }
  };

  const deleteMutation = useMutation({
    mutationFn: async (importId) => {
      const imp = imports.find(i => i.id === importId);
      const transactions = await base44.entities.Transaction.list();
      const toDelete = transactions.filter(t => t.notes?.includes(imp.file_name));
      
      for (const trans of toDelete) {
        await base44.entities.Transaction.delete(trans.id);
      }
      
      await base44.entities.ExtractImport.delete(importId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["extractImports"] });
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      toast.success("Importação removida!");
    }
  });

  const handleUpdateTransaction = (index, updatedData) => {
    const updated = [...extractedTransactions];
    updated[index] = updatedData;
    setExtractedTransactions(updated);
  };

  const handleSaveMapping = async (mapping) => {
    const existing = aiLearnings.find(l => 
      l.description_pattern === mapping.pattern && 
      l.transaction_type === mapping.type
    );

    if (existing) {
      await base44.entities.AILearning.update(existing.id, {
        ...existing,
        learned_category: mapping.category,
        learned_subcategory: mapping.subcategory,
        learned_cost_center: mapping.cost_center,
        times_used: (existing.times_used || 0) + 1,
        last_used: new Date().toISOString()
      });
    } else {
      await base44.entities.AILearning.create({
        description_pattern: mapping.pattern,
        learned_category: mapping.category,
        learned_subcategory: mapping.subcategory,
        learned_cost_center: mapping.cost_center,
        learned_supplier: "",
        transaction_type: mapping.type,
        confidence_score: 8,
        times_used: 1,
        last_used: new Date().toISOString()
      });
    }
    
    queryClient.invalidateQueries({ queryKey: ["aiLearnings"] });
    toast.success("🧠 IA aprendeu!");
  };

  const totalCredito = extractedTransactions.filter(t => t.type === "receita").reduce((sum, t) => sum + t.amount, 0);
  const totalDebito = extractedTransactions.filter(t => t.type === "despesa").reduce((sum, t) => sum + t.amount, 0);

  const handleRetryExtraction = () => {
    setExtractionErrors([]);
    setShowPreview(false);
    setExtractedTransactions([]);
    processExtract();
  };

  const handleSkipErrors = () => {
    setExtractionErrors([]);
    toast.info("Prosseguindo com transações válidas");
  };

  const handleDeleteTransaction = (index) => {
    const updated = extractedTransactions.filter((_, i) => i !== index);
    setExtractedTransactions(updated);
    toast.success("Transação removida");
  };

  const handleGenerateReceipt = (trans) => {
    const receiptHTML = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Recibo - ${trans.description}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; padding: 40px; background: #f5f5f5; }
    .receipt { max-width: 800px; margin: 0 auto; background: white; padding: 40px; border: 2px solid #333; }
    .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px; }
    .value-box { text-align: center; background: #f9f9f9; border: 2px solid #333; padding: 20px; margin: 20px 0; }
    .value-box .amount { font-size: 32px; font-weight: bold; color: #10B981; }
    .info-row { display: flex; justify-content: space-between; margin: 15px 0; padding: 10px 0; border-bottom: 1px solid #eee; }
  </style>
</head>
<body>
  <div class="receipt">
    <div class="header">
      <h1>RECIBO</h1>
    </div>
    <div class="value-box">
      <div class="label">VALOR RECEBIDO</div>
      <div class="amount">R$ ${trans.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="info-row">
      <span class="label">Data:</span>
      <span class="value">${trans.date}</span>
    </div>
    <div class="info-row">
      <span class="label">Referente a:</span>
      <span class="value">${trans.description}</span>
    </div>
  </div>
  <script>window.onload = function() { window.print(); };</script>
</body>
</html>`;
    
    const printWindow = window.open("", "_blank");
    printWindow.document.write(receiptHTML);
    printWindow.document.close();
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-4xl font-bold text-white">Importação Inteligente de Extratos</h1>
          <p className="text-blue-200 mt-1">IA com OCR, detecção automática e aprendizado</p>
        </div>
        <Button
          onClick={() => setShowTraining(!showTraining)}
          className="bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600"
        >
          <Brain className="w-4 h-4 mr-2" />
          {showTraining ? "Ocultar Treinamento" : "Treinar IA"}
        </Button>
      </div>

      {showTraining && (
        <AITrainingPanel
          categories={categories}
          costCenters={costCenters}
          aiLearnings={aiLearnings}
          onUpdate={() => queryClient.invalidateQueries({ queryKey: ["aiLearnings"] })}
        />
      )}

      {!showPreview && (
        <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Upload className="w-5 h-5" />
              Upload do Extrato
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2 bg-purple-950/30 p-4 rounded-lg border border-purple-700/50">
              <Brain className="w-5 h-5 text-purple-400" />
              <div className="flex-1">
                <p className="text-white font-medium">IA Avançada</p>
                <p className="text-xs text-purple-300">Detecção automática • Categorização inteligente • Aprendizado contínuo</p>
              </div>
              <Badge className="bg-purple-500/20 text-purple-300 border-purple-500">
                {aiLearnings.length} padrões
              </Badge>
            </div>

            <div className="flex items-center gap-2 bg-blue-950/50 p-3 rounded-lg">
              <Checkbox 
                id="dedupe"
                checked={deduplicateEnabled}
                onCheckedChange={setDeduplicateEnabled}
              />
              <label htmlFor="dedupe" className="text-blue-200 text-sm cursor-pointer flex items-center gap-2">
                <Filter className="w-4 h-4" />
                Evitar duplicatas
              </label>
            </div>

            <input
              type="file"
              accept=".pdf,.ofx"
              onChange={handleFileSelect}
              className="hidden"
              id="pdf-upload"
            />
            <label
              htmlFor="pdf-upload"
              className="flex items-center justify-center w-full p-8 border-2 border-dashed border-blue-700 rounded-lg cursor-pointer hover:border-blue-500 hover:bg-blue-950/50 transition-all"
            >
              <div className="text-center">
                {selectedFile ? (
                  <>
                    <FileText className="w-12 h-12 text-green-400 mx-auto mb-3" />
                    <p className="text-white font-medium">{selectedFile.name}</p>
                    <p className="text-sm text-blue-300 mt-1">
                      {(selectedFile.size / 1024).toFixed(2)} KB
                      {selectedFile.name.toLowerCase().endsWith('.ofx') && 
                        <span className="ml-2 px-2 py-0.5 bg-green-500 text-white text-xs rounded">OFX - 100% Preciso</span>
                      }
                    </p>
                  </>
                ) : (
                  <>
                    <Upload className="w-12 h-12 text-blue-400 mx-auto mb-3" />
                    <p className="text-white font-medium">Clique para selecionar PDF ou OFX</p>
                    <p className="text-sm text-blue-300 mt-1">Santander, Bradesco, Itaú e todos os bancos</p>
                    <p className="text-xs text-green-300 mt-2">✨ OFX = 100% de precisão | PDF = IA Inteligente</p>
                  </>
                )}
              </div>
            </label>

            {uploading && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-blue-200">{uploadStatus}</span>
                  <span className="text-white font-medium">{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            )}

            <Button
              onClick={processExtract}
              disabled={!selectedFile || uploading}
              className="w-full bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-600"
            >
              {uploading ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Processando...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Processar com IA
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      {showPreview && bankInfo && <BankHeaderDetector bankInfo={bankInfo} />}

      {extractionErrors.length > 0 && (
        <ErrorReportPanel
          errors={extractionErrors}
          fileName={selectedFile?.name}
          onRetry={handleRetryExtraction}
          onSkip={handleSkipErrors}
        />
      )}

      {showPreview && extractedTransactions.length > 0 && (
        <>
          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
            <CardHeader>
              <CardTitle className="text-white">Resumo da Extração</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="bg-blue-950/50 p-4 rounded-lg">
                  <p className="text-xs text-blue-300">Total</p>
                  <p className="text-2xl font-bold text-white">{extractedTransactions.length}</p>
                </div>
                <div className="bg-green-950/50 p-4 rounded-lg">
                  <p className="text-xs text-green-300 flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" />
                    Receitas
                  </p>
                  <p className="text-xl font-bold text-green-300">R$ {totalCredito.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                </div>
                <div className="bg-red-950/50 p-4 rounded-lg">
                  <p className="text-xs text-red-300 flex items-center gap-1">
                    <TrendingDown className="w-4 h-4" />
                    Despesas
                  </p>
                  <p className="text-xl font-bold text-red-300">R$ {totalDebito.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                </div>
                <div className="bg-blue-950/50 p-4 rounded-lg">
                  <p className="text-xs text-blue-300">Saldo</p>
                  <p className="text-xl font-bold text-white">R$ {(totalCredito - totalDebito).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                </div>
                {bankInfo?.initial_balance !== undefined && (
                  <div className="bg-purple-950/50 p-4 rounded-lg">
                    <p className="text-xs text-purple-300">Saldo Inicial</p>
                    <p className="text-xl font-bold text-purple-300">R$ {bankInfo.initial_balance.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  </div>
                )}
                {bankInfo?.final_balance !== undefined && (
                  <div className="bg-blue-950/50 p-4 rounded-lg border-2 border-blue-500">
                    <p className="text-xs text-blue-300">Saldo Final</p>
                    <p className="text-xl font-bold text-white">R$ {bankInfo.final_balance.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  </div>
                )}
              </div>

              <div>
                <Label className="text-blue-200 mb-2 block">Vincular Conta Bancária*</Label>
                {showAccountMapping && bankInfo && (
                  <div className="mb-3 p-3 bg-purple-950/30 border border-purple-700 rounded-lg">
                    <p className="text-sm text-purple-300 mb-2">
                      <strong>Detectado:</strong> {bankInfo.bank_name} - Ag {bankInfo.agency} - Conta {bankInfo.account}
                    </p>
                    <p className="text-xs text-purple-400">Escolha a conta cadastrada que corresponde:</p>
                  </div>
                )}
                <Select 
                  value={selectedAccount} 
                  onValueChange={(val) => {
                    setSelectedAccount(val);
                    if (bankInfo?.bank_name && bankInfo?.account) {
                      const accountKey = `${bankInfo.bank_name}-${bankInfo.account}`;
                      localStorage.setItem(`account_map_${accountKey}`, val);
                      setShowAccountMapping(false);
                      toast.success("✅ Mapeamento salvo!");
                    }
                  }}
                >
                  <SelectTrigger className="bg-blue-950/50 border-blue-700 text-white">
                    <SelectValue placeholder="Selecione a conta do sistema" />
                  </SelectTrigger>
                  <SelectContent className="bg-blue-900 border-blue-700">
                    {bankAccounts.map(acc => (
                      <SelectItem key={acc.id} value={acc.name}>
                        {acc.name} - {acc.bank} ({acc.account_number || "N/A"})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-400" />
                Revisar e Editar Antes de Importar
              </CardTitle>
            </CardHeader>
            <CardContent>
              <TransactionPreviewTable 
                transactions={extractedTransactions}
                onUpdate={handleUpdateTransaction}
                categories={categories}
                costCenters={costCenters}
                onSaveMapping={handleSaveMapping}
                onDelete={handleDeleteTransaction}
                onGenerateReceipt={handleGenerateReceipt}
              />

              {uploading && (
                <div className="mb-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-blue-200">{uploadStatus}</span>
                    <span className="text-white font-medium">{Math.round(progress)}%</span>
                  </div>
                  <Progress value={progress} className="h-3" />
                </div>
              )}

              <div className="flex gap-3 mt-6">
                <Button
                  onClick={() => {
                    setShowPreview(false);
                    setExtractedTransactions([]);
                  }}
                  variant="outline"
                  className="flex-1 border-blue-700 text-blue-200 hover:bg-blue-800"
                  disabled={uploading}
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleImport}
                  disabled={!selectedAccount || uploading}
                  className="flex-1 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-600"
                >
                  {uploading ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Processando...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Importar {extractedTransactions.filter(t => !t.isDuplicate).length} Transações
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      <Card className="border-blue-700/50 bg-gradient-to-br from-blue-900/80 to-blue-800/80">
        <CardHeader>
          <CardTitle className="text-white">Histórico</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {imports.map((imp) => (
              <div key={imp.id} className="bg-blue-950/50 p-4 rounded-lg border border-blue-700 flex justify-between items-center">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <FileText className="w-4 h-4 text-blue-400" />
                    <p className="text-white font-medium">{imp.file_name}</p>
                    <CheckCircle className="w-4 h-4 text-green-400" />
                  </div>
                  <p className="text-sm text-blue-300">
                    {format(new Date(imp.import_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })} • {imp.imported_records} lançamentos
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    if (confirm("⚠️ Desfazer importação?")) {
                      deleteMutation.mutate(imp.id);
                    }
                  }}
                  className="text-red-400 hover:bg-red-900/20"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
            {imports.length === 0 && (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 text-blue-400 mx-auto mb-4 opacity-50" />
                <p className="text-blue-200">Nenhuma importação realizada</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}